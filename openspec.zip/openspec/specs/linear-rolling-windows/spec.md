## Purpose

Defines requirements for O(n) rolling window aggregations using incremental accumulators and monotonic-index deques, replacing the prior O(n·w) per-position slice approach.

## Requirements

### Requirement: Rolling aggregations run in linear time with bounded allocation

`rolling_sum`, `rolling_mean`, `rolling_min`, and `rolling_max` SHALL compute their result in O(n) time for n rows independent of window size w (rather than O(n·w)), writing into a single preallocated output buffer. The system SHALL NOT allocate a fresh slice for every window position. Sum/mean SHALL use an incremental running accumulator; min/max SHALL use a monotonic-index deque.

#### Scenario: rolling_mean does not allocate per window step

- **WHEN** `rolling_mean` is evaluated on a 1,000,000-row float64 column with window 100
- **THEN** allocation SHALL be bounded by the output buffer plus O(w) working state
- **AND** no per-position slice SHALL be allocated (memory per call SHALL NOT scale as O(n·w))

#### Scenario: cost is independent of window size

- **WHEN** `rolling_min` is evaluated with window w and again with window 2w over the same data
- **THEN** the per-row work SHALL remain amortized O(1) and total time SHALL remain O(n) in both cases

### Requirement: Rolling sum and mean are floating-point stable

The incremental running accumulator for `rolling_sum` and `rolling_mean` SHALL use compensated (Kahan/Neumaier) summation, or an equivalent drift-bounding strategy, so that results match a full per-window recomputation reference within accepted floating-point tolerance, including on mixed-sign and large-magnitude inputs.

#### Scenario: rolling_sum matches full-recompute reference on mixed-sign data

- **WHEN** `rolling_sum` is evaluated on a column of mixed-sign float64 values
- **THEN** each output SHALL equal the sum obtained by recomputing that window from scratch, within floating-point tolerance

### Requirement: Null and min_periods semantics are preserved

The linear rolling kernels SHALL preserve existing null handling and `min_periods` semantics: a running count of valid (non-null) observations SHALL be maintained, and a window with fewer valid observations than required SHALL produce a null result. Mean SHALL divide by the valid count.

#### Scenario: insufficient observations yields null

- **WHEN** a rolling window contains fewer non-null observations than the required minimum
- **THEN** the output for that position SHALL be null

#### Scenario: results equal the previous implementation

- **WHEN** any rolling op is evaluated via the new linear kernel and the previous O(n·w) implementation on the same data and parameters
- **THEN** the outputs SHALL be equal (within floating-point tolerance for sum/mean; exactly for min/max)
