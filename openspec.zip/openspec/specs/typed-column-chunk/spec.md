## Purpose

Defines requirements for the typed column chunk as the canonical primitive storage unit, replacing `[]any` with dense typed value buffers and validity masks.

## Requirements

### Requirement: Typed column chunk is canonical storage

The system SHALL store each primitive column as a `ColumnChunk` with a declared `dtypes.DataType`, a dense typed value buffer, and a validity mask indicating null positions.

#### Scenario: Create float64 chunk from slice

- **WHEN** code constructs a `ColumnChunk` from `[]float64` values and a validity mask of equal length
- **THEN** the chunk SHALL expose `Len()` equal to the input length and `ValueAt(i)` for non-null indices SHALL return the i-th float64 without heap boxing per element

#### Scenario: Null positions are readable

- **WHEN** validity marks index `j` as null
- **THEN** `IsNull(j)` SHALL be true and `ValueAt(j)` SHALL NOT require callers to read a boxed `nil` from `[]any`

### Requirement: Legacy any slice conversion is one-time at ingest

The system SHALL provide conversion from `[]any` input (existing `series.New`) into a typed `ColumnChunk` at construction time.

#### Scenario: series.New builds typed backing

- **WHEN** `series.New` is called with `dtypes.Int64` and a `[]any` of int64 values
- **THEN** the resulting series SHALL hold a typed `[]int64` (or equivalent) backing and SHALL NOT retain `[]any` as the canonical storage after construction completes

### Requirement: Supported primitive dtypes in chunk layer

The chunk layer MUST support at minimum: `Bool`, `Int64`, `Float64`, `String`, and temporal types mapped to `time.Time` or int64 epoch nanos as documented in `dtypes`.

#### Scenario: Unsupported dtype falls back to boxed storage

- **WHEN** a column dtype is struct, list, or other nested type
- **THEN** the system MAY use a boxed slow-path storage but SHALL NOT block primitive columns from using typed chunks

### Requirement: Chunk slice and gather without per-element boxing

The system SHALL implement `Slice(indices []int)` and `Filter(mask []bool)` on `ColumnChunk` producing a new chunk by copying or gathering typed values in bulk.

#### Scenario: Filter by boolean mask

- **WHEN** a bool mask of length N is applied to a float64 chunk of length N
- **THEN** the output chunk length SHALL equal the count of true mask bits and values SHALL preserve order of surviving indices

### Requirement: Chunk caches its null count

A `ColumnChunk` SHALL maintain a cached null count with an "unknown" sentinel. The count SHALL be computed lazily on first request and returned in constant time thereafter, and SHALL be reset to the unknown sentinel whenever the chunk's values or validity are mutated, sliced/gathered, aliased via a sub-range view, cloned, or concatenated.

#### Scenario: cached count returned without rescan

- **WHEN** the chunk's null count is requested twice without intervening mutation
- **THEN** the second request SHALL return the cached value without rescanning the validity mask

#### Scenario: count invalidated on mutation or aliasing

- **WHEN** a chunk is produced by slicing, gathering, shifting, sub-range viewing, cloning, or concatenating, or its validity is modified
- **THEN** the cached null count SHALL be the unknown sentinel until next computed, and the next computation SHALL equal a full validity scan

### Requirement: Chunk immutability and copy-on-write contract

A `ColumnChunk` SHALL be treated as immutable once it may be shared by more than one frame. Any operation that mutates a chunk's backing value buffer or validity mask in place SHALL first clone the chunk when it is shared, guaranteeing that read-only sharing of a chunk by multiple frames is safe and that a mutation through one owner does not change another owner's view.

#### Scenario: shared chunk is not mutated in place

- **WHEN** a chunk is shared by two frames and one frame performs an operation that would alter values in place
- **THEN** the operation SHALL act on a private clone, leaving the other frame's chunk unchanged

#### Scenario: gather and slice continue to allocate new chunks

- **WHEN** `Slice(indices)` or `Filter(mask)` is applied to a chunk
- **THEN** the result SHALL be a new chunk and the source chunk SHALL be unmodified
