## Purpose

Defines requirements for assembling join output via typed columnar gather, replacing per-cell boxing and per-row string key formatting with bulk typed operations.

## Requirements

### Requirement: Join output is materialized by typed column gather

Equi-join output SHALL be assembled by collecting matched `(leftIndex, rightIndex)` pairs and then materializing each output column once via a typed gather over the backing slices, without boxing each output cell into `interface{}` and without building an `[]any` per output row. Allocation for output assembly SHALL scale with the number of output columns plus the gathered index arrays, not with the number of output cells.

#### Scenario: inner join does not box per cell

- **WHEN** an inner join produces an R-row × C-column result
- **THEN** output assembly SHALL allocate on the order of C typed columns (plus index arrays), not R×C interface boxes

#### Scenario: outer join null-fills unmatched indices

- **WHEN** a left/right/full join leaves some side unmatched (sentinel index)
- **THEN** the gathered output column SHALL place a null at those positions

### Requirement: Join keys are built by typed hashing

The join build and probe phases SHALL derive keys by hashing the typed key-column backing slice (or a typed composite for multi-column keys), and SHALL NOT format each row's key via `fmt.Sprintf` or per-row string concatenation.

#### Scenario: int64 key join does not format strings per row

- **WHEN** a join is performed on an int64 key column
- **THEN** the key for each row SHALL be derived from the typed value without a per-row formatted string allocation

### Requirement: All join modes preserve results

The columnar output path SHALL produce identical rows (modulo documented ordering) and identical null-fill behavior as the prior implementation for inner, left, right, full, semi, anti, and cross joins.

#### Scenario: join results match the prior implementation

- **WHEN** any supported join mode is evaluated via the columnar path and the prior path on the same inputs
- **THEN** the set of output rows and their values SHALL be equal

#### Scenario: benchmark uses a high-cardinality key

- **WHEN** the `bench/top30` join benchmark runs
- **THEN** it SHALL join on a high-cardinality key (so output size is proportional to input) rather than a low-cardinality key that produces a cross-product explosion, and a `join` case at 1,000,000 rows SHALL complete
