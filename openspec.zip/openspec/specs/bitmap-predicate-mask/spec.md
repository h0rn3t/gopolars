## Purpose

Defines requirements for the packed-bitmap type used to represent predicate results across the system, including its allocation, pooling, popcount, and index-compression helpers in `pkg/simd`.

## Requirements

### Requirement: Predicate results are represented as packed uint64 bitmaps

The `pkg/simd` package SHALL define a `Bitmap` type (`type Bitmap []uint64`) where bit `i%64` of word `i/64` (LSB = bit 0) encodes whether row `i` survives a filter predicate. All comparison and mask-combination kernels SHALL return or accept `Bitmap` rather than `[]bool`.

#### Scenario: Bitmap encodes first 64 rows in one word

- **WHEN** rows 0, 2, and 63 match a predicate over a 64-row column
- **THEN** the returned `Bitmap` SHALL have length 1 and word 0 SHALL equal `(1<<0)|(1<<2)|(1<<63)`

#### Scenario: Bitmap length scales with row count

- **WHEN** a predicate is evaluated over N rows
- **THEN** the returned `Bitmap` SHALL have `(N+63)/64` words

#### Scenario: Partial last word has trailing bits zeroed

- **WHEN** a predicate is evaluated over N rows where N is not a multiple of 64
- **THEN** bits `N%64` through 63 of the last word SHALL be zero

### Requirement: BitmapNew allocates an exact-size zeroed bitmap

`simd.BitmapNew(n int) Bitmap` SHALL allocate a `Bitmap` of `(n+63)/64` words, all zero-initialized.

#### Scenario: BitmapNew returns correct length

- **WHEN** `BitmapNew(100)` is called
- **THEN** the returned Bitmap SHALL have length 2

#### Scenario: BitmapNew returns zero bits

- **WHEN** `BitmapNew(64)` is called
- **THEN** word 0 SHALL equal 0

### Requirement: BitmapPopcount returns the number of set bits

`simd.BitmapPopcount(b Bitmap, nRows int) int` SHALL return the count of set bits in positions 0..nRows-1, using `math/bits.OnesCount64` per word.

#### Scenario: Popcount on all-ones bitmap

- **WHEN** `BitmapPopcount` is called on a Bitmap where all nRows bits are set
- **THEN** the result SHALL equal nRows

#### Scenario: Popcount on empty bitmap

- **WHEN** `BitmapPopcount` is called on a Bitmap where no bits are set
- **THEN** the result SHALL equal 0

### Requirement: Bitmap scratch buffers are pooled for small sizes

The `pkg/simd` package SHALL maintain a `sync.Pool` that vends `Bitmap` buffers for sizes up to 1M rows (16 384 bytes / 2048 words). Callers SHALL call `BitmapRelease(b Bitmap)` to return a buffer to the pool; buffers exceeding the cap SHALL be silently dropped.

#### Scenario: BitmapAcquire + BitmapRelease produces no net heap allocation on repeated calls

- **WHEN** `BitmapAcquire(1_000_000)` and `BitmapRelease` are called in a tight loop
- **THEN** `go test -benchmem` SHALL report 0 B/op and 0 allocs/op after the first warm-up call

#### Scenario: Oversized buffers are not retained in the pool

- **WHEN** `BitmapRelease` is called on a Bitmap with cap > 2048 words
- **THEN** the buffer SHALL NOT be added to the pool (GC-eligible)

### Requirement: CompressIndices accepts Bitmap input

`simd.CompressIndices(mask Bitmap, nRows int) []int` SHALL produce the ascending-order slice of row indices where the corresponding bitmap bit is set, using `math/bits.TrailingZeros64` + bit-clear word-walk for efficient iteration.

#### Scenario: CompressIndices from bitmap matches byte-mask output

- **WHEN** the same predicate is evaluated and compressed via both the legacy `[]bool` path and the new Bitmap path
- **THEN** the resulting `[]int` slices SHALL be element-wise equal

#### Scenario: CompressIndices on all-zero bitmap returns empty slice

- **WHEN** the bitmap has no set bits
- **THEN** the returned slice SHALL have length 0 and SHALL NOT allocate beyond the slice header
