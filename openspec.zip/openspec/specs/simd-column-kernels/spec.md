## Purpose

Defines requirements for SIMD-accelerated column kernels that operate directly on typed buffers, supporting aggregation, comparison, and mask compression without `[]any` indirection.

## Requirements

### Requirement: SIMD kernels operate on typed buffers only

The `pkg/simd` package SHALL expose kernels that accept dense typed slices (`[]float64`, `[]int64`, `Bitmap` masks) and SHALL NOT require `[]any` inputs.

#### Scenario: Sum from float64 chunk

- **WHEN** aggregation requests sum over a float64 `ColumnChunk` with no nulls
- **THEN** the implementation SHALL pass the underlying `[]float64` slice directly to `simd.SumFloat64` or its generic fallback

### Requirement: Vectorized comparison kernels for filter masks

The system SHALL provide SIMD-accelerated (where build tags allow) element-wise comparison kernels that return a `simd.Bitmap` used by `Filter` and fused-reduce paths. The previous `[]bool` return type is replaced by `Bitmap` in all comparison kernel signatures.

#### Scenario: Greater-than mask on amd64 with simd build

- **WHEN** built with `GOEXPERIMENT=simd` on amd64 and comparing `[]float64` column to a literal threshold
- **THEN** the mask generation SHALL use `pkg/simd` comparison helpers and return a `Bitmap`

#### Scenario: Generic port without simd tag

- **WHEN** built without simd experiment or on non-amd64
- **THEN** the same comparison API SHALL produce an identical `Bitmap` using scalar loops

#### Scenario: Bitmap output matches legacy bool-mask semantics

- **WHEN** `CompareGTFloat64(vals, threshold)` is called
- **THEN** bit `i` of the returned `Bitmap` SHALL equal `vals[i] > threshold` for all i

### Requirement: Filter index compression kernel

The system SHALL provide `CompressIndices(mask Bitmap, nRows int) []int` that converts a `Bitmap` to ascending survivor indices. The previous `[]bool` input is replaced by `Bitmap`.

#### Scenario: Compress bitmap to indices

- **WHEN** a Bitmap with bits set at positions 0 and 2 (out of 3 rows) is compressed
- **THEN** the result indices SHALL be `[0,2]` in order

#### Scenario: Compression is equivalent to legacy []bool path

- **WHEN** the same predicate result is expressed as a legacy `[]bool` and as a `Bitmap`
- **THEN** `CompressIndices` on the `Bitmap` SHALL produce the same `[]int` as the legacy scalar loop

### Requirement: MaskedReduceFloat64 accepts Bitmap and uses branchless word-walk

`MaskedReduceFloat64(vals []float64, keep Bitmap, nulls []bool) (sum, min, max float64, count int)` SHALL replace the `[]bool keep` parameter with `Bitmap` and SHALL implement reduction via a word-at-a-time traversal using `math/bits.TrailingZeros64` + bit-clear (`x &= x-1`), accumulating only set-bit rows without per-row branch conditionals.

#### Scenario: Branchless reduction produces same result as branchy loop

- **WHEN** `MaskedReduceFloat64` is called with a 50%-selectivity Bitmap over 1M float64 rows
- **THEN** the returned sum SHALL equal the value produced by the previous `if !keep[i] { continue }` implementation (within float64 reduction-order tolerance)

#### Scenario: Word-walk skips zero words efficiently

- **WHEN** the Bitmap is sparse (popcount < 5% of rows)
- **THEN** `MaskedReduceFloat64` SHALL iterate only over non-zero words, not all N rows

#### Scenario: NaN/null semantics preserved

- **WHEN** the first surviving row value is NaN
- **THEN** min and max SHALL both be NaN (sticky-from-seed)

#### Scenario: Null rows excluded

- **WHEN** `nulls[i]` is true for a row whose bit is set in the Bitmap
- **THEN** that row SHALL be excluded from sum, min, max, and count

### Requirement: Index compression allocates exactly the result size

The mask-to-indices compression kernel SHALL allocate an output `[]int` whose capacity matches the number of set bits in the Bitmap, using `BitmapPopcount` for exact pre-sizing.

#### Scenario: Empty selectivity allocates no oversized index buffer

- **WHEN** `CompressIndices` is called on a Bitmap of N rows where zero bits are set
- **THEN** the returned slice SHALL have length 0 and SHALL NOT have pre-allocated capacity proportional to N

#### Scenario: Dense selectivity produces a correctly sized buffer

- **WHEN** `CompressIndices` is called on a Bitmap where K bits are set
- **THEN** the returned slice SHALL contain exactly K indices in ascending order

### Requirement: Document simd build requirements

The project SHALL document in `pkg/simd` and README that SIMD acceleration requires Go 1.26+ with `GOEXPERIMENT=simd` on amd64, and that correctness does not depend on SIMD being enabled.

#### Scenario: CI runs tests without simd

- **WHEN** CI runs default `go test ./...` without experiment tags
- **THEN** all tests SHALL pass using generic implementations

### Requirement: Reduce and compare kernels are vectorized on arm64

The `pkg/simd` package SHALL provide reduce (sum/min/max) and compare kernels that are vectorized on arm64 via compiler auto-vectorization of the generic implementation, so that non-amd64 platforms do not fall back to a purely scalar element-by-element loop in the hot path.

#### Scenario: Sum over float64 on arm64 is not purely scalar

- **WHEN** built and run on arm64 without `GOEXPERIMENT=simd`
- **THEN** `simd.SumFloat64` over a large `[]float64` SHALL execute a vectorized or auto-vectorized loop rather than a single-accumulator scalar loop

#### Scenario: Results are identical across architectures

- **WHEN** the same input is reduced or compared on amd64 and arm64
- **THEN** the numerical results SHALL be identical (within defined float reduction-order tolerance) and the bitmaps SHALL be bit-for-bit equal
