## Purpose

Defines requirements for zero-copy projection operations (Select, WithColumns, Rename) that share column buffers by pointer, and copy-on-write semantics to ensure safe mutation across shared frames.

## Requirements

### Requirement: Projection shares column buffers without copying

`DataFrame.Select`, `DataFrame.WithColumns`, and `Series.Rename` SHALL produce their result by sharing the existing `*chunk.Column` buffers of unchanged columns by pointer, and SHALL NOT copy the backing typed value buffers or validity masks of columns whose values are unchanged. The cost of these operations SHALL scale with the number of columns, not the number of rows.

#### Scenario: select does not copy backing buffers

- **WHEN** `Select` is called to project an existing column by name (no value transformation)
- **THEN** the resulting `Series` SHALL reference the same `*chunk.Column` as the source
- **AND** no allocation proportional to row count SHALL occur for that column

#### Scenario: rename is metadata-only

- **WHEN** `Series.Rename` is called
- **THEN** the returned `Series` SHALL share the source `*chunk.Column` and differ only in its name field
- **AND** the backing value buffer SHALL NOT be cloned

#### Scenario: with_columns reuses unchanged columns

- **WHEN** `WithColumns` adds or replaces a single column on a frame of C columns
- **THEN** the C−1 unchanged columns in the result SHALL reference the same `*chunk.Column` pointers as the source frame
- **AND** only the newly evaluated column SHALL be allocated

### Requirement: Columns are copy-on-write

A `*chunk.Column` shared across frames SHALL be treated as immutable; any operation that would mutate a column's backing buffer in place SHALL first clone the column when it is shared, so that mutating one frame never alters another frame that shares the buffer.

#### Scenario: mutation does not leak across shared frames

- **WHEN** frame B is derived from frame A via a projection that shares a column, and a subsequent operation mutates that column's values in B
- **THEN** the corresponding column in frame A SHALL retain its original values

#### Scenario: read-only sharing requires no copy

- **WHEN** multiple frames share a column and only read it
- **THEN** no defensive copy of the backing buffer SHALL be made
