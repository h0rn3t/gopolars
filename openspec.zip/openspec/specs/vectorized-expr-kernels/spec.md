## Purpose

Defines requirements for batch expression evaluation over entire columns, replacing per-row `expr.Eval` invocations with vectorized passes for supported primitive operations.

## Requirements

### Requirement: Batch expression evaluation for primitive operations

The system SHALL evaluate expression trees over entire columns in batch mode without invoking row-wise `expr.Eval` for supported expression kinds. The internal boolean result of predicate evaluation SHALL be represented as a `simd.Bitmap` rather than a `[]bool` slice.

#### Scenario: Filter uses batch Bitmap mask

- **WHEN** `DataFrame.Filter` receives a predicate composed only of supported primitive operations (column refs, literals, comparisons, and/or/not)
- **THEN** the engine SHALL compute a `simd.Bitmap` in one vectorized pass and SHALL NOT call `expr.Eval` per row index

#### Scenario: Unsupported predicate falls back to row-wise eval

- **WHEN** a predicate uses an unsupported operation (e.g. row-relative `reverse` access pattern)
- **THEN** the system SHALL fall back to row-wise `expr.Eval` and SHALL document the fallback in debug diagnostics when enabled

### Requirement: EvalBool returns a Bitmap

The `evalbatch.EvalBool` function (or equivalent internal entry point used by `filterBatch`) SHALL return a `simd.Bitmap` rather than a `[]bool` mask. All callers that previously received `[]bool` from `EvalBool` SHALL be updated to consume `Bitmap`.

#### Scenario: EvalBool Bitmap bit set for matching rows

- **WHEN** `EvalBool` is called on a predicate `col("a") > 5.0` over a float64 column
- **THEN** bit `i` of the returned Bitmap SHALL be set if and only if `col_a[i] > 5.0`

#### Scenario: EvalBool Bitmap length

- **WHEN** `EvalBool` is called over a column of height N
- **THEN** the returned Bitmap SHALL have `(N+63)/64` words

### Requirement: EvalBool does not allocate redundant mask and validity copies

When producing the boolean result of a predicate plan, the system SHALL NOT allocate fresh full-length `[]bool` mask and validity slices that duplicate buffers already held by the evaluated result chunk.

#### Scenario: Predicate over N rows allocates no duplicate N-length bool buffers

- **WHEN** a predicate plan is evaluated to a boolean result over a column of height N
- **THEN** the Bitmap result SHALL be produced without allocating two N-length `[]bool` slices for mask and validity separately

### Requirement: Batch predicate evaluation runs in parallel above a row threshold

The system SHALL evaluate a supported `Filter` predicate across multiple worker goroutines when the column height exceeds a parallelism threshold, partitioning rows into 64-bit-word-aligned contiguous chunks and producing a result Bitmap whose bits are identical to sequential evaluation.

#### Scenario: Large filter uses all available workers

- **WHEN** `DataFrame.Filter` receives a supported predicate over a column with height above the parallelism threshold
- **THEN** the batch evaluator SHALL distribute disjoint word-aligned row ranges across up to `GOMAXPROCS` workers
- **AND** the surviving rows SHALL appear at the same bitmap positions as a single-threaded evaluation

#### Scenario: Small filter stays sequential

- **WHEN** `DataFrame.Filter` receives a supported predicate over a column with height below the parallelism threshold
- **THEN** the evaluator SHALL run sequentially without spawning workers

#### Scenario: Parallel and sequential Bitmap results are identical

- **WHEN** the same supported predicate is evaluated over the same data with parallelism enabled and disabled
- **THEN** the resulting Bitmap SHALL be bit-for-bit equal, including null handling

### Requirement: WithColumns evaluates supported exprs to typed output chunk

The system SHALL implement batch evaluation for `WithColumns` when the expression plan is supported, materializing a typed `ColumnChunk` directly.

#### Scenario: Arithmetic with_columns on two float columns

- **WHEN** `WithColumns` adds `col("a") + col("b")` on float64 columns `a` and `b` of equal length
- **THEN** the result column SHALL be produced via vectorized float64 addition without constructing an intermediate `[]any` of length N

### Requirement: Expression plan is built once per operation

The system SHALL walk the expression AST once to build an execution plan reused for all rows in the batch.

#### Scenario: Column lookup happens once per column name

- **WHEN** a plan references column `x` ten times in nested expressions
- **THEN** the batch evaluator SHALL resolve the `x` chunk pointer once per evaluation, not once per row per reference

### Requirement: Public polars API behavior unchanged for supported inputs

For expressions and dtypes supported by batch kernels, results MUST match the semantics of the current row-wise evaluator (including null propagation rules).

#### Scenario: Null in comparison propagates

- **WHEN** either operand is null at index `i` in a comparison expression
- **THEN** the bitmap bit at `i` SHALL be 0 (row excluded), matching current `expr.Eval` null-filter semantics, as verified by conformance tests

### Requirement: Typed batch evaluation for cumulative, rank, window, and coalesce expressions

The system SHALL evaluate `cum_sum`, `fill_null`, `fill_nan`, `rank`, and `over` over typed column backing slices, writing typed output buffers, without producing one `interface{}` box per row or round-tripping the result through an `[]any` slice and `chunk.FromAny`. For any dtype not supported by the typed path, the system SHALL fall back to the existing row-wise `expr.Eval` and SHALL surface the fallback in debug diagnostics when enabled.

#### Scenario: cum_sum writes a typed output without boxing

- **WHEN** `cum_sum` is evaluated on a 1,000,000-row numeric column
- **THEN** the running total SHALL be written into a typed output buffer (e.g. `[]float64`)
- **AND** no `interface{}` box SHALL be allocated per row

#### Scenario: fill_null and fill_nan use a typed coalesce kernel

- **WHEN** `fill_null` (or `fill_nan`) with a literal replacement is evaluated on a primitive column
- **THEN** the operation SHALL be recognized by the batch evaluator (not routed to the row-wise fallback)
- **AND** the result SHALL be produced by a typed coalesce over the backing slice without per-row boxing

#### Scenario: rank uses a typed comparator

- **WHEN** `rank` is evaluated on a primitive column
- **THEN** ordering SHALL be computed via a typed argsort/comparator over the backing slice rather than a per-comparison `interface{}`-boxing comparator
- **AND** the output ranks SHALL be written into a typed buffer

#### Scenario: over uses a typed partition key

- **WHEN** `over` partitions by a primitive key column
- **THEN** partition assignment SHALL use a typed key (no `fmt.Sprintf` per row), and per-partition results SHALL be written without per-row boxing

#### Scenario: unsupported dtype still falls back

- **WHEN** any of these expressions is applied to a dtype with no typed kernel (e.g. nested/struct)
- **THEN** the system SHALL fall back to the row-wise path and produce correct results

#### Scenario: results match the row-wise path

- **WHEN** any of `cum_sum`, `fill_null`, `fill_nan`, `rank`, `over` is evaluated via the typed path and the row-wise fallback on the same data
- **THEN** the outputs SHALL be equal (within floating-point tolerance for floating-point results)

### Requirement: Fused filter-then-reduce evaluates in a single pass

For the pattern `filter(predicate).<reduce>()` where the predicate and reduction are supported, the system SHALL compute the reduction in a single masked pass over the source column without materializing an intermediate filtered column or building a surviving-index slice.

#### Scenario: filter(...).Sum() avoids materialization

- **WHEN** a supported predicate is followed by a `Sum` over a float64 column via the eager `FilterAggregateDirect` path
- **THEN** the engine SHALL call `MaskedReduceFloat64` with the Bitmap in one pass
- **AND** SHALL NOT allocate a compressed index slice nor a sliced output column for the filtered rows

#### Scenario: Fused result matches materialized result

- **WHEN** the fused path computes a reduction over a filtered column
- **THEN** the result SHALL equal the value obtained by materializing the filtered column and reducing it, including null and NaN handling
