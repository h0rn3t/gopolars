## ADDED Requirements

### Requirement: No dead packages or orphaned build files

The repository SHALL NOT ship Go packages, exported symbols, or build/lock files that have zero references from production code, examples, or documentation.

#### Scenario: Unused package is absent

- **WHEN** the codebase is searched for importers of `github.com/h0rn3t/gopolars/pkg/cache`
- **THEN** no production, test, example, or bench file imports it AND the `pkg/cache` directory does not exist

#### Scenario: Orphaned lockfile is absent

- **WHEN** the repository root is inspected for `go.work.sum`
- **THEN** the file is absent because no `go.work` file exists to require it

#### Scenario: Test-only export is removed

- **WHEN** the codebase is searched for `WindowSum` / `WindowSumInput`
- **THEN** the symbols are absent AND no non-test code referenced them before removal

### Requirement: Execution runs operators without indirection-only layers

The lazy execution path SHALL produce results directly from the logical plan without an intermediate layer whose only behavior is to copy or re-wrap nodes. Removing such a layer SHALL NOT change query results.

#### Scenario: Same query, same result after collapsing the physical layer

- **WHEN** any lazy query that previously flowed through `pkg/plan/physical` and `pkg/exec/scheduler` is collected before and after the refactor
- **THEN** the resulting DataFrame (schema, row order, and values) is identical

#### Scenario: Engine consumes logical nodes directly

- **WHEN** the execution engine is invoked
- **THEN** it operates on `[]logical.Node` without constructing a separate `physical.Operator` mapping or routing through a single-implementation scheduler wrapper

### Requirement: Public API and observable behavior are unchanged

The change SHALL remove no exported symbol that is referenced by examples, documentation, or downstream consumers, and SHALL keep all query results and benchmark characteristics unchanged.

#### Scenario: Public IO surface preserved

- **WHEN** `examples/parquet_scan` and `examples/lazy_pushdown` are built
- **THEN** `polars.NewIO()` and the `IO` interface still exist and compile unchanged

#### Scenario: Full test suite stays green

- **WHEN** `go test ./...` runs after the refactor
- **THEN** all previously passing tests still pass with no behavioral assertions changed

#### Scenario: Internal trivial helper is inlined without effect

- **WHEN** code that previously called `simd.CountFloat64(vals)` or `parseCondition(...)` executes
- **THEN** it returns the identical value via `int64(len(vals))` / `parseExpression(...)` respectively
