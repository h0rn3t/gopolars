## Why

A repo-wide over-engineering audit (ponytail-audit) found ~400 lines of dead code, orphaned lockfiles, and indirection-only internal layers that add maintenance cost and 3am-debugging surface without buying anything. Cutting them now — before they grow more callers — keeps the engine lean while the public API and all query results stay identical.

## What Changes

Behavior-preserving internal cleanup only. **No public API change** (verified: `polars.NewIO`, the `IO` interface, `expr.go` re-exports and case-aliases are user-facing and explicitly OUT of scope).

- **Remove dead `pkg/cache` package** — `chunk_cache.go`, `plan_cache.go`, `cache_test.go`. Zero importers anywhere (verified).
- **Remove orphaned `go.work.sum`** — no `go.work` file exists; the lockfile is dead.
- **Remove `WindowSum` + `WindowSumInput`** from `pkg/polars/analytics.go` — exported but only ever called from tests, never from production or examples.
- **Remove unused `Chunk` struct** in `pkg/series/chunk.go` — no referencing code.
- **Remove `simd.CountFloat64`** — it is literally `int64(len(vals))`; replace internal call sites with the builtin.
- **Inline `parseCondition`** in `pkg/sql/parser.go` — a 3-line passthrough to `parseExpression`.
- **Collapse the indirection-only execution scheduler** (`pkg/exec/scheduler.go`) — a single-implementation wrapper around a synchronous operator loop; fold into the engine.
- **Collapse the `pkg/plan/physical` layer** — `Operator`/`Build()` only map `logical.Node` → `Operator`; have the engine consume `[]logical.Node` directly (rewires 3 call sites: `pkg/exec/scheduler.go`, `pkg/exec/engine.go`, `pkg/polars/lazyframe.go`).
- **Untrack `bench.txt`** — tracked transient benchmark output; add to `.gitignore`.

Explicitly **excluded** (public API / ergonomics, per chosen scope): `pkg/polars/io.go` IO interface + `NewIO`, `pkg/polars/expr.go` re-exports, case-only aliases (`Sql`, `WriteCsv`, `Vstack`, …), the unary-math/rolling method shrink.

## Capabilities

### New Capabilities
- `lean-internal-surface`: The library carries no dead packages, orphaned lockfiles, or indirection-only internal layers; execution runs operators directly while public API and query results remain byte-for-byte unchanged.

### Modified Capabilities
<!-- None. No existing capability's requirements change; this is a behavior-preserving removal. -->

## Impact

- **Code removed/changed**: `pkg/cache/*` (deleted), `go.work.sum` (deleted), `pkg/polars/analytics.go` (WindowSum gone), `pkg/series/chunk.go` (Chunk gone), `pkg/simd/*` (CountFloat64 gone), `pkg/sql/parser.go` (parseCondition inlined), `pkg/exec/{scheduler,engine}.go` + `pkg/plan/physical/*` (layer folded), `pkg/polars/lazyframe.go` (call site rewired), `bench.txt` + `.gitignore`.
- **APIs**: No public/exported API used by examples, docs, or downstream is removed. `WindowSum` is exported but test-only — removal is the only nominal export change; not part of the documented parity surface.
- **Dependencies**: None added or removed (all 4 direct deps remain in use).
- **Tests/CI**: Full `go test ./...` and the benchmark suite must stay green; query results and benchmark numbers unchanged are the acceptance gate.
- **Net**: ~-395 lines, -1 tracked file.
