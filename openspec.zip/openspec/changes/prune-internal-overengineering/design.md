## Context

A ponytail over-engineering audit of gopolars surfaced dead code and indirection-only layers. This change executes the **safe subset** (dead code + internal yagni; public API untouched). Two items need real rewiring rather than plain deletion — the execution scheduler and the `pkg/plan/physical` layer — so they get design attention here. Everything else is a straight delete/inline.

Verified facts driving the design:
- `pkg/plan/physical.Build([]logical.Node) Plan` wraps each node in `Operator{Node}` — an **identity** transform. The only consumers are `pkg/exec/engine.go:88`, `pkg/exec/scheduler.go`, and `pkg/polars/lazyframe.go:656` (Explain), the last of which immediately unwraps `.Operators` back to `[]logical.Node`.
- `pkg/exec.Scheduler.Run` (`scheduler.go:17`) spawns a goroutine per operator but blocks on `<-done` each iteration — it is **already sequential**, not parallel.
- `pkg/cache` has zero importers; `go.work.sum` has no `go.work`; `WindowSum` has only test callers; `simd.CountFloat64` is `int64(len(vals))`; `parseCondition` is a passthrough to `parseExpression`.

## Goals / Non-Goals

**Goals:**
- Remove ~395 lines of dead/redundant internal surface with zero change to query results, public API, or benchmark numbers.
- Keep `go build ./...`, `go vet ./...`, `golangci-lint`, and `go test ./...` green at every step.

**Non-Goals:**
- No public API changes: `polars.NewIO`/`IO`, `expr.go` re-exports, case-aliases, and the unary-math/rolling method shrink stay.
- No behavioral or performance change. This is not the place to make execution actually parallel — only to remove the layer that pretends to be.
- No dependency changes.

## Decisions

**1. Collapse the scheduler into a plain loop (over alternatives: keep it, or make it truly parallel).**
Replace `scheduler.Run(physicalPlan, fn)` in `executeOptimized` with a `for _, n := range optimized { switch n.Type {...} }` loop, inlining the existing closure body (it mutates a captured `current` local — a loop body does the same). Delete `pkg/exec/scheduler.go`. Rationale: the scheduler is a single-implementation wrapper whose goroutine is immediately joined, so the loop is provably identical. Making it genuinely parallel is out of scope and would be unsafe (operators are sequentially data-dependent via `current`).

**2. Delete `pkg/plan/physical`; engine and Explain use `[]logical.Node` directly (over: keep as a future hook).**
Since `Build` is identity, `engine.go` iterates `optimized` directly, and `lazyframe.go` Explain replaces the build+unwrap (lines 656-661) with `physicalStage := renderStage(optimizedNodes)`. The "physical" line in `Explain` output is byte-identical because the mapping was identity. Drop the `physical` import in all three files. Rationale: a layer with one identity implementation and one indirection caller is the textbook yagni; logical nodes are the real plan.

**3. Straight deletes/inlines for the rest.**
`pkg/cache/` (whole dir), `go.work.sum`, `WindowSum`+`WindowSumInput`, `pkg/series/chunk.go` `Chunk`, `simd.CountFloat64` (replace internal callers with `int64(len(...))`), `parseCondition` (inline its one call). `bench.txt` → `git rm --cached` + add to `.gitignore`.

**4. Sequencing: zero-risk deletes first, rewiring last.**
Order tasks so the suite stays green incrementally and a rewiring problem can't block the trivial wins.

## Risks / Trade-offs

- **[Hidden non-test caller of a "dead" symbol]** → Before each delete, `rg` the symbol across the whole repo (incl. examples, bench, scripts). `go build ./...` after each removal is the backstop.
- **[Explain output drift after removing physical layer]** → A test asserts the `physical=[...]` segment equals the pre-refactor string for a sample plan; since `Build` is identity this must hold.
- **[Scheduler removal changes error propagation/ordering]** → The loop preserves first-error-wins short-circuit and operator order exactly; covered by the existing lazy-collect tests.
- **[`go.work.sum` was load-bearing for a workspace build]** → Confirmed no `go.work` exists; `go build ./...` after removal proves it.
- **[CountFloat64 used with overflow expectations]** → It already returned `int64(len)`; the inline is identical, no semantic change.

## Migration Plan

No runtime migration — internal only. Rollback is `git revert` of the change commit. Acceptance gate: `go build ./... && go vet ./... && go test ./...` green, plus the benchmark suite showing unchanged numbers within noise.

## Open Questions

- None blocking. If `WindowSum`'s test-only removal is undesirable (it is exported), it can be dropped from the task list without affecting any other task — it has no dependents.
