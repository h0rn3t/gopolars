## ADDED Requirements

### Requirement: AVX2-accelerated float64 kernels with runtime dispatch

On `amd64`, `pkg/simd` SHALL provide AVX2 hand-written assembly implementations of `MinFloat64`, `MaxFloat64`, `MinMaxFloat64`, `AddSlicesFloat64`, and `MulSlicesFloat64`, selected at runtime when the CPU reports AVX2 support (`golang.org/x/sys/cpu` `cpu.X86.HasAVX2`). When AVX2 is absent, or on any non-`amd64` architecture, the kernels SHALL fall back to the existing scalar multi-accumulator implementation. Selection SHALL NOT require a build tag.

#### Scenario: AVX2 path on a capable amd64 CPU

- **WHEN** built for `amd64` and run on a CPU reporting `HasAVX2 == true`
- **THEN** `MinFloat64` and the other four kernels SHALL execute the AVX2 assembly path

#### Scenario: Scalar fallback without AVX2

- **WHEN** `cpu.X86.HasAVX2 == false` (older amd64) or the build target is not `amd64`
- **THEN** the same exported functions SHALL run the scalar multi-accumulator implementation and return identical results

#### Scenario: No build tag required

- **WHEN** the package is built with the default `go build` flags (no `-tags simd`)
- **THEN** the AVX2 path SHALL still be reachable at runtime on a capable amd64 CPU

### Requirement: AVX2 kernels produce results identical to the scalar path

The AVX2 implementations SHALL return results bit-identical to the scalar multi-accumulator kernels for every input, including empty, short (below one vector width), NaN, all-NaN, +0.0/-0.0, and mismatched-length (add/mul) inputs. Reduction NaN handling SHALL match the scalar rule: a NaN seed is sticky and a later NaN does not displace a non-NaN running extreme. Where AVX2 `VMINPD`/`VMAXPD` NaN/zero semantics differ from the scalar `<`/`>` comparison, the kernel SHALL reconcile so the externally observed result is identical.

#### Scenario: NaN and all-NaN reductions match scalar

- **WHEN** `MinFloat64`, `MaxFloat64`, and `MinMaxFloat64` are run over a slice with a leading NaN, a trailing NaN, and an all-NaN slice
- **THEN** each AVX2 result SHALL equal the scalar kernel's result for the same input

#### Scenario: Element-wise results match scalar

- **WHEN** `AddSlicesFloat64(a, b)` and `MulSlicesFloat64(a, b)` are run on 1M-element inputs (including a mismatched-length pair)
- **THEN** the result length SHALL be `min(len(a), len(b))` and `result[i]` SHALL equal `a[i]+b[i]` / `a[i]*b[i]` for every in-range `i`, identical to the scalar loop

#### Scenario: Tail handling below vector width

- **WHEN** a kernel is called with a length that is not a multiple of the AVX2 vector width (4 float64) or is shorter than one vector
- **THEN** the remainder SHALL be processed by a scalar tail and the result SHALL equal the scalar kernel

### Requirement: AVX2 correctness is verified before the kernel is trusted

The change SHALL include an equivalence test that runs each AVX2 kernel against the scalar kernel over the input classes above, and this test SHALL pass on an `amd64` execution environment (Rosetta 2 locally for correctness; the reference amd64 host for performance) before the AVX2 path is relied upon.

#### Scenario: Equivalence suite passes on amd64

- **WHEN** `go test ./pkg/simd/...` is run on an AVX2-capable amd64 environment (including under Rosetta 2)
- **THEN** the AVX2-vs-scalar equivalence test SHALL pass for all input classes
