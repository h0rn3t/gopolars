## Context

`BenchmarkCross` calls the `pkg/simd` kernels directly on a pre-materialized `[]float64`. At 1M elements the scalar generic kernels lose to NumPy/Polars (`min`/`max` Py ×2.1, `minmax` ×1.2, `add`/`mul` ×1.4–1.5). The scalar reductions are already multi-accumulator and single-threaded (~29 GB/s, under L3 bandwidth) — the remaining gap needs wide vector instructions.

Hardware reality that shapes this design:
- **Dev box is `arm64`** (Apple Silicon, Go 1.26.4). AVX2 is amd64-only, so the kernels cannot run natively here. Rosetta 2 is installed and (macOS 26) supports AVX2, so it is used for **correctness** only; performance is measured on the reference amd64 host (EPYC 7763, Zen 3: AVX2 yes, AVX-512 no).
- `golang.org/x/sys` is already an (indirect) dependency → `cpu.X86.HasAVX2` is available with no new module.
- `github.com/atul-007/turboslice` is imported by exactly one file (`simd_amd64.go`), so it can be retired cleanly.

Current build-tag layout:
- `simd_amd64.go` — `//go:build amd64 && simd` (turboslice; never built by default)
- `simd_generic.go` — `//go:build !amd64 || !simd` (the path actually compiled everywhere today)

## Goals / Non-Goals

**Goals:**
- AVX2 `min`/`max`/`minmax`/`add`/`mul` for float64 on amd64, reachable under plain `go build` (runtime CPU detection, no build tag).
- Results bit-identical to the scalar kernels for all inputs (empty, short, NaN, all-NaN, ±0, mismatched lengths).
- No public API change, no new module, scalar fallback on non-AVX2 / non-amd64.

**Non-Goals:**
- AVX-512 (absent on the reference Zen 3 host) and NEON/arm64 SIMD (dev box stays on the scalar path).
- NumCPU parallelism (documented secondary lever; add later only if a single-core AVX2 kernel still misses parity).
- Touching the `Series` facade `[]any` boxing / double-materialization (separate follow-up; the benchmark measures kernels).

## Decisions

### Decision: Hand-written Plan9 AVX2 assembly, runtime-dispatched

Write `pkg/simd/reduce_amd64.s` and `arith_amd64.s` using Go's assembler AVX2 mnemonics (`VMOVUPD`, `VMINPD`, `VMAXPD`, `VADDPD`, `VMULPD`, `VBROADCASTSD`), declared `//go:noescape` from `kernels_amd64.go`. Each reduction uses **4 independent YMM accumulators** (4 float64 each = 16 elements/iteration) to break the dependency chain, then a horizontal reduce + scalar tail. Element-wise kernels stream 16 elements/iteration into the pre-allocated output, with a scalar tail.

- **Why asm over `simd/archsimd` (goexperiment.simd):** archsimd in Go 1.26 is experimental, gated behind `goexperiment.simd`, and (as turboslice shows) only exposes 128-bit lanes today — half the width we need. Plan9 asm gives full 256-bit AVX2 unconditionally on amd64.
- **Why asm over relying on the compiler:** the Go compiler does auto-vectorize simple float64 `add`/`mul` loops (which is exactly why turboslice keeps them scalar), but it is conservative about reduction reassociation and compare-select, so `min`/`max`/`minmax` are left scalar — those are the biggest losers and the clearest asm wins. `add`/`mul` asm is included for symmetry but kept only if measured to beat the compiler's auto-vec on the reference host (see Risks).

### Decision: Runtime dispatch with no build tag; retire turboslice

New `kernels_amd64.go` (`//go:build amd64`) holds the exported funcs; at package init it reads `cpu.X86.HasAVX2` into a bool and each exported func branches AVX2-asm vs scalar. The scalar bodies move from `simd_generic.go` into a tag-neutral `scalar.go` (unexported `minFloat64Scalar`, …) shared by both amd64-fallback and the non-amd64 build. `simd_generic.go` is retagged `//go:build !amd64` and simply re-exports the scalar bodies. `simd_amd64.go` and the turboslice dep are deleted.

- **Why no `-tags simd`:** the current tag gate is why the accelerated path never shipped. Runtime detection makes AVX2 the default on capable hardware and degrades safely on old amd64 — one binary, correct everywhere.

Target file layout:
```
scalar.go          // (no build tag) minFloat64Scalar, maxFloat64Scalar, ... — moved from simd_generic.go
simd_generic.go    // //go:build !amd64  — exports MinFloat64 etc. = the scalar bodies
kernels_amd64.go   // //go:build amd64   — exports MinFloat64 etc. = HasAVX2 ? asm : scalar
reduce_amd64.s     // AVX2 min/max/minmax
arith_amd64.s      // AVX2 add/mul
// simd_amd64.go (turboslice) DELETED
```

### Decision: Reconcile AVX2 NaN / signed-zero semantics to the scalar result

`VMINPD(a,b)`/`VMAXPD(a,b)` return the **second** operand when either input is NaN and for ±0 ties — which differs from the scalar `if v < m { m = v }` (NaN compares false, so the running extreme is kept; seed NaN is sticky). To stay bit-identical, the reduction kernels either (a) order operands and add a per-vector NaN self-compare + blend, or (b) detect "any NaN present" cheaply and, if so, fall back to the scalar kernel for that call. Approach chosen during apply based on cost, validated by the equivalence test.

- **Why this matters:** it is the single highest-risk correctness point in hand-written SIMD min/max. The product facade (`numericValues(true)`) already strips NaN before calling the kernel, so the common path is NaN-free — making option (b) (NaN-present → scalar fallback) cheap and safe, with the asm fast path covering the overwhelmingly common NaN-free input.

## Risks / Trade-offs

- **Cannot benchmark AVX2 natively on the arm64 dev box** → correctness via Rosetta 2 (`GOARCH=amd64 go test`), performance via the reference amd64 host; Rosetta timings explicitly treated as non-representative.
- **AVX2 NaN/±0 divergence from scalar** → reconcile (blend) or NaN-present scalar fallback; locked down by an AVX2-vs-scalar equivalence test over NaN/all-NaN/±0/short inputs run under Rosetta before the path is trusted.
- **`add`/`mul` may not beat the compiler's auto-vectorized scalar loop on Zen 3** → keep the asm only if the re-baseline shows a win; otherwise leave `add`/`mul` on the (already auto-vectorized) scalar path and ship only the reduction kernels. Decision is measurement-driven, not assumed.
- **Hand-written asm maintenance cost** → confined to two `.s` files behind stable Go signatures, with the scalar path as the always-correct reference the equivalence test pins to.

## Migration Plan

1. Extract scalar bodies to `scalar.go`; retag `simd_generic.go` to `!amd64`.
2. Add `kernels_amd64.go` dispatch (HasAVX2) wired to scalar fallback first (no asm yet) — confirm the package still builds and tests green on amd64 (Rosetta) and arm64.
3. Add `reduce_amd64.s` (min/max/minmax), then `arith_amd64.s` (add/mul), wiring each into the dispatch.
4. Add the AVX2-vs-scalar equivalence test; run `GOARCH=amd64 go test ./pkg/simd/...` under Rosetta until green.
5. Delete `simd_amd64.go`; drop turboslice from go.mod (`go mod tidy`); promote `golang.org/x/sys` to direct.
6. Re-baseline on the reference amd64 host; update `bench/cross/cross_summary.{json,md}` and parity budgets; drop `add`/`mul` asm if it shows no win.

Rollback: the change sits behind a runtime flag and stable signatures — reverting `kernels_amd64.go` to call only the scalar bodies (and restoring `simd_generic.go`'s tag) returns to today's behavior with no API impact.

## Open Questions

- NaN reconciliation approach — blend vs NaN-present scalar fallback — decided in apply step 3/4 by cost under the equivalence test.
- Whether `add`/`mul` asm survives the re-baseline or is dropped in favor of the compiler's auto-vec — decided in step 6.
- Exact unroll factor (4 YMM vs 8) — tuned on the reference host; 4 is the starting point.
