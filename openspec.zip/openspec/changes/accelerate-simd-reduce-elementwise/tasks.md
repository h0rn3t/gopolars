## 1. Restructure build tags (scalar stays correct everywhere)

- [x] 1.1 Move the scalar multi-accumulator bodies out of `simd_generic.go` into a tag-neutral `pkg/simd/scalar.go` as unexported `minFloat64Scalar`/`maxFloat64Scalar`/`minMaxFloat64Scalar`/`addSlicesFloat64Scalar`/`mulSlicesFloat64Scalar` (and `sumFloat64Scalar`/`dotProductFloat64Scalar` to replace turboslice)
- [x] 1.2 Retag `simd_generic.go` to `//go:build !amd64`; have it export `MinFloat64` etc. as thin wrappers over the scalar bodies
- [x] 1.3 Confirm `go build ./...` and `go test ./pkg/simd/...` still pass on arm64 (no behavior change yet)

## 2. amd64 runtime dispatch (fallback first, no asm yet)

- [x] 2.1 Add `kernels_amd64.go` (`//go:build amd64`) with a package-level `hasAVX2 = cpu.X86.HasAVX2` and exported `MinFloat64` etc. that branch `hasAVX2 ? avx2 : scalar` — wire ALL branches to the scalar bodies for now
- [x] 2.2 Promote `golang.org/x/sys` to a direct dependency; `go build` for `GOARCH=amd64`
- [x] 2.3 Verify under Rosetta: `GOARCH=amd64 go test ./pkg/simd/...` passes (still scalar, proves the dispatch + Rosetta toolchain work)

## 3. AVX2 reduction kernels

- [x] 3.1 Write `reduce_amd64.s`: `minFloat64AVX2`/`maxFloat64AVX2` — 4 YMM accumulators (`VMINPD`/`VMAXPD`), horizontal reduce, scalar tail; `//go:noescape` stubs in `kernels_amd64.go`
- [x] 3.2 Write `minMaxFloat64AVX2` (min+max accumulators in one pass)
- [x] 3.3 Handle NaN/±0: implement reconciliation (blend) OR NaN-present scalar fallback so results match `*Scalar` exactly; wire the three reductions to the AVX2 path when `hasAVX2`

## 4. AVX2 element-wise kernels

- [x] 4.1 Write `arith_amd64.s`: `addSlicesFloat64AVX2`/`mulSlicesFloat64AVX2` (`VADDPD`/`VMULPD`), 16 elements/iter into the pre-allocated dst, scalar tail
- [x] 4.2 Wire `AddSlicesFloat64`/`MulSlicesFloat64` to the AVX2 path; result len = `min(len(a),len(b))`

## 5. Correctness (Rosetta-gated)

- [x] 5.1 Add an AVX2-vs-scalar equivalence test in `pkg/simd` covering empty, sub-vector, non-multiple-of-4, 1M, NaN (leading/trailing), all-NaN, ±0, and mismatched-length (add/mul) inputs
- [x] 5.2 `GOARCH=amd64 go test ./pkg/simd/...` green under Rosetta; then full `go test ./...` on arm64 (scalar path) green
- [x] 5.3 Delete `simd_amd64.go`; `go mod tidy` to drop `github.com/atul-007/turboslice`; confirm nothing else imports it

## 6. Re-baseline on the reference amd64 host

- [x] 6.1 Run `BenchmarkCross` for `min`/`max`/`minmax`/`add`/`mul` on the reference amd64 host (AVX2) — via parity-nightly on ubuntu-latest (EPYC 7763): min 272→100µs, max 273→~101µs, minmax 315→100µs (Go now beats Polars ~1.7-3x); add/mul stayed memory-bound and noise-dominated
- [x] 6.2 add/mul AVX2 measured ~2.5x slower than the auto-vectorized scalar on EPYC (memory-bound); dropped arith_amd64.s, kept add/mul scalar
- [~] 6.3 Parity gate passed on CI with the new code (no budget regression — nothing to change). cross_summary.{json,md} are harness-generated ("do not edit by hand") and both Go/Polars samples vary ~2x run-to-run at the workflow's `-count=1`, so they are left for the parity-nightly harness to refresh rather than hand-edited with noisy singles.
