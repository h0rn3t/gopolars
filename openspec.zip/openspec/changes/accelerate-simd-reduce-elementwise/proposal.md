## Why

A fresh cross-language run at the 1,000,000-element reference scale shows the `pkg/simd` reduction and element-wise kernels — which `BenchmarkCross` measures directly and which the `Series` reduction/arithmetic surface calls — losing to Python (NumPy/Polars) on the five hottest numeric ops:

| op | Go | Py | result | Go throughput |
|----|------|------|--------|------|
| `min` | 272.18 µs | 128.95 µs | **Py ×2.1** | 29.4 GB/s |
| `max` | 272.63 µs | 129.50 µs | **Py ×2.1** | 29.3 GB/s |
| `minmax` | 315.20 µs | 259.25 µs | Py ×1.2 | 25.4 GB/s |
| `add` | 324.80 µs | 229.94 µs | Py ×1.4 | 49.3 GB/s |
| `mul` | 325.19 µs | 221.88 µs | Py ×1.5 | 49.2 GB/s |

The path actually compiled is the scalar `simd_generic.go`. Its reductions are already multi-accumulator and single-threaded, topping out near 29 GB/s — below L3 bandwidth, so there is real compute headroom that only vector instructions can reach. The existing amd64 escape hatch is a dead end: `simd_amd64.go` delegates to `github.com/atul-007/turboslice`, which (a) is reached only under `-tags simd` that no build sets, (b) needs `goexperiment.simd` and only widens to 128-bit (2 float64 lanes), and (c) keeps `add`/`sum`/`dot` scalar by design. NumPy/Polars win because they run true wide-SIMD (AVX2, 4 float64 lanes) min/max/compare. The reference host (EPYC 7763, Zen 3) has AVX2 but not AVX-512, so AVX2 is the right and sufficient target.

## What Changes

- **Hand-written AVX2 assembly kernels** for `MinFloat64`, `MaxFloat64`, `MinMaxFloat64`, `AddSlicesFloat64`, `MulSlicesFloat64` in `pkg/simd`: 256-bit `VMINPD`/`VMAXPD`/`VADDPD`/`VMULPD` over 4 independent YMM accumulators (16 float64/iteration), with a scalar tail for the remainder.
- **Runtime dispatch, no build tag**: the exported amd64 functions select the AVX2 path when `cpu.X86.HasAVX2` is true and fall back to the current scalar multi-accumulator kernel otherwise. The AVX2 path is reachable under a plain `go build` — no `-tags simd`, no `goexperiment`.
- **Retire the turboslice integration**: `simd_amd64.go` (its only importer) is replaced by the native AVX2 + scalar-fallback amd64 path; the `github.com/atul-007/turboslice` dependency is dropped.
- **Scalar implementations become the shared fallback**: the existing multi-accumulator code moves to a build-tag-neutral file so both the non-amd64 build and the amd64-without-AVX2 fallback call it; results are unchanged.
- **NaN/zero reconciliation**: because `VMINPD`/`VMAXPD` NaN and signed-zero semantics differ from the scalar `<`/`>`, the reduction kernels reconcile so externally observed results stay bit-identical to the scalar path. Covered by an AVX2-vs-scalar equivalence test over empty/short/NaN/all-NaN/±0 inputs.
- **Verification under Rosetta 2 locally, re-baseline on amd64 host**: correctness is validated by running the amd64 test binary under Rosetta 2 on the dev machine; performance numbers and `bench/cross/cross_summary.{json,md}` + tracked parity budgets are re-seeded from the reference amd64 host (Rosetta timings are not representative).
- **Parallelism deferred**: NumCPU chunking remains a documented secondary lever, to be layered on later only if a single-core AVX2 kernel still misses parity on an op.

No public API change. `simd.MinFloat64` and the other four keep their signatures and observable results; only the amd64 execution path changes.

## Capabilities

### New Capabilities

- `avx2-float64-kernels`: On amd64, `pkg/simd` runs AVX2 assembly implementations of `MinFloat64`/`MaxFloat64`/`MinMaxFloat64`/`AddSlicesFloat64`/`MulSlicesFloat64` selected at runtime via `cpu.X86.HasAVX2` (no build tag), falling back to the scalar multi-accumulator kernel on non-AVX2 amd64 and on other architectures, and returning results bit-identical to the scalar path — including NaN, all-NaN, ±0, short, and mismatched-length inputs.

### Modified Capabilities

<!-- None. simd-column-kernels defines the typed-buffer kernel surface and its observable result semantics, which are unchanged — this change swaps the amd64 implementation behind those same signatures and adds the runtime-dispatch capability. No existing requirement's behavior changes. -->

## Impact

- **Code**: new `pkg/simd/*_amd64.s` (AVX2 asm) + `kernels_amd64.go` (runtime dispatch); `simd_generic.go` retagged to non-amd64 with the scalar bodies extracted to a shared file; `simd_amd64.go` (turboslice) removed.
- **Dependencies**: drop `github.com/atul-007/turboslice`; promote `golang.org/x/sys` (already present, indirect) to a direct dependency for `cpu`.
- **Callers**: `Series.Min`/`Max`/`MinMax`-equivalents and `Series.Add`/`Mul` (`pkg/polars/series.go`) benefit transparently — no call-site changes.
- **Benchmarks/baselines**: `bench/cross/cross_summary.{json,md}` and tracked parity budgets for the five ops re-seeded from the reference amd64 run.
- **Risk**: hand-written asm cannot be benchmarked natively on this arm64 dev box (AVX2 is amd64-only); correctness is gated behind the Rosetta 2 equivalence run, performance behind the amd64 host re-baseline.
