## Why

The two prior performance changes (`close-polars-benchmark-gap`/`performance-parity-all-workloads` removed per-row boxing and added a parallel gather; `close-polars-time-gaps` parallelized `group_by` and `sort` and added radix `rank`) closed most of the allocation gap. But a freshly captured cross-language run at the **1,000,000-row reference scale** still shows Python Polars winning the DataFrame surface where its multi-threaded engine has no Go equivalent yet:

| op | Go time | Go B/op | allocs | Py time | result |
|----|---------|---------|--------|---------|--------|
| `drop_nulls` 1M | 43.9 ms | 49.6 MB | 20 | 1.36 ms | **Py ×32.4** |
| `filter` 1M | 5.81 ms | 25.1 MB | 112 | 564 µs | **Py ×10.3** |
| `join` 1M | 47.4 ms | 122 MB | 2120 | 6.40 ms | **Py ×7.4** |
| `unique` 1M | 16.4 ms | 7.6 MB | 24 | 4.92 ms | **Py ×3.3** |
| `sort` 1M | 35.9 ms | 68.1 MB | 78 | 12.7 ms | **Py ×2.8** |
| `head`/`tail` (any size) | ~1.6 µs | 7.2 KB | ~19 | ~0.6 µs | **Py ×2.5–3.7** |
| `group_by` 1M | 2.08 ms | 92.8 KB | 187 | 1.50 ms | Py ×1.4 |
| `fill_null` 1M | 1.16 ms | 8.6 MB | 9 | 871 µs | Py ×1.3 |

Two root causes account for nearly all of it, and neither prior change touched them: (1) the equi-`join` core is still **fully single-threaded** — a `map[string][]int` built with a per-row `string(scratch)` key allocation, a serial probe, and a serial per-column `Gather` — which is both the slowest workload and the heaviest (122 MB / 2120 allocs); and (2) `head`/`tail`/`limit` pay a **fixed per-call materialization cost** (~19 allocs, 7.2 KB) independent of how few rows they return, where Polars returns a near-free view. The remaining losers (`drop_nulls`, `filter`, `unique`) are row-materialization-bound: their output gather is the cost, and the `drop_nulls`/`filter` numbers here are **far worse than the committed `comparison_table.md`** (which reports `drop_nulls` Go ×1.7, `filter` Py ×3.8) — meaning the parallel-gather fast path the prior change added is not engaging on this dataset, a regression to reproduce and fix. Closing these directly advances the tracked "performance parity on all workloads" goal.

## What Changes

- **Parallel, allocation-lean hash join** *(headline — `join` Py ×7.4, 122 MB)*: replace the serial `map[string][]int` + `string(scratch)` build with a typed probe table keyed on packed integer/hash keys (no per-row string allocation), build the probe side and gather the output columns **concurrently across `NumCPU`** above a size threshold, and pre-size the pair buffer from an estimated match count. Inner/left/right/full/semi/anti/cross semantics, null-fill, and suffixing are unchanged.
- **Constant-overhead `head`/`tail`/`limit`/`slice`** *(`head`/`tail` Py ×2.5–3.7)*: return a metadata-only frame view — shared column references with an adjusted offset/length — so a head/tail of *k* rows allocates O(columns) book-keeping rather than re-materializing per call, making cost independent of frame size. Falls back to a copy only where a downstream mutation would otherwise alias shared storage.
- **Parallel row materialization** *(`drop_nulls` Py ×32.4, `filter` Py ×10.3, `unique` Py ×3.3)*: route `filter`, `drop_nulls`, and `unique`'s output gather through one shared typed gather that runs across `NumCPU` above a threshold; have `drop_nulls` share unchanged columns and only gather columns that actually lose rows; reproduce and fix the `drop_nulls`/`filter` regression versus the committed baseline (the fast path is currently bypassed on the benchmark dataset).
- **Parity-gate coverage + re-baseline**: reproduce the fresh run on the reference machine, re-seed `docs/performance/parity_budgets.json` and `bench/top30/baselines/parity_baseline.json` from it, and extend the gate so every DataFrame-surface op in the table above (`head`, `tail`, `fill_null`, `select`, `with_columns`) carries a tracked budget — no DataFrame op may silently regress.

No public API changes and no change to results — outputs remain byte-identical (guarded by the existing equality/conformance suites); only execution paths, allocation profiles, and the parity gate change.

## Capabilities

### New Capabilities

- `parallel-hash-join`: Equi-joins build the probe table from typed integer-packed row keys (no per-row string allocation), build/probe and gather output columns concurrently across `NumCPU` above a size threshold, and pre-size the pair buffer — producing identical rows, null-fill, ordering, and suffixing to the sequential path for every join mode.
- `parallel-row-materialization`: `filter`, `drop_nulls`, and `unique` materialize their selected rows through one shared typed gather that runs concurrently across `NumCPU` above a size threshold with bounded allocation; `drop_nulls` shares columns that lose no rows and gathers only the rest, returning identical rows to the per-column sequential path.
- `constant-time-frame-slice`: `head`, `tail`, `limit`, and `slice` produce a frame whose columns reference the parent's storage with an adjusted offset/length, allocating O(columns) book-keeping independent of frame size, and copy only when required to preserve copy-on-write safety — with results identical to the materializing path.

### Modified Capabilities

<!-- None: the prior changes' delta specs for join (columnar-join), sort (parallel-numeric-sort), and the parity gate (workload-performance-parity, streaming-row-selection) are not yet synced into openspec/specs/. To avoid competing deltas on unsynced capabilities, this change layers new, narrowly-scoped parallel/zero-copy capabilities on top of the typed foundations already shipped, mirroring how `close-polars-time-gaps` introduced `parallel-group-aggregation`/`parallel-merge-sort` rather than amending unsynced deltas. -->

## Impact

- **Affected code**: `pkg/frame/join.go` (probe table, parallel build/probe, `materializeJoin`), `pkg/frame/frame.go` (`Filter`, `DropNulls`/`gatherRows`, `Unique`, `Head`/`Tail`/`Limit`/`Slice`, shared `takeColumns`), `pkg/chunk` (typed packed-key helper, parallel gather core, zero-copy column view).
- **APIs**: no public signature changes; observable results (rows, order, null-fill, dtypes) preserved and guarded by existing equality/conformance suites.
- **Benchmarks / CI**: re-baselined `bench/top30` summaries, updated `docs/performance/parity_budgets.json` + `bench/top30/baselines/parity_baseline.json`, extended `TestParityBudgets` coverage, regenerated `bench/comparison_table.md`.
- **Dependencies**: none added — portable Go goroutine parallelism only (the reference machine is arm64; no SIMD/assembly required).
- **Risk**: concurrency correctness in the parallel join build/probe and gather (disjoint output ranges, deterministic pair order) and copy-on-write safety for the zero-copy slice; both are addressed in design.md and validated under `-race` with parity tests against the sequential path.
