## ADDED Requirements

### Requirement: Allocation-lean typed join keys

The equi-join probe table SHALL be keyed without allocating a Go `string` per row. For the common single-key and fixed-width multi-key cases the join SHALL pack each row's typed key values into an integer or fixed-width hash key; only mixed/variable-width or unsupported key dtypes MAY fall back to the existing byte-encoded key. The total key-construction allocations SHALL be O(rows / chunk) rather than O(rows).

#### Scenario: Single integer key builds without per-row string allocation

- **WHEN** a frame is joined to another on a single `Int64` key column at 1,000,000 rows
- **THEN** the result is identical to the sequential join
- **AND** the per-operation allocation count does not scale linearly with row count (no per-row key string is created)

#### Scenario: Mixed-width composite key falls back correctly

- **WHEN** the join keys are a composite of differing/variable-width dtypes that cannot be packed
- **THEN** the join uses the byte-encoded key fallback
- **AND** produces rows identical to the sequential path

### Requirement: Parallel join build, probe, and materialization

For frames above a row-count threshold the join SHALL build the probe table, probe the build side, and gather the output columns concurrently across up to `GOMAXPROCS` workers, using disjoint output ranges so no two workers write the same memory. Below the threshold, and for `asof` joins, the existing sequential path SHALL be used unchanged. The pair buffer SHALL be pre-sized from an estimated match count to avoid repeated growth.

#### Scenario: Large inner join runs in parallel and matches sequential output

- **WHEN** an inner join of two 1,000,000-row frames is executed
- **THEN** the output rows, column order, dtypes, and values are identical to the sequential join
- **AND** the operation completes without data races under `-race`

#### Scenario: Sub-threshold join uses the sequential path

- **WHEN** a join is executed on frames below the parallel threshold
- **THEN** the sequential build/probe/gather path is used and the result is unchanged

### Requirement: Join semantics preserved across all modes

The parallel join SHALL produce results identical to the prior implementation for every join mode — `inner`, `left`, `right`, `full`, `semi`, `anti`, and `cross` — including unmatched-row null-fill, right-column suffixing on name collision, and the relative ordering of emitted rows that the existing equality suites assert.

#### Scenario: All join modes equal the sequential result

- **WHEN** the same left/right frames are joined under each of inner, left, right, full, semi, anti, and cross
- **THEN** each result equals the sequential implementation's result for that mode, including null-filled unmatched rows and suffixed colliding column names

#### Scenario: Right and full joins emit unmatched right rows once

- **WHEN** a right or full join leaves some right rows unmatched
- **THEN** each unmatched right row is emitted exactly once with the left columns null-filled, matching the sequential output
