## ADDED Requirements

### Requirement: Metadata-only head/tail/limit/slice

`head`, `tail`, `limit`, and `slice` SHALL return a frame whose columns reference the parent frame's existing storage with an adjusted offset and length, rather than re-materializing the selected rows. The per-call allocation SHALL be O(columns) book-keeping and SHALL NOT scale with the number of rows in the parent frame or the number of rows returned.

#### Scenario: Head cost is independent of frame size

- **WHEN** `head(10)` is called on a 1,000-row frame and on a 1,000,000-row frame
- **THEN** both return the first 10 rows identical to the materializing path
- **AND** the per-call bytes and allocation count are the same for both sizes (no per-row materialization)

#### Scenario: Tail and slice return correct windows as views

- **WHEN** `tail(k)`, `limit(k)`, or `slice(offset, length)` is called
- **THEN** the returned frame contains exactly the requested rows in order, equal to the materializing path
- **AND** the columns reference the parent storage with an adjusted offset/length

#### Scenario: Out-of-range and empty windows

- **WHEN** the requested window is empty, exceeds the frame height, or has a negative/overflowing offset per the existing semantics
- **THEN** the result matches the current materializing implementation's behavior for that case

### Requirement: Copy-on-write safety for shared slices

A view returned by `head`/`tail`/`limit`/`slice` SHALL preserve copy-on-write safety: an operation that would mutate a shared column in place SHALL first copy the affected column so the parent and the view are never aliased through a mutation. Read-only consumers SHALL observe values identical to a fully materialized slice.

#### Scenario: Mutating through a view does not corrupt the parent

- **WHEN** a frame is sliced to a view and a subsequent operation mutates a column of either the view or the parent
- **THEN** the other frame's values are unchanged
- **AND** both frames remain internally consistent (height, schema, and per-column length agree)
