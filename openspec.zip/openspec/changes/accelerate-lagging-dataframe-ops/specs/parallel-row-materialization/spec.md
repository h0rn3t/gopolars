## ADDED Requirements

### Requirement: Shared parallel typed gather for row selection

`filter`, `drop_nulls`, and `unique` SHALL materialize their selected rows through one shared typed gather. For frames above a row-count threshold the gather SHALL run across up to `GOMAXPROCS` workers — partitioning either by output column or by disjoint output row ranges so that concurrent writes never target the same memory. Below the threshold the sequential gather SHALL be used. The materialized output SHALL be identical, value-for-value and null-for-null, to the sequential gather.

#### Scenario: Filter materialization is parallel and matches sequential output

- **WHEN** a predicate selects ~50% of a 1,000,000-row multi-column frame
- **THEN** the filtered frame equals the sequential filter result
- **AND** the column gather executes concurrently without data races under `-race`

#### Scenario: The parallel gather fast path actually engages on the benchmark dataset

- **WHEN** `filter` and `drop_nulls` run at the 1,000,000-row reference scale used by `bench/top30`
- **THEN** the parallel typed gather path is taken (not a sequential or boxed fallback)
- **AND** the measured wall-clock is at least as fast as the committed `bench/comparison_table.md` baseline for that op

### Requirement: drop_nulls gathers in parallel and shares when no rows drop

Because `drop_nulls`/`drop_nans` remove whole rows, every column loses the same rows; the win is in the gather, not in sharing individual columns. When no row in scope is null/NaN, `drop_nulls`/`drop_nans` SHALL return a frame sharing the input columns without materializing a copy (the existing fast path). When rows are removed, the row gather across all columns SHALL run through the shared parallel typed gather above the size threshold, with bounded allocation and no per-row boxing.

#### Scenario: Sparse nulls gather in parallel, not a slow scattered copy

- **WHEN** `drop_nulls` removes a small fraction of rows from a wide 1,000,000-row frame (so the no-null shared-frame fast path does not apply)
- **THEN** the result equals the sequential `drop_nulls` output
- **AND** the per-column gather runs concurrently across `GOMAXPROCS` without data races under `-race`
- **AND** the measured wall-clock is at least as fast as the committed `bench/comparison_table.md` baseline for `drop_nulls` at the reference scale

#### Scenario: No nulls returns a shared frame

- **WHEN** `drop_nulls` is called on a frame with no nulls in scope
- **THEN** the returned frame shares the input columns and allocates O(1) book-keeping

### Requirement: unique materialization parallelized

`unique` SHALL gather its kept distinct rows across columns through the shared parallel gather above the threshold, preserving first-seen encounter order. The set of distinct rows and their order SHALL be identical to the sequential `unique`.

#### Scenario: Large unique matches sequential output

- **WHEN** `unique` is computed over a 1,000,000-row frame with repeated keys
- **THEN** the distinct rows and their encounter order equal the sequential `unique` result
- **AND** the per-column gather executes without data races under `-race`
