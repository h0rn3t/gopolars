## Context

`gopolars` already removed per-row `interface{}` boxing (`performance-parity-all-workloads`) and parallelized `group_by`/`sort` plus radix `rank` (`close-polars-time-gaps`). A freshly captured cross-language run at the 1M-row reference scale still loses to Python Polars on a cluster of DataFrame-surface ops (see proposal table). Investigation of the current code pinpointed the causes:

- **Join** (`pkg/frame/join.go`) is fully sequential: the probe table is `map[string][]int` built with a `string(scratch)` allocation per right row (`chunk.AppendRowKey`), the probe loop is serial, and `materializeJoin` gathers each output column serially via `Column.Gather`. At 1M this is the slowest workload and the heaviest (122 MB / 2120 allocs).
- **head/tail/limit/slice** (`frame.go:782-851`) build an `indexes []int` of length *k* and call `Column.Slice(indexes)` (a full per-column copy) then `New()` (which rebuilds the column map/schema). A zero-copy `Column.View(start,end)` (`chunk.go:397`) already exists but these ops do not use it, so cost is ~19 allocs / 7.2 KB regardless of *k*.
- **filter / drop_nulls / unique** materialize through `takeColumns`/`gatherRows`/`Column.Slice`. `drop_nulls`/`drop_nans` already build the drop mask column-at-a-time and **share the frame when no row is null** (`frame.go:1308`, `1270`); the slow 49.6 MB / 43.9 ms run in the proposal is the *sparse-null* case where one or more nulls force an indexed gather of every column. `filter`'s materialization is similar. The committed `comparison_table.md` reports much faster numbers, so the parallel-gather path the prior change added is not reliably engaging on this dataset — a regression to reproduce.

Constraints: no public API or result changes (guarded by existing equality/conformance suites); portable Go only (the reference machine is arm64; Go 1.26 `simd/archsimd` is amd64-only); concurrency must be `-race`-clean and deterministic.

## Goals / Non-Goals

**Goals:**
- Bring `join`, `drop_nulls`, `filter`, `unique`, and `head`/`tail`/`limit`/`slice` at the 1M reference scale to parity or better with Python Polars, without changing observable results.
- Parallelize the join build/probe/gather and remove the per-row string-key allocation.
- Make `head`/`tail`/`limit`/`slice` constant-cost via the existing zero-copy `Column.View`.
- Reproduce, re-baseline, and gate every DataFrame-surface op so wins are locked and regressions caught.

**Non-Goals:**
- `group_by` (Py ×1.4) and `fill_null` (Py ×1.3) — already near parity; out of scope beyond ensuring they are tracked by the gate (a small follow-up may revisit them).
- SIMD/assembly kernels (non-portable on arm64) and any change to lazy/SQL execution.
- Beating Polars on tiny absolute times where the gap is sub-microsecond and practically irrelevant beyond the gate.

## Decisions

### D1 — Parallel partitioned hash join with typed keys

Replace the `map[string][]int` build with a hash table keyed on a packed integer (single `Int64`/`Float64`/`Boolean` key) or a 64-bit hash of the existing `AppendRowKey` bytes (composite/string keys), eliminating the per-row `string` allocation. Store row indices as `int32` to halve the pair/posting memory.

Parallelize as a **build-side partitioned, left-driven probe**:
1. Build the right (probe) table. For large inputs, partition right rows by `hash%P` into P shard maps built concurrently (each worker owns one shard range → no shared writes), or build sequentially when right is small. After build, the maps are read-only.
2. Probe by splitting the **left rows into contiguous shards**; each worker looks up its shard against the (now read-only) table and appends `(left,right)` pairs to a *local* buffer. Concatenate shard buffers in shard order.

This preserves the exact emitted order the equality suites assert: pairs come out in left-row order, right matches within a left row stay in posting (build) order, and unmatched right rows for right/full joins are appended at the end in right-row order (unchanged). Pre-size the pair buffer from `len(left)` scaled by a sampled match rate.
3. Materialize via a parallel per-column gather over the concatenated `leftIdx`/`rightIdx` (reusing the parallel gather from D3).

**Alternatives considered:** (a) keep the string-keyed map but parallelize only the probe — rejected, the string allocation is most of the 2120 allocs; (b) full sort-merge join — rejected, changes complexity class and output order, larger blast radius; (c) a single shared map written under a lock or `sync.Map` — rejected, contention erases the parallel win. `asof` join stays sequential (different algorithm, not in the losing set).

### D2 — Constant-cost head/tail/limit/slice via Column.View

Add an internal `viewRows(start, end)` frame helper that builds the output frame by calling `Column.View(start,end)` per column (zero-copy slice of the backing arrays, already implemented) and copying `order`/`schema` (O(columns)), bypassing the `indexes []int` build and the per-column `Slice` copy. Route `Head`/`Limit`/`Tail`/`Slice` through it for the contiguous-window case; the existing `n >= height` short-circuit (returns the shared frame) stays.

**Copy-on-write:** `View` shares backing slices, so any in-place column mutator must copy first. gopolars columns are effectively immutable today (`Shift`, `Filter`, etc. allocate new arrays), so the risk is a *future* in-place op; the task list includes auditing existing mutators and documenting the COW invariant, plus a test that mutating through a view never corrupts the parent.

**Alternatives considered:** giving `Column` an explicit `offset` field threaded through every kernel — rejected as far more invasive than reusing `View`, which already produces a correct standalone column.

### D3 — One shared parallel typed gather for row selection

Unify `filter`, `drop_nulls`/`drop_nans`, and `unique` onto a single typed gather that, above a row-count threshold, gathers columns concurrently across `GOMAXPROCS` (bounded), and below it stays sequential. First **reproduce** the proposal's `drop_nulls`/`filter` numbers in a committed benchmark (the sparse-null and 50%-selectivity cases) to confirm the regression, then ensure the parallel path engages for them. Keep `drop_nulls`/`drop_nans`'s no-null shared-frame fast path; when rows are removed, all columns are gathered (whole-row removal means no column can be shared). Consider a contiguous-run gather (bulk copy) when the keep-set has long runs.

**Alternatives considered:** per-row-range partitioning vs per-column partitioning — choose per-column for wide frames and per-range for few-column tall frames; the gather helper picks based on `columns` vs `rows`. SIMD compress — rejected (non-portable).

### D4 — Re-baseline and extend the parity gate

Reproduce the fresh run on the reference machine, regenerate `bench/top30/top30_summary.{json,csv,md}`, re-seed `docs/performance/parity_budgets.json` and `bench/top30/baselines/parity_baseline.json`, and extend `TestParityBudgets` so every DataFrame-surface op (`head`, `tail`, `fill_null`, `select`, `with_columns`, plus the already-tracked ones) carries a budget. Regenerate `bench/comparison_table.md`.

## Risks / Trade-offs

- **[Join output order changes under parallelism]** → Probe is left-driven and shards are contiguous + concatenated in order; right matches stay in posting order; unmatched-right appended last. Validated against the existing per-mode join equality suites and a new large-frame parity test.
- **[Data race in parallel build/probe/gather]** → Shard maps are write-owned per worker and read-only after build; gather workers write disjoint columns/ranges. Run `-race` on `pkg/frame`/`pkg/chunk` and the join/gather tests.
- **[Zero-copy view aliases parent through a future in-place mutation]** → Audit current mutators (none mutate in place today), document the COW invariant, and add a mutation-isolation test. If an in-place op is later needed, it copies the affected column first.
- **[Parallel overhead hurts small frames]** → All parallel paths gate on a row-count threshold; below it the sequential path is byte-for-byte unchanged. Re-confirm the 1K-row numbers do not regress.
- **[Re-baselining masks a real regression]** → Budgets are seeded from the *measured* fresh run but each op carries `r_min`; the gate still fails on a drop below baseline beyond `tolerance`, and any sub-parity `r_min` requires a justification.

## Migration Plan

Pure internal optimization: ship behind the existing eager paths, no flags, no API change. Each decision is independently revertable (join, slice, gather, gate are separate commits). Rollback = revert the commit; the sequential paths remain intact below thresholds. Verification: `go build ./...`, `go vet`, full `go test ./...`, `-race` on touched packages, then the re-run `bench/top30 --python` suite with the gate green.

## Open Questions

- Join build-side selection: always build on the right operand, or build on the smaller operand (and flip output column order accordingly)? Building on the smaller side is faster but must not change output column order/suffixing — resolve during implementation with a parity test.
- Exact parallel thresholds per op (join rows, gather rows×cols) — tune from the profile; seed conservatively (e.g. ≥ 64K rows) and confirm 1K does not regress.
- Whether the `drop_nulls`/`filter` slowdown vs the committed table is purely the sparse-null/selectivity dataset difference or also a code regression — settle by reproducing both datasets in D3's first step before optimizing.
