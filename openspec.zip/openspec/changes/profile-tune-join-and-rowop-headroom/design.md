## Context

`accelerate-lagging-dataframe-ops` parallelized the equi-join (`pkg/frame/join.go`) and brought 1M join to parity (6.71 ms vs Polars 6.27 ms). Three follow-ups were deferred and are the subject of this change:

- The parallel **build** (`buildPacked`) shards by `k % P` with each worker scanning *all* right rows and keeping `k%P==s` — P full scans. It is gated on `parallelJoinThreshold` (right ≥ 32768), but the benchmark's right side is the ~1000-row `unique("i")` dimension, so the sharded build **never runs on the target workload** and is effectively unvalidated.
- The probe pre-packs the whole probe-side key column into `leftPacked []uint64` (~8 MB at 1M) before fanning out.
- `parallelJoinThreshold` was copied from `parallelFilterThreshold`, not measured for join.
- `filter` (×4.6) and `drop_nulls` (×3.7) still trail Polars; the gap was attributed to SIMD without a measured assessment. (Note: the committed `drop_nulls` parity number is also an artifact — the Go bench calls `DropNaNs` on a null-not-NaN column, a no-op.)

Constraints: no public API or result changes (guarded by the existing equality/conformance and `TestJoinParallelMatchesSequential` suites); portable Go only by default (reference machine is arm64 M4 Pro; Go 1.26 has no portable SIMD); concurrency must stay `-race`-clean.

## Goals / Non-Goals

**Goals:**
- Replace the join's untested assumptions with profile evidence: know where 1M join time goes now, set thresholds from the measured crossover.
- Make the parallel build *lean and justified*: drop the O(rows) `leftPacked` buffer; either delete the parallel build (if it never pays for realistic right sizes) or replace the P-pass partition with a single-pass one — whichever the profile supports.
- Produce a measured go/no-go on closing `filter`/`drop_nulls` without SIMD, and land any portable win that clears a bar — all with byte-identical results.

**Non-Goals:**
- Changing join/filter/drop_nulls *results* or any public API.
- Shipping non-portable (NEON/asm) kernels in the default build (an isolated, build-tagged spike is allowed for measurement only).
- Re-touching ops already at/near parity (group_by, fill_null, head/tail, sort, unique).

## Decisions

### D1 — Profile before changing code

Capture CPU + alloc profiles of `join`, `filter`, and `drop_nulls` at 1M (`-cpuprofile`/`-memprofile`, plus `-benchmem`) and read them with `pprof`/`benchstat`. Every subsequent decision (threshold value, keep-vs-delete the parallel build, go/no-go on row ops) is made from these numbers, not from intuition. *Alternative:* tune by guess — rejected; that is exactly the gap this change closes.

### D2 — Lean the build: drop `leftPacked`, then keep-or-delete parallel build by evidence

Remove `leftPacked`: pack the probe key inline in the probe loop. For the supported dtypes a key is one arithmetic op (`uint64(v)` for Int64, bit-cast for Float64 with NaN canonicalization, 0/1 for Bool, `UnixNano` for Datetime). Hoist the dtype switch out of the row loop (switch once → tight typed loop), so no 8 MB buffer and no per-row dtype branch.

For the build partition, choose from the profile:
- **(a) Delete the parallel build** and always build the single sequential map, *if* the profile shows the parallel build never pays within realistic right-side sizes (the simplest, least-code outcome — favored unless large-right joins are shown to matter).
- **(b) Single-pass partition** if large-right joins are a real target: a count-then-scatter (radix) partition — pass 1 (parallel, contiguous ranges) counts per-(worker,shard); prefix-sum offsets; pass 2 (parallel) scatters int32 row indices into one flat per-shard array; build per-shard maps from contiguous slices. Two passes over right, no locking, no redundant scans.

*Alternatives:* per-worker local maps + sequential merge (rejected: merge is a serial O(rows) pass that can cost more than it saves); a single shared map under a lock / `sync.Map` (rejected: contention erases the win).

**Measured outcome (supersedes the above hypothesis):** `leftPacked`/`rightKeys` were removed via an inline `PackKeyFunc` closure — a real win (Join1M 106→98 MB, large-right 198→182 MB, no time cost). But the build refactor went the *opposite* way from the hypothesis: deleting the sharded build (option a) was tried and **regressed** the 1M×1M build from 25 ms to 127 ms (5.6× slower) — the GC-heavy CPU profile had misled the "alloc-bound, sharding won't pay" reasoning. The per-key posting-slice allocation parallelizes well across shards, so the sharded P-pass build is kept and is now *validated* by measurement rather than assumed. The single-pass / count-then-scatter rewrite was therefore unnecessary and not pursued. Net: keep the parallel build, drop only the key buffers.

### D3 — Set thresholds from the measured crossover

Replace the inherited `1<<15` with the measured build/probe/gather crossover (they may differ), each documented in-source with the measurement that set it. Re-confirm the 1K join does not regress. *Alternative:* one shared threshold for all three phases — keep only if the profile shows the crossovers coincide.

### D4 — Row-op gap: attribute, then test portable levers, then decide

Profile `filter`/`drop_nulls` at 1M to split time between predicate/null-scan and compaction/gather. Then test portable levers against the dominant cost:
- **Bitmap-driven contiguous-run gather**: when the keep-set has long runs, copy whole runs with `copy()` (bulk memmove) instead of per-index gather — cheap, portable, helps low-selectivity/sparse cases.
- Memory-layout / bounds-check-elimination tweaks in the gather kernel.
- An **optional, build-tagged arm64 NEON compaction spike** purely to measure the SIMD ceiling and quantify the residual portable gap.

Record a go/no-go in `docs/performance/`. Land the run-gather (and any BCE win) only if it keeps results byte-identical and shows a measured improvement; otherwise document the residual as SIMD-bound with the NEON number as evidence. *Alternatives:* jump straight to SIMD (rejected: non-portable, unmeasured); accept the gap with no investigation (rejected: that is the assumption this change removes).

## Risks / Trade-offs

- **[Profile noise leads to a wrong threshold]** → Use `benchstat` over multiple runs; pick a conservative crossover; re-confirm 1K is unregressed.
- **[Build refactor breaks correctness]** → `TestJoinParallelMatchesSequential` (all modes, incl. large-right and null keys) runs under `-race`; add an allocation test asserting no O(rows) probe-key buffer.
- **[Deleting the parallel build hurts a real large-right join]** → Only delete if the profile + a new large-right benchmark show it never pays; keep the benchmark committed so a future regression is visible.
- **[Run-gather changes results on edge cases]** → Byte-identical equality tests across empty/partial/full selectivity and sparse/dense nulls; the run-gather is a path *inside* the existing gather, falling back to per-index for short runs.
- **[NEON spike leaks into the portable build]** → Behind a build tag; default build excludes it; CI builds the default.

## Migration Plan

Pure internal optimization/assessment: no flags, no API change. Each decision is independently revertable (profile/threshold, build refactor, row-op gather are separate commits; the NEON spike is build-tagged). Rollback = revert the commit; the sequential paths and current gather remain intact below thresholds. Verification: `go build ./...`, `go vet`, full `go test ./...`, `-race` on touched packages, the join parity + allocation tests, and the focused 1M benchmarks (before/after via `benchstat`).

## Open Questions

- Is a **large-right** join (both sides ≫ threshold) a real target workload? This decides D2 keep-vs-delete of the parallel build.
- Is per-index gather already memory-bandwidth-bound at 1M? If so, the contiguous-run gather may not help and the row-op outcome is no-go (SIMD-bound) — to be settled by the D4 profile before writing any kernel.
- Do the build/probe/gather crossovers differ enough to warrant separate thresholds, or is one constant sufficient?
