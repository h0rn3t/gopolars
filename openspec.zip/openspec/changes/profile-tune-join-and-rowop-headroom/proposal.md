## Why

The prior change (`accelerate-lagging-dataframe-ops`) parallelized the equi-join and brought it to parity at 1M (47.4 ms → 6.71 ms vs Polars 6.27 ms). But it shipped on a hypothesis, not a profile: the parallel build is **untested on the target workload** (the benchmark's right side is the ~1000-row `unique("i")` dimension, always below the threshold, so the sharded build never runs there), it pre-packs the entire probe-side key column into a separate O(rows) `[]uint64` buffer (~8 MB at 1M), the parallel threshold (32768) was copied from the filter path rather than measured for join, and the two most common row ops still trail Polars — `filter` ×4.6, `drop_nulls` ×3.7 — with the gap attributed to "SIMD, out of scope" without a concrete assessment. This change replaces those assumptions with measurements: profile, tune, simplify, and produce a go/no-go on the row-op gap.

## What Changes

- **Profile-calibrated join thresholds**: capture CPU + alloc profiles of `join` at 1M, identify the now-dominant cost (probe vs gather vs build), and set the parallel build/probe/gather thresholds from the measured crossover instead of the inherited `1<<15`. Re-confirm no 1K regression.
- **Lean parallel join build**: remove the upfront full-column `leftPacked []uint64` (pack probe keys lazily per shard or skip the separate buffer) and replace the "each worker scans all right rows, keeps `k%P==s`" partition (P full scans) with a single-pass partition (e.g. per-worker local maps merged, or a count-then-scatter). Results stay byte-identical; the parallel build becomes worth its complexity (and gets a benchmark that actually exercises it with a large right side).
- **Row-op SIMD-gap assessment**: a committed, measured feasibility study for `filter` and `drop_nulls` at 1M — quantify where the time goes (predicate eval vs compaction/gather), test portable levers (bitmap-driven contiguous-run gather, memory layout, bounds-check elimination, optional arm64 NEON compaction spike), and record a go/no-go. If a portable optimization clears a bar, land it; otherwise document the residual as SIMD-bound with evidence.

No public API changes and no change to results — outputs remain byte-identical (guarded by the existing equality/conformance and join parity suites); only profiles, thresholds, the build's internal structure, and (conditionally) a row-op compaction path change.

## Capabilities

### New Capabilities

- `lean-parallel-join-build`: The parallel join build produces results identical to the sequential path while (a) not allocating a separate O(rows) probe-side key buffer, (b) partitioning the build side without scanning any right row more than a constant number of times, and (c) using a parallel threshold calibrated from a measured profile. A benchmark exercises the large-right (sharded) build directly.
- `rowop-simd-gap-assessment`: A committed, reproducible assessment of the `filter`/`drop_nulls` 1M gap versus Polars, attributing time to predicate-eval vs compaction, evaluating portable (non-SIMD) optimizations, and recording a go/no-go decision; any optimization that lands keeps results byte-identical and carries a benchmark.

### Modified Capabilities

<!-- None synced: the prior change's `parallel-hash-join` and `parallel-row-materialization` deltas are not yet in openspec/specs/. To avoid competing deltas on unsynced capabilities, this change layers narrowly-scoped refinement/assessment capabilities on top, mirroring how the prior change layered new capabilities rather than amending unsynced deltas. -->

## Impact

- **Affected code**: `pkg/frame/join.go` (`buildPacked` partition strategy, removal of `leftPacked`, threshold constant), possibly `pkg/frame/typed.go` / `pkg/chunk` (row-op compaction path if an optimization lands), `bench/top30` (a large-right join benchmark; profile capture harness).
- **APIs**: no public signature changes; observable results (rows, order, null-fill, dtypes) preserved and guarded by existing suites.
- **Benchmarks / docs**: a large-right join benchmark added; a committed profile-and-assessment note under `docs/performance/`; thresholds documented with their measured basis.
- **Dependencies**: none added — portable Go only; an arm64 NEON compaction spike, if attempted, stays behind a build tag and is optional/revertable.
- **Risk**: low — profiling and threshold tuning are non-behavioral; the build refactor is guarded by the existing join parity tests under `-race`; the row-op work is gated behind a measured go/no-go and only lands if it keeps results identical.
