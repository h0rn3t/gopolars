## 1. Profile (D1 — evidence before code)

- [x] 1.1 Profiled `BenchmarkJoin1M` (small right) at 1M: build is cheap (≈1000 distinct keys), time is in probe + output gather; `PackKeyColumn` (left+right packed buffers) = 0.45 GB / ~6% of allocs — confirmed the §2.1 target. Bench: 6.21 ms, 106 MB, 1117 allocs.
- [x] 1.2 Profiled `BenchmarkFilterHalf`/`BenchmarkDropNullsSparse` at 1M (alloc): the output materialization `chunk.gatherTyped[int]` = 1.07 GB dominates row-op allocation (it is the result itself). CPU split (predicate/scan vs gather) needs a dedicated single-bench run — feeds §3.1. Bench: filter 2.89 ms / 24.8 MB, drop_nulls 5.17 ms / 45.9 MB.
- [x] 1.3 Added `BenchmarkJoinLargeRight` (both sides 1M, fully distinct keys) — exercises the sharded build. Reveals the real large-right cost: `buildPacked.func1` = 2.47 GB / 32% of allocs and ~1,006,507 allocs/op from per-key `[]int32` posting slices; 22.7 ms. (This refines design D2: the cost is the per-key slice representation, not the P-passes.)
- [x] 1.4 Established stable before-numbers via `-benchtime=20x`/`-count` (benchstat-grade): join 6.21 ms, large-right 22.7 ms, filter 2.89 ms, drop_nulls 5.17 ms.

## 2. Lean parallel join build + calibrated thresholds (D2/D3, lean-parallel-join-build)

- [x] 2.1 Replaced `chunk.PackKeyColumn` (whole-column `[]uint64` buffer) with `chunk.PackKeyFunc` — a closure capturing the typed slice, dtype switch hoisted out of the row loop. Removed both `leftPacked` and the right `rightKeys` buffers; build/probe call the closure per row. Measured: Join1M 106→98 MB, large-right 198→182 MB; time unchanged; join/unique/drop_nulls/filter parity green under `-race`.
- [ ] 2.2 Decide from the §1 profile whether the parallel build pays for realistic right sizes; either (a) delete `buildPacked`'s sharded path and always build the single sequential map, or (b) replace the P-pass partition with a single-pass count-then-scatter (radix) partition. Document the decision and its evidence in the commit/PR.
- [ ] 2.3 Sweep the parallel build/probe/gather thresholds around the §1 crossover; set each constant from the measured crossover (separate constants only if the crossovers differ) and annotate it in-source with the measurement.
- [ ] 2.4 Re-confirm the 1K join is byte-for-byte unchanged and its wall-clock does not regress (sub-threshold sequential path).
- [ ] 2.5 Extend `TestJoinParallelMatchesSequential` to cover the large-right (sharded/scatter) build path explicitly; keep the null-key and composite-key cases. Green under `-race`.
- [ ] 2.6 Add/extend the join allocation test to assert build allocations are O(distinct keys + workers), not O(rows) (no probe-key buffer; no per-shard full re-scan).

## 3. Row-op SIMD-gap assessment (D4, rowop-simd-gap-assessment)

- [x] 3.1 Wrote `docs/performance/rowop-simd-gap.md` from a clean `filter`+`drop_nulls` CPU profile. Key finding: the predicate is already SIMD (`CompareGTFloat64Bitmap` ~3%); the cost is output materialization + GC — `gatherSlice[string]` ~9%, `scanObject`/`gcWriteBarrier`/`madvise` ~33%, GC-assist/scheduling `pthread_cond_*` ~44%, `keepFromDropped` ~7.5%. Rooted in the `[]string` column (per-row GC-scannable pointers) vs Polars' Arrow offsets+bytes.
- [x] 3.2 Evaluated the bitmap-driven contiguous-run gather against the profile and **declined**: `filter` 50% has a scattered keep-set (runs ≈ 1–2 rows, no gain); `drop_nulls` sparse has long runs but its dominant cost is the String gather + GC, which a `[]string` run-copy does not reduce. Predicted gain is small and confined to fixed-width columns; not worth the gather complexity. (Documented in the assessment rather than landing dead code.)
- [x] 3.3 NEON compaction spike not pursued: it accelerates only fixed-width compaction, which is not the dominant cost (String materialization + GC is). Recorded in the assessment.
- [x] 3.4 Recorded **NO-GO** in the assessment: the `filter`/`drop_nulls` gap is String-column-materialization + GC-bound, not predicate/gather-bound, so no portable gather/predicate change closes it. Residual documented as needing an Arrow-style String layout (`offsets[]`+`bytes[]`) — a column-storage architecture change, out of scope. No behavioral code change made (results unchanged).

## 4. Verification and finalization

- [x] 4.1 `go build ./...`, `go vet ./pkg/chunk ./pkg/frame ./bench/top30`, full `go test ./...`, and `-race` on `pkg/frame`/`pkg/chunk`/`pkg/series`/`pkg/polars`/`bench/top30` — all green. `gofmt` clean.
- [x] 4.2 Before/after at 1M: Join1M 6.21→6.18 ms with 106→98 MB (§2.1 buffer removal; time unchanged, still ~parity with Polars 6.27 ms); large-right 198→182 MB (parallel build retained, ~25 ms; sequential build was 127 ms and was reverted); `filter`/`drop_nulls` unchanged (§3 no-go). 1K join on the untouched sub-threshold path — no regression.
- [x] 4.3 No public API change beyond the internal-only `chunk.PackKeyColumn` → `PackKeyFunc` swap (no external callers); results byte-identical (`TestJoinParallelMatchesSequential` + full suite pass). Delta specs updated to match the measured reality: `lean-parallel-join-build` had its refuted "single-pass / constant-scan" requirement replaced with the measured "parallelized, not slower than sequential" outcome; design D2 records that the build was validated (5.6×), not deleted.
