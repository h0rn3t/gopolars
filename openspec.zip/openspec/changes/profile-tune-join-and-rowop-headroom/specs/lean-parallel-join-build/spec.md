## ADDED Requirements

### Requirement: Bounded-allocation parallel join build

The parallel join build SHALL produce results identical to the sequential path while bounding its working memory: it SHALL NOT allocate a separate O(rows) probe-side key buffer for the whole left frame (keys are packed inline via a hoisted closure). Total build allocations SHALL remain O(distinct keys + workers), not O(workers × rows). For a large right side the build SHALL be parallelized across workers (each writing only its own shard map, read-only after build) and SHALL NOT be slower than a single-goroutine build.

> Note (measure-then-act): the original draft required the build to scan each right row "a constant number of times" (single pass). Profiling refuted this — the sharded build re-scans rows for its shard but parallelizes the per-key posting-slice allocation, which dominates a high-cardinality build, making it ~5.6× faster at 1M×1M than a single-goroutine single-pass build. The requirement is therefore stated in terms of the measured outcome (not slower than sequential, bounded allocation) rather than the refuted scan-count proxy.

#### Scenario: Large join matches sequential without an O(rows) probe-side key buffer

- **WHEN** an inner join of a 1,000,000-row left frame on a single Int64 key is executed on the parallel path
- **THEN** the output rows, order, dtypes, null-fill, and suffixing are identical to the sequential (single-worker) result
- **AND** the join does not allocate a full-frame `[]uint64` probe-key buffer (probe keys are packed inline by a closure capturing the typed column)

#### Scenario: Large-right build is parallelized and not slower than sequential

- **WHEN** the probe table is built for a right side above the parallel threshold
- **THEN** the build is sharded across workers (each owns the keys with `k % shards == s`, writing only its own map)
- **AND** its wall-clock is no worse than a single-goroutine build of the same table (measured ~5.6× faster at 1M×1M)
- **AND** the resulting table yields the same matches as the sequential single-map build

### Requirement: Profile-calibrated parallel thresholds

The join's parallel build/probe/gather thresholds SHALL be set from a measured crossover point on the reference machine, documented with their basis, rather than inherited unchanged from an unrelated op. Below the calibrated threshold the sequential path SHALL be used and SHALL remain byte-for-byte unchanged.

#### Scenario: Small join stays sequential and unregressed

- **WHEN** a join is executed on frames below the calibrated threshold
- **THEN** the sequential build/probe/gather path is used
- **AND** the 1,000-row join wall-clock does not regress versus the prior implementation

#### Scenario: Threshold has a recorded measured basis

- **WHEN** the parallel threshold constant is read in the source
- **THEN** it is accompanied by a note citing the profile/crossover measurement that set it

### Requirement: Large-right sharded build is exercised and correct

A benchmark and a parity test SHALL directly exercise the large-right (sharded) build path — where the right side itself exceeds the threshold — so the parallel build is validated on a representative workload, not only on the small-right benchmark case.

#### Scenario: Large-right join equals sequential under race detection

- **WHEN** both left and right frames exceed the parallel threshold and are joined
- **THEN** the result equals the sequential implementation's result
- **AND** the operation completes without data races under `-race`
