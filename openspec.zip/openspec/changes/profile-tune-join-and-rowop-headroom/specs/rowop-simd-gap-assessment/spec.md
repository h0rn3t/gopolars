## ADDED Requirements

### Requirement: Committed reproducible row-op gap assessment

The change SHALL produce a committed, reproducible assessment of the `filter` and `drop_nulls` 1M gap versus Polars, under `docs/performance/`. The assessment SHALL attribute the measured Go time between predicate/null-scan and compaction/gather, state the Polars 1M reference time, and record an explicit go/no-go decision on closing the gap without SIMD.

#### Scenario: Assessment documents attribution and a decision

- **WHEN** the assessment note is read after the change lands
- **THEN** it reports, for `filter` and `drop_nulls` at 1M, the Go time split into predicate/scan vs compaction/gather and the Polars reference time
- **AND** it records a go/no-go decision with the evidence behind it

#### Scenario: Assessment is reproducible

- **WHEN** the documented profiling/benchmark commands are re-run on the reference machine
- **THEN** they regenerate the measurements the assessment is based on (within run-to-run noise)

### Requirement: Any landed row-op optimization preserves results and is benchmarked

If the assessment is go and a portable optimization is implemented, it SHALL keep `filter`/`drop_nulls` results byte-identical to the current path and SHALL carry a benchmark demonstrating the improvement at 1M. If the assessment is no-go, no behavioral code change SHALL be made and the residual gap SHALL be documented as SIMD-bound.

#### Scenario: Optimization keeps results identical

- **WHEN** a portable `filter`/`drop_nulls` optimization lands
- **THEN** the filtered / null-dropped frame equals the prior implementation's result, value-for-value and null-for-null, across empty / partial / full selectivity and sparse / dense nulls
- **AND** the existing equality and `-race` suites pass unchanged

#### Scenario: Improvement is measured

- **WHEN** an optimization lands
- **THEN** a committed benchmark shows the 1M wall-clock improved versus the pre-optimization baseline

### Requirement: Non-portable experiments are isolated

Any non-portable experiment (e.g. an arm64 NEON compaction kernel) SHALL be isolated behind a build tag so the default portable build is unaffected, and SHALL be optional and revertable.

#### Scenario: Default build excludes the non-portable kernel

- **WHEN** the project is built without the experiment's build tag
- **THEN** the portable implementation is used and the build succeeds on all supported architectures
