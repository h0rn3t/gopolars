## ADDED Requirements

### Requirement: Tracked workloads carry parity budgets at a reference scale

The system SHALL maintain a versioned parity-budget file that maps every workload tracked by the cross-language `bench/top30` suite (identified by object, operation, and row scale) to a parity budget. A parity budget is expressed as a minimum ratio `r_min = python_time / go_time` measured at a declared reference scale (1,000,000 rows). A workload meets its budget WHEN its measured ratio is greater than or equal to `r_min`. The default target for an in-scope workload SHALL be `r_min = 1.0` (gopolars at least as fast as Python Polars); any workload assigned a budget below `1.0` SHALL carry an inline justification in the budget file.

#### Scenario: every tracked workload has a budget entry

- **WHEN** the parity gate loads the budget file and enumerates the workloads emitted by `bench/top30`
- **THEN** each emitted `(object, operation, scale)` at the reference scale SHALL have a corresponding budget entry, and any tracked workload without an entry SHALL be reported as an error

#### Scenario: sub-parity budgets are justified

- **WHEN** a workload is assigned `r_min < 1.0`
- **THEN** the budget file SHALL include a non-empty justification string for that workload

### Requirement: The parity gate fails on budget breach

A parity-gate check SHALL compare each tracked workload's measured ratio against its budget and SHALL exit non-zero when any in-scope workload's measured ratio falls below its `r_min`. The failure report SHALL name the workload, its budget, and its measured ratio.

#### Scenario: a regressed workload fails the gate

- **WHEN** a tracked workload's measured ratio is below its budgeted `r_min`
- **THEN** the parity gate SHALL exit non-zero and SHALL list that workload with its measured and budgeted ratios

#### Scenario: all workloads within budget pass

- **WHEN** every in-scope workload's measured ratio is greater than or equal to its `r_min`
- **THEN** the parity gate SHALL exit zero

### Requirement: A versioned baseline detects regression

The parity gate SHALL read a versioned baseline of per-workload ratios and SHALL flag any workload whose newly measured ratio degrades beyond a tolerance band relative to the baseline, independently of whether the absolute budget is still met. The tolerance band SHALL be configurable in the budget file.

#### Scenario: degradation beyond tolerance is flagged

- **WHEN** a workload's measured ratio drops below its baseline ratio by more than the configured tolerance
- **THEN** the parity gate SHALL report that workload as a regression even if its absolute `r_min` budget is still satisfied

#### Scenario: noise within tolerance does not flag

- **WHEN** a workload's measured ratio differs from its baseline by less than the configured tolerance
- **THEN** the parity gate SHALL NOT report that workload as a regression
