## ADDED Requirements

### Requirement: Full-frame sort gather skips redundant validity allocation

A full-frame numeric sort already computes a single permutation (radix argsort above threshold, otherwise a typed comparison argsort) and materializes every payload column by one typed gather under that permutation. That gather SHALL go through the shared null-mask-free typed gather, so a payload column with no nulls is materialized without allocating or copying a per-column validity buffer. The sorted output — row order, stability, NaN placement, and every column value — SHALL be identical to the prior implementation.

#### Scenario: sorting a null-free frame allocates no per-column validity buffer

- **WHEN** a frame of null-free numeric and payload columns is sorted by a numeric key
- **THEN** each payload column SHALL be gathered under the shared permutation without a separately allocated validity slice, with values identical to the prior implementation

#### Scenario: sorted output is unchanged

- **WHEN** a frame is sorted via the gather path and via the prior implementation
- **THEN** the resulting row order and all column values SHALL be identical, including documented stability and NaN placement
