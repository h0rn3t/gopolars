## ADDED Requirements

### Requirement: Typed gather allocates a validity buffer only when nulls can result

`chunk.Column.Slice` and `chunk.Column.Gather` SHALL materialize output by switching on dtype once and running a tight typed copy loop over the index slice, rather than a per-row dtype switch. When the source column has no null rows (cached `NullCount() == 0`) and no `-1` null-fill sentinel is present, the output SHALL be produced with a nil validity slice — no `[]bool` is allocated and no per-row null bookkeeping runs — and its null count SHALL be recorded as a known zero. The output values SHALL be identical to the prior per-row copy.

#### Scenario: null-free gather allocates no validity buffer

- **WHEN** `Slice` or `Gather` gathers rows from a null-free column
- **THEN** the result SHALL carry no separately allocated validity slice and SHALL report a null count of zero, with values equal to the prior implementation

#### Scenario: gather with nulls or null-fill preserves null placement

- **WHEN** the source has null rows, or a `-1` index requests null-fill (outer join)
- **THEN** the output SHALL place a null at exactly those positions, identical to the prior implementation

### Requirement: drop_nulls and drop_nans build the keep-set column-at-a-time

`drop_nulls` and `drop_nans` SHALL determine the surviving rows by scanning typed buffers one column at a time — the cached validity mask for `drop_nulls` (skipping any column with `NullCount() == 0`) and the typed `float64` backing for `drop_nans` — rather than probing each row through a per-row `IsNull()` call or a boxed `Value(row)`. The result SHALL contain exactly the rows the prior per-row implementation kept, in order, including the retention of null (non-NaN) rows by `drop_nans`.

#### Scenario: drop result matches the prior implementation across selectivity

- **WHEN** `drop_nulls`/`drop_nans` runs on a frame with no, some, or all rows removed
- **THEN** the surviving rows and their values SHALL equal the prior per-row implementation

#### Scenario: drop_nans removes only non-null NaN rows

- **WHEN** a float column contains both NaN values and null rows
- **THEN** `drop_nans` SHALL remove the NaN rows and retain the null rows

### Requirement: Large multi-column gathers materialize columns concurrently

When a row-selecting or reordering operation (`filter`, `sort`, `drop_nulls`/`drop_nans`) materializes a result whose kept-row count is at or above the parallel threshold and whose frame has more than one column, the per-column typed gather SHALL run concurrently across at most GOMAXPROCS workers — each column is independent and writes a disjoint output slot — so the materialization tail uses the cores left idle after the predicate evaluation. Below the threshold, for a single column, or on one CPU, the gather SHALL stay sequential. The result SHALL be element-wise identical to the sequential gather, including null placement and row order.

#### Scenario: parallel gather equals the sequential gather

- **WHEN** a multi-column frame above the parallel threshold is filtered (or sorted) with the gather forced parallel and forced sequential
- **THEN** the two results SHALL be element-wise identical — same surviving rows, same order, same per-column null placement — and SHALL match a sequential oracle

#### Scenario: small or single-column gather stays sequential

- **WHEN** the kept-row count is below the threshold, or the frame has one column, or GOMAXPROCS is 1
- **THEN** the gather SHALL run sequentially with no worker goroutines

### Requirement: Row selection shares the input frame when nothing is removed

When `drop_nulls`/`drop_nans` would remove no rows (no in-scope nulls or NaNs), they SHALL return the input columns without gathering a full copy, matching the no-op sharing already used by `Limit` and `Sort`. Allocation in that case SHALL be bounded by the public wrapper, independent of row count.

#### Scenario: drop_nulls on a null-free frame does not gather a copy

- **WHEN** `drop_nulls` runs on a multi-column null-free frame
- **THEN** it SHALL not perform a per-column gather, allocating no more than the public facade wrapper
