## MODIFIED Requirements

### Requirement: is_null and is_not_null are produced from the typed validity mask

`is_null` and `is_not_null` SHALL build their boolean result directly from the column's validity state without round-tripping values through an `[]any` slice and `chunk.FromAny`. For a null-free column (cached `NullCount() == 0`), `is_null` SHALL leave the all-false zero buffer and `is_not_null` SHALL fill all-true at memmove throughput (e.g. exponential copy doubling) rather than a per-element store loop; for a column with nulls, `is_null` SHALL copy the validity mask and `is_not_null` SHALL invert it. Allocation SHALL be bounded by a single output buffer, independent of per-row boxing, and on null-free data `is_not_null` SHALL run within a small constant factor of `is_null` rather than ~7× slower. At the reference scale, both `is_null` and `is_not_null` SHALL meet their parity budget under `workload-performance-parity`.

#### Scenario: is_null does not box per row

- **WHEN** `is_null` is evaluated on a column of N rows
- **THEN** the result SHALL be built from the validity mask in a single pass with allocation independent of N beyond the one output buffer
- **AND** no `[]any` of length N SHALL be allocated

#### Scenario: is_not_null does not box per row

- **WHEN** `is_not_null` is evaluated on a column of N rows
- **THEN** the result SHALL be built from the validity state (all-true fill when null-free, mask inversion otherwise) with allocation independent of N beyond the one output buffer
- **AND** no `[]any` of length N SHALL be allocated

#### Scenario: is_not_null matches is_null in cost

- **WHEN** `is_null` and `is_not_null` are benchmarked on the same N-row column
- **THEN** their measured per-row time and allocation SHALL be within a small constant factor of each other (no 7×-style asymmetry)

#### Scenario: is_not_null is the exact inverse of is_null

- **WHEN** both `is_null` and `is_not_null` are evaluated on the same column
- **THEN** for every index the two results SHALL be boolean inverses
