## ADDED Requirements

### Requirement: Matched-right tracking is allocated only when consulted, and is bounded

The equi-join match-tracking buffer — used to emit the unmatched right rows of a `right`/`full` join — SHALL be allocated only for those join modes, and SHALL be a bounded `[]bool` over the right-side height rather than a map that grows with the number of matches. For `inner`, `left`, `semi`, and `anti` joins no match-tracking buffer SHALL be allocated. Marking a matched right row SHALL be an O(1) array write. Join output (rows, values, null-fill) SHALL be identical to the prior implementation for every mode.

#### Scenario: inner and left joins allocate no match-tracking buffer

- **WHEN** an `inner` or `left` join is evaluated
- **THEN** no matched-right tracking structure SHALL be allocated, and the output SHALL equal the prior implementation

#### Scenario: right and full joins track matches in a bounded slice

- **WHEN** a `right` or `full` join records which right rows matched
- **THEN** the tracking SHALL use a `[]bool` of length equal to the right height (not a growing map), and the unmatched right rows SHALL be emitted with the left side null-filled, identical to the prior implementation

#### Scenario: all join modes preserve results

- **WHEN** any of `inner`, `left`, `right`, `full`, `semi`, `anti` is evaluated with the new match tracking
- **THEN** the set of output rows, their values, and null-fill SHALL be identical to the prior implementation
