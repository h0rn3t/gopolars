## Context

The cross-language `bench/top30` suite records `ratio = python_time / go_time` per workload at 1 K and 1 M rows. At 1 M, Python Polars still wins a hard core: `drop_nulls`, `is_not_null`, `drop_nans`, `filter`, `join`, `is_null`, `unique`, `sort`, `over`.

The proposal originally attributed these to per-row `[]any` boxing. **Reconnaissance during implementation falsified that premise** — the code is already typed-gather based:

- `filter` builds an `int` keep-index then gathers each column via `chunk.Column.Slice` (typed). `sort` computes a single argsort (radix above threshold) and gathers all payload columns once. `unique` uses `chunk.GroupIDs` (typed hashing) + gather. `join` pre-sizes its `map[string][]int` from build-side height and builds keys with typed `chunk.AppendRowKey` (no `fmt.Sprintf`). `is_not_null` already avoided `[]any`.
- Column **validity is `[]bool`** (one byte/row), not a packed bitmap.

So the real, measurable costs were narrower: (1) `Slice`/`Gather` always allocated and copied a full `nulls []bool` and did a per-row dtype switch via `copyRow`, even for null-free columns; (2) `is_not_null` used a per-element store loop while `is_null` used `copy()` (memmove); (3) `drop_nulls`/`drop_nans` built their keep-set with a per-row virtual `IsNull()` / boxed `Value()` probe; (4) the join populated an unbounded `map[int]struct{}` of matched right rows for every join mode. And there was no contract enforcing parity across the suite.

This change is cross-cutting (`pkg/chunk`, `pkg/frame`, `pkg/polars`, CI) and performance-complex, so it warrants a design.

## Goals / Non-Goals

**Goals:**
- An enforceable parity gate over every tracked `bench/top30` workload, with per-workload budgets and a committed baseline that fails CI on breach or regression.
- Eliminate the verified, measurable overheads above without changing results.
- Hold output bit-for-bit identical (the existing equality suites are the guardrail).

**Non-Goals:**
- No public API changes, no new dependencies, no change to result semantics or ordering.
- Not closing the absolute 1 M gap to `r_min = 1.0` on every op by brute force: Polars is multi-threaded and chunked, so some ops (filter/join/drop/sort/unique at 1 M) carry a **justified sub-parity budget** at their measured floor rather than a risky single-threaded rewrite.
- The `LazyFrame.sql` 1 M line is a harness artifact (Polars evaluates a trivial cached lazy plan); marked `out_of_scope` in the budget file, not optimized.
- No deep rewrite of eager `filter` to route the predicate through the SIMD `Bitmap` comparison kernels — high risk for modest gain on top of the gather win; deferred behind a documented budget (Open Question Q1).

## Decisions

### D1 — Parity gate as a budget file + Go test over the committed summary

`docs/performance/parity_budgets.json` maps each `object/op` at the reference scale (1 M) to `{ r_min, justification?, out_of_scope? }` plus a global `tolerance`. `bench/top30/baselines/parity_baseline.json` holds the committed measured ratios. `TestParityBudgets` (in `bench/top30`) loads the committed `top30_summary.json`, computes the best ratio per workload, asserts every tracked workload has a budget, fails when `measured < r_min`, fails when `measured` drops below baseline by more than `tolerance`, and requires a justification for any `r_min < 1.0`.

- **Why read the committed summary:** the harness is coupled to Python (it `Skip`s without it), so the gate cannot regenerate numbers in fast CI. Reading the committed artifact makes the gate a Go-only regression lock that runs inside the existing `go test ./...` job and fails if a future committed summary regresses or omits a workload. The nightly `parity-nightly.yml` re-runs the bench against Python and re-checks the gate on fresh numbers.
- **Why a file + checker over hard-coded thresholds:** budgets are reviewable data and can record justified sub-parity floors for multi-threading-bound ops without weakening the gate globally.
- **Alternatives considered:** benchstat self-regression (tracks drift, not *parity*); a Python-driven gate on every push (couples CI to a Python env, duplicates the harness).

### D2 — Null-mask-free typed gather core (`gatherTyped`)

`Slice` and `Gather` delegate to one `gatherTyped(indices, allowNullFill)` that switches on dtype once and runs a tight generic typed copy (`gatherSlice[T]`). When the source has `NullCount() == 0` and no `-1` sentinel is present, the output validity slice is left nil (no `[]bool` allocated, no per-row null writes) and the null count is recorded as a known zero. This is the broad win: it benefits filter, drop, unique, head, tail, sort, and inner-join output. *(Measured: filter ~22% faster, two fewer allocations.)*

- **Why `NullCount()` not `nulls != nil`:** construction routes nil validity through `normalizeNulls`, which allocates an all-false slice — so most null-free columns carry a non-nil mask. The cached null count is the correct predicate and costs one amortized scan.
- **Alternatives considered:** a new `gatherByIndices` helper (rejected — would duplicate `Slice`/`Gather`); keeping `copyRow`'s per-row dtype switch (rejected — branch overhead per row).

### D3 — `is_not_null` memmove-throughput fill

For a null-free column, `is_not_null` fills all-true via exponential copy doubling (`fillTrue`) instead of a per-element store loop, mirroring `is_null`'s `copy()`; for a column with nulls it inverts the mask element-wise. `is_null` additionally skips its copy when `NullCount() == 0`. *(Measured: is_not_null 373 µs → 45 µs at 1 M null-free; asymmetry 9.1× → 1.5×.)*

### D4 — Join: allocate matched-right tracking only when consulted, bounded

The matched-right buffer is only read to emit unmatched right rows of `right`/`full` joins. It is now allocated only for those modes, as a `[]bool` over the right height (O(1) marking) instead of a growing `map[int]struct{}` populated for every mode. `inner`/`left`/`semi`/`anti` allocate none. Win D2 already makes inner-join output gather null-mask-free.

### D5 — Sort gather rides the shared null-mask-free path

The single-argsort gather already in place now flows through `gatherTyped` (D2), so a null-free payload column is materialized without a redundant per-column validity buffer. No change to the argsort, stability, or NaN placement.

## Risks / Trade-offs

- **[Benchmark noise / static committed summary makes the gate misleading]** → The gate is explicitly a regression lock over the committed artifact; the nightly job refreshes against Python. Budgets carry a `tolerance` band.
- **[Leaving output validity nil breaks a consumer assuming non-nil]** → Verified no external code mutates the slice from `Nulls()` or assumes non-nil after a gather; nil already means "no nulls" everywhere (`normalizeNulls`, `IsNull`, `NullCount`). Full suite + `-race` pass.
- **[`drop_*` sharing the input frame introduces aliasing]** → Columns are immutable/copy-on-write (`CloneIfShared`); `Limit`/`Sort` already return the input on no-op. Same pattern.
- **[A workload cannot reach parity single-threaded]** → The budget file allows a justified `r_min < 1.0` so the gate stays honest rather than globally weakened.

## Migration Plan

1. Land the gate (D1) seeded from the committed summary so it is green and locks the status quo. *(done)*
2. Land D2 (typed gather), D3 (`is_not_null`), the column-wise `drop_*`, and D4 (join); each guarded by equality tests. *(done — full suite + `-race` green)*
3. After a fresh `./run-bench.sh --python`, ratchet each improved workload's `r_min` toward `1.0` and refresh the baseline. *(follow-up — requires the Python benchmark run; the gate stays green meanwhile because improvements never trip a min floor)*
- **Rollback:** each optimization is path-local and revertible by commit; the gate can be made warn-only via tolerance if a CI environment proves noisy.

### D6 — Parallel per-column gather (resolves Q1)

A CPU profile of the 4-column 1M `filter` showed the SIMD comparison is only ~2.8% of time (the predicate eval is already parallel and bitmap-based); the cost is the **serial per-column gather** (`gatherSlice[string]` ~9.5%, float/int ~6%) plus GC from the ~24 MB output. So the lever is not the bitmap (already done) but parallelizing the materialization. `takeColumns(keep)` distributes the per-column `Slice` round-robin across at most GOMAXPROCS workers (columns are independent, output slots disjoint) above the existing `parallelFilterThreshold`, staying sequential for small/one-column frames. Wired into `filter` (batch + row-wise fallback), `sort`, and `drop`. *(Measured: filter 1M 3.26 ms → 1.62 ms isolated, ~2×; top30 filter 3.40 → 2.18 ms, sort 21.99 → 18.41 ms. Race-clean.)*

## Open Questions

- **Q1 (resolved, D6):** Eager `filter` was already routed through the SIMD bitmap kernels; the profile showed the win was the parallel gather, not the comparison. Implemented.
- **Q2:** The ratio gate conflates Go time (controlled) with Python time (noisy run-to-run on a shared machine). Budgets are seeded at 0.65× the measured ratio with a 0.40 regression tolerance and a `regression_check_ceiling` so the absolute `r_min` floor is the strongest guarantee; the cleanest long-term fix is to also track a Go-only ns/op baseline (benchstat-style). Revisit if CI proves flaky.
