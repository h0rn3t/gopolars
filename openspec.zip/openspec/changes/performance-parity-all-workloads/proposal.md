## Why

The cross-language `bench/top30` suite shows Python Polars still winning at the 1,000,000-row reference scale on a hard core of workloads — `drop_nulls`, `is_not_null`, `drop_nans`, `filter`, `join`, `is_null`, `unique`, `sort`, and `over`. Investigation during implementation found that the code is **already past per-row `[]any` boxing**: `filter`/`sort`/`unique` materialize via typed index gather, `join` pre-sizes its hash map with typed row keys, and `sort` computes a single argsort. The genuine remaining costs are narrower and verifiable: (1) `Slice`/`Gather` always allocated and copied a full `nulls []bool` even for null-free columns; (2) `is_not_null` ran a per-element store loop while `is_null` used a memmove `copy()`; (3) `drop_nulls`/`drop_nans` built their keep-set with a per-row `IsNull()`/boxed `Value()` probe; (4) the join tracked matched right rows in an unbounded map for every join type. Above all, there was **no enforceable contract** holding every tracked workload to a parity target, so gaps and regressions went uncaught.

## What Changes

- Add an enforceable **workload performance parity gate**: every `bench/top30` workload at the reference scale carries a parity budget (`r_min`, a minimum `python_time/go_time` ratio) in `docs/performance/parity_budgets.json`, checked by a Go test against a committed baseline, failing on budget breach, regression beyond tolerance, or an untracked workload. Budgets default to parity (`r_min = 1.0`); workloads where Polars' multi-threaded chunked engine is fundamentally ahead at 1M carry an explicit justified sub-parity floor.
- **Null-mask-free typed gather**: `chunk.Column.Slice`/`Gather` switch on dtype once and skip the validity buffer entirely for null-free gathers — benefiting filter, drop, unique, head, tail, sort, and join output. *(measured: ~22% faster filter, two fewer allocations.)*
- **`is_not_null` fast path**: fill the all-true result via memmove-backed copy doubling instead of a per-element loop, matching `is_null`. *(measured: 8.4× faster on null-free data; asymmetry 9.1× → 1.5×.)*
- **Column-wise drop**: `drop_nulls`/`drop_nans` build the keep-set by scanning typed validity/value buffers column-at-a-time (skipping null-free columns) and share the input frame when nothing is dropped. *(measured: drop_nulls 4.4× faster at 1M.)*
- **Bounded join match tracking**: allocate the matched-right buffer only for right/full joins, as a bounded `[]bool` instead of a growing map.
- **Parallel per-column gather**: a CPU profile showed eager `filter` was already SIMD-bitmap + parallel-eval based, with the cost in the *serial* per-column gather and GC. `takeColumns` gathers columns concurrently (bounded by GOMAXPROCS) for large multi-column materializations in `filter`/`sort`/`drop`. *(measured: filter 1M ~2× faster in isolation, 3.26 ms → 1.62 ms; top30 filter 3.40 → 2.18 ms, sort 21.99 → 18.41 ms.)*

No public API changes and no change to results — outputs remain identical (guarded by the existing equality test suites); only execution paths, allocation profiles, and the new CI gate change.

## Capabilities

### New Capabilities

- `workload-performance-parity`: A benchmark-backed parity contract — every tracked `bench/top30` workload at the reference scale carries a parity budget versus Python Polars, enforced by a Go test gate against a committed baseline that fails on budget breach, regression beyond tolerance, or an untracked workload.
- `streaming-row-selection`: Row-selecting operations materialize output through a typed gather that allocates a validity buffer only when nulls can actually result, build their keep-set column-at-a-time from typed buffers (no per-row boxed probe), and share the input frame when no rows are removed.

### Modified Capabilities

- `efficient-validity-ops`: `is_not_null` is produced from the validity state with the same bounded-allocation, memmove-throughput profile as `is_null` rather than a per-element store loop.
- `columnar-join`: The matched-right tracking buffer is allocated only for the join modes that consult it (right/full) and is a bounded `[]bool` over the right height, not a map that grows with match count.
- `parallel-numeric-sort`: The single-argsort gather that materializes payload columns skips the redundant validity allocation for null-free columns (via the shared null-mask-free gather), so a full-frame numeric sort no longer allocates a per-column null buffer it does not need.

## Impact

- **Affected code**: `pkg/chunk` (typed gather core in `Slice`/`Gather`), `pkg/frame` (`DropNulls`/`DropNaNs`, `join`), `pkg/polars` (`IsNull`/`IsNotNull`).
- **Benchmarks / CI**: new `TestParityBudgets` gate in `bench/top30` (runs in the existing `go test ./...` job), a `parity-nightly.yml` Python-refresh workflow, `docs/performance/parity_budgets.json`, and `bench/top30/baselines/parity_baseline.json`.
- **Dependencies**: none added.
- **Risk**: execution-path changes are guarded by the existing "accelerated output equals prior path" equality scenarios; the full suite (34 packages) and `-race` on touched packages pass.
