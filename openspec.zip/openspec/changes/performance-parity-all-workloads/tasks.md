## 1. Parity gate and budgets (D1)

- [x] 1.1 Add `docs/performance/parity_budgets.json` mapping every `object/op` emitted by `bench/top30` at the 1 M reference scale to `{ r_min, justification? }` plus a global `tolerance`; seed `r_min = min(1.0, best*0.9)` from the committed summary so the gate starts green.
- [x] 1.2 Mark the `LazyFrame/sql` 1 M harness artifact `out_of_scope` with a justification rather than a parity target.
- [x] 1.3 Commit a versioned baseline of measured ratios (`bench/top30/baselines/parity_baseline.json`) from the last committed `top30_summary.json`.
- [x] 1.4 Implement `TestParityBudgets` in `bench/top30`: load `top30_summary.json`, assert every tracked workload has a budget, fail when `measured < r_min`, fail when `measured` drops below baseline by more than `tolerance`, and require a justification for `r_min < 1.0`.
- [x] 1.5 Wire the gate into CI: it runs Go-only inside the existing `go test -race ./...` job on push; add `parity-nightly.yml` to refresh against Python Polars nightly (resolves the push-vs-nightly question).
- [x] 1.6 Document the parity contract and `ratio = python_time / go_time` convention in `bench/top30/README.md`.

## 2. Null-mask-free typed gather (D2)

- [x] 2.1 Add `gatherTyped` + generic `gatherSlice[T]` in `pkg/chunk`; route `Slice` (no fill) and `Gather` (null-fill) through it, switching on dtype once.
- [x] 2.2 Skip the validity buffer when `NullCount() == 0` and no `-1` sentinel; record a known-zero null count. Verified output equals the prior path via the full chunk/frame/series/polars suites.
- [x] 2.3 Confirm the win: filter ~22% faster, two fewer allocations (the eliminated output `nulls` buffers).

## 3. Row-selecting operations (streaming-row-selection)

- [x] 3.1 `filter`, `head`, `tail`, `unique` materialize through the null-mask-free `Slice` (inherited from D2) — no code change needed beyond D2; allocation drops for null-free columns.
- [x] 3.2 Rewrite `DropNulls`/`DropNaNs` to build the keep-set column-at-a-time from typed validity/`float64` buffers (skipping null-free columns), not a per-row `IsNull()`/boxed `Value()` probe.
- [x] 3.3 Share the input frame when nothing is dropped (matching the `Limit`/`Sort` no-op pattern).
- [x] 3.4 Add equality tests across empty/half/full selectivity, the drop_nans null-retention case, and a no-op share (≤1 alloc) test (`pkg/polars/drop_perf_test.go`).
- [x] 3.5 Add a `drop_nulls` 1 M benchmark; measured 20.7 ms → 4.68 ms (4.4× faster).

## 4. Validity kernel: is_not_null fast path (D3, efficient-validity-ops)

- [x] 4.1 Fill `is_not_null` all-true via memmove-backed copy doubling (`fillTrue`) for null-free columns; invert the mask element-wise otherwise. Skip `is_null`'s copy when `NullCount() == 0`.
- [x] 4.2 Add a null-free correctness test and an allocation-does-not-scale test (no `[]any` of length N).
- [x] 4.3 Add `BenchmarkIsNullNullFree`/`BenchmarkIsNotNullNullFree`; measured asymmetry 9.1× → 1.5× (is_not_null 373 µs → 45 µs at 1 M).

## 5. Join match-tracking allocation (D4, columnar-join)

- [x] 5.1 Allocate the matched-right buffer only for `right`/`full` joins, as a bounded `[]bool` over the right height instead of a growing `map[int]struct{}`; mark in O(1).
- [x] 5.2 Verify all modes (inner/left/right/full/semi/anti/cross) still produce identical rows and null-fill via the existing join equality suites.

## 6. Sort gather (D5, parallel-numeric-sort)

- [x] 6.1 The single-argsort payload gather now rides the D2 null-mask-free path; no per-column validity buffer for null-free columns. Sorted order/stability/NaN placement unchanged (existing sort suites pass).

## 7. Verification and finalization

- [x] 7.1 `go build ./...`, `go vet` on touched packages, full `go test ./...` (34 packages pass), and `-race` on `pkg/chunk`/`pkg/frame`/`pkg/series`/`pkg/polars`/`bench/top30` all green.
- [x] 7.2 Ran the `bench/top30 --light --python` suite (polars 1.40.1) to regenerate `top30_summary.{json,csv,md}`. Confirmed wins at 1M: drop_nulls 0.038→1.45 (now beats Polars), is_not_null 0.034→0.236, sort 0.354→0.918, filter 0.116→0.244, join 0.146→0.192, unique 0.284→0.358, is_null 0.206→0.256.
- [x] 7.3 Ratcheted `r_min` from the fresh numbers (drop_nulls→1.0, sort 0.32→0.78, is_not_null 0.034→0.20, …), refreshed `parity_baseline.json` from the same run, and widened the gate (tolerance 0.40 + `regression_check_ceiling` 3.0 so nanosecond-scale ops with large cross-run variance are r_min-gated only). Gate passes.
- [x] 7.4 Regenerated `bench/comparison_table.md` from the fresh summaries (drop_nulls Py ×34→Go ×1.5, sort ×2.8→×1.1, is_not_null ×29.7→×4.3, filter ×10.7→×4.1, join ×7.8→×5.2).
- [x] 7.5 (Q1 resolved) Eager `filter` is already routed through the SIMD bitmap kernels (`evalbatch` → `CompareGTFloat64Bitmap`/`BitmapAnd` → `CompressIndices`) with a parallel predicate eval. A CPU profile showed the comparison is only ~2.8% of time; the cost is the **serial per-column gather** plus GC. Added a bounded parallel `takeColumns` gather (filter/sort/drop) → filter 1M ~2× faster in isolation (3.26 ms → 1.62 ms), top30 filter 3.40 ms → 2.18 ms, sort 21.99 ms → 18.41 ms. Re-seeded budgets/baseline (v0.3); gate green.
