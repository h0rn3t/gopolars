# Design — Full SQL Surface

## Context

The SQL engine lives in `pkg/sql/` (lexer, recursive-descent parser, expression parser, function catalog, binder with a `Catalog` interface, planner producing `logical.Node`s) and is exposed via `pkg/polars/sqlcontext.go` (`SQLContext` with a `map[string]frame.DataFrame` registry guarded by an `RWMutex`). Today `parser.go` rejects everything except SELECT with explicit "unsupported" errors, `from.go` rejects table functions, and `functions.go` is a single dispatch covering ~26 scalar + 6 aggregate + 6 window functions. IO readers for CSV/Parquet/JSON/IPC already exist under `pkg/io/`. Expression evaluation is op-code based (`pkg/expr/eval.go`, `pkg/expr/evalbatch/`), and several SQL-needed operations (e.g. `ENDS_WITH`, `LPAD`, `SPLIT_PART`, `INITCAP`, `ATAN2`, `CONCAT_WS`) have no existing Expr method or eval kernel yet.

## Goals / Non-Goals

**Goals:**
- Polars-SQL-parity DDL: `CREATE TABLE AS`, `DROP TABLE [IF EXISTS]`, `TRUNCATE TABLE`, `SHOW TABLES`, `EXPLAIN`, all session-scoped to one `SQLContext`.
- File-reading table functions (`read_csv`, `read_parquet`, `read_json`, `read_ipc`) usable wherever a table name is allowed.
- Function catalog expansion (string, math, aggregate, window, conditional, temporal) per the `sql-function-catalog` spec.
- Keep the existing `SQLContext` interface unchanged; only extend `Execute` behavior.

**Non-Goals:**
- DML (`INSERT`, `UPDATE`, `DELETE`) and `ALTER TABLE` — Polars SQL also rejects these; they stay as clear errors.
- Read options on table functions (delimiters, schema overrides, glob patterns) — paths only, default reader options; options can be a follow-up.
- Persistent catalogs, views, or cross-context sharing.
- New window frame specifications (ROWS BETWEEN ...) — only the function set grows, the OVER machinery stays.

## Decisions

### 1. Statement-level AST instead of growing `ParsedQuery`
`Parse` currently returns a SELECT-shaped `ParsedQuery`. Introduce a small statement union (e.g. `Statement` interface with `SelectStatement{*ParsedQuery}`, `CreateTableAs{Name, Select}`, `DropTable{Name, IfExists}`, `TruncateTable{Name}`, `ShowTables{}`, `Explain{Select}`) and a top-level `ParseStatement`. The existing `Parse` stays as a thin wrapper for SELECT so current callers don't churn.
**Alternative considered:** flags on `ParsedQuery` — rejected; DDL has different execution semantics (registry mutation vs. plan production) and conflating them spreads conditionals through binder/planner.

### 2. DDL executes in `SQLContext`, not in the planner
`CREATE/DROP/TRUNCATE/SHOW TABLES` are registry operations, so `sqlContext.Execute` dispatches on statement type: SELECT/EXPLAIN go through bind→plan as today; DDL statements operate on the `tables` map under the existing mutex and return small literal frames (`response` column for CREATE/DROP/TRUNCATE, `name` column for SHOW TABLES). `CREATE TABLE AS` plans and **collects** the inner SELECT eagerly (the registry stores materialized `frame.DataFrame`s), then registers the result.
**Alternative considered:** lazy CTAS (store the LazyFrame) — rejected; registry is typed to DataFrame, and Polars CTAS is eager too. Eager also gives the "error → registry untouched" guarantee cheaply.

### 3. EXPLAIN reuses the existing plan rendering
`EXPLAIN <select>` binds and plans, then renders the `logical.Node` chain using the same textual representation behind the existing `test/unit/testdata/sql_explain.golden` machinery, returned as a single-column frame (one row per plan line). No new plan formatter.

### 4. Table functions resolve at bind time through a widened catalog source
`from.go` parses `identifier '(' string-literal ')'` in table position into a `TableFn{Name, Path, Alias}` reference (arity/literal checks at parse time; unknown names rejected at bind time). The binder resolves a `TableFn` by invoking the matching `pkg/io` reader and treating the loaded frame exactly like a registered table (schema available for column resolution, aliasing, joins, CTEs). Reading happens once at bind/plan time, eagerly.
**Alternative considered:** a lazy scan node executed at `Collect` time — rejected for this change; the binder needs the schema anyway to validate column references, and our readers don't expose schema-only peeking. Eager read keeps the pipeline unchanged. The error-on-missing-file consequently surfaces from `Execute` (spec allows either).
**Dependency note:** `pkg/sql` must not import `pkg/io` directly if that creates a cycle through `pkg/polars`; if so, the table-function reader hook is injected as a `map[string]func(path string) (frame.DataFrame, error)` supplied by `pkg/polars` alongside the `Catalog`.

### 5. Function catalog becomes table-driven
Replace the long switch in `functions.go` with a registry: `map[string]fnSpec` where `fnSpec` holds canonical name, min/max arity, builder `func(args []expr.Expr, rawArgs []sqlExprNode) (expr.Expr, error)`, and kind (scalar/aggregate/window). Aliases map to the same spec. This makes arity/unknown-name errors uniform (per the spec's error-behavior requirement) and keeps each new function a one-entry addition.
**Alternative considered:** keep growing the switch — rejected; with ~50 new entries the switch becomes the bug farm, and consistent error messages are hard to maintain.

### 6. Missing expression kernels are added in `pkg/expr`, not faked in SQL
Functions with no current Expr support get small Expr methods + eval kernels following the existing op-code pattern (`pkg/expr/sql_ops.go` is the precedent for SQL-motivated helpers): `EndsWith`, `StrPadStart`/`StrPadEnd`, `StrSplitPart`, `StrToTitle` (INITCAP), `StrPos`, `ConcatWS` (variadic via fold over `StrConcat` with separator), `Atan2`, plus temporal `DtOrdinalDay` if absent. Functions that map onto existing methods (`Sign`, `Cbrt`, `Log/Log10/Log1p`, trig, `Std`, `Var`, `Median`, `First`, `Last`, `Rank`, `Shift` for LAG/LEAD, `Reverse`, `StartsWith`, `StrLike` for REGEXP_LIKE) are catalog-only work. `OCTET_LENGTH`/`BIT_LENGTH` derive from byte length (`StrLen` semantics checked; bit length = 8×octet via arithmetic). `GREATEST`/`LEAST` fold over pairwise `Where(a.Gt(b), a, b)`-style max/min expressions to stay row-wise.

### 7. Window additions ride the existing OVER path
`RANK`/`DENSE_RANK` map to `Rank()` variants over the partition; `LAG`/`LEAD` map to `Shift(±offset)` with optional `FillNull(default)`; `FIRST_VALUE`/`LAST_VALUE` map to `First()`/`Last()` over the partition with the existing ORDER BY handling. No new window executor; if `Rank` lacks a dense mode, add it as an eval-kernel option first.

### 8. `COUNT(DISTINCT col)` is parsed as a function modifier
The expression parser accepts `DISTINCT` immediately after `COUNT(`, setting a flag on the function-call node; the catalog builder maps it to `NUnique()`. Other aggregates with DISTINCT are rejected with a clear error (Polars parity).

## Risks / Trade-offs

- [Eager table-function reads make `Execute` do IO] → Acceptable: matches the binder's schema needs; documented in spec scenarios ("Execute or subsequent collection returns an error"). Revisit with a lazy scan node if/when readers expose schema peeking.
- [Import cycle `pkg/sql` → `pkg/io` → `pkg/polars`] → Mitigated by injecting reader funcs through the binder's catalog parameter (Decision 4); verify with `go build ./...` early in implementation.
- [Semantics drift vs. py-polars on edge cases (NULL padding in LPAD, SPLIT_PART out-of-range index, LAST_VALUE default frame)] → Mitigated by adding parity tests in `test/parity/unit/sql/` mirroring py-polars outputs for each new function; where py-polars behavior is surprising, match it and note it in the test.
- [Catalog refactor regresses existing 26 functions] → Mitigated by porting the existing switch entries first under the new registry with the current tests green before adding new entries.
- [CTAS replacing existing tables silently] → Matches `Register`'s existing overwrite behavior and Polars semantics; called out in spec so it's deliberate.
- [`unsupported_test.go` cases flip meaning] → Tests for CREATE/DROP/TRUNCATE/SHOW/EXPLAIN/read_csv move to positive suites in the same commit that enables each statement, so the suite never lies.

## Open Questions

- None blocking. Reader options for table functions (`read_csv('x.csv', delimiter => ';')`) deliberately deferred.
