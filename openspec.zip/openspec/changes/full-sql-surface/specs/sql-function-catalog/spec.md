# sql-function-catalog — Complete SQL Function Catalog

## ADDED Requirements

### Requirement: Extended string functions
The SQL function catalog SHALL support the following string functions with Polars-SQL-compatible names and semantics, mapped onto the expression API: `STARTS_WITH(s, prefix)`, `ENDS_WITH(s, suffix)`, `LEFT(s, n)`, `RIGHT(s, n)`, `LTRIM(s)`, `RTRIM(s)`, `REVERSE(s)`, `INITCAP(s)`, `LPAD(s, n, fill)`, `RPAD(s, n, fill)`, `SPLIT_PART(s, sep, n)`, `STRPOS(s, sub)` (alias `POSITION`), `OCTET_LENGTH(s)`, `BIT_LENGTH(s)`, `REGEXP_LIKE(s, pattern)`, and `CONCAT_WS(sep, s1, s2, ...)`. Function names SHALL be case-insensitive. NULL inputs SHALL propagate as NULL outputs.

#### Scenario: ENDS_WITH in a filter
- **WHEN** `SELECT name FROM t WHERE ENDS_WITH(name, 'son')` is executed
- **THEN** only rows whose `name` ends with `son` are returned

#### Scenario: SPLIT_PART extracts a field
- **WHEN** `SELECT SPLIT_PART(email, '@', 2) AS domain FROM t` is executed
- **THEN** the result contains the substring after the `@` for each row

#### Scenario: CONCAT_WS joins with separator
- **WHEN** `SELECT CONCAT_WS('-', a, b, c) FROM t` is executed
- **THEN** each row contains `a-b-c` with the separator between non-null parts

### Requirement: Extended math functions
The catalog SHALL support: `SIGN`, `CBRT`, `LOG(x)` (natural log alias of `LN`), `LOG(base, x)`, `LOG2`, `LOG10`, `LOG1P`, `PI()`, `DEGREES`, `RADIANS`, `SIN`, `COS`, `TAN`, `COT`, `ASIN`, `ACOS`, `ATAN`, `ATAN2(y, x)`, mapped to the corresponding Expr math methods. Results SHALL be Float64 consistent with the expression engine.

#### Scenario: Trig function in projection
- **WHEN** `SELECT SIN(angle) FROM t` is executed
- **THEN** the result equals applying the `Sin` expression to the `angle` column

#### Scenario: Two-argument LOG
- **WHEN** `SELECT LOG(2, x) FROM t` is executed
- **THEN** each value is the base-2 logarithm of `x`

#### Scenario: PI as a zero-argument function
- **WHEN** `SELECT PI()` is projected in a query
- **THEN** every row contains the Float64 value of π

### Requirement: Extended aggregate functions
The catalog SHALL support the aggregates `STDDEV` (aliases `STDEV`, `STDDEV_SAMP`), `VARIANCE` (aliases `VAR`, `VAR_SAMP`), `MEDIAN`, `FIRST`, and `LAST` in SELECT and HAVING under GROUP BY, mapped to the corresponding Expr aggregation methods. `COUNT(DISTINCT col)` SHALL count distinct non-null values per group.

#### Scenario: STDDEV per group
- **WHEN** `SELECT g, STDDEV(x) FROM t GROUP BY g` is executed
- **THEN** each group row contains the sample standard deviation of `x`

#### Scenario: COUNT DISTINCT
- **WHEN** `SELECT g, COUNT(DISTINCT x) FROM t GROUP BY g` is executed
- **THEN** each group row contains the number of distinct non-null `x` values

### Requirement: Extended window functions
The catalog SHALL support `RANK()`, `DENSE_RANK()`, `LAG(expr [, offset [, default]])`, `LEAD(expr [, offset [, default]])`, `FIRST_VALUE(expr)`, and `LAST_VALUE(expr)` with `OVER (PARTITION BY ... ORDER BY ...)` clauses, consistent with the existing window-function execution path. `LAG`/`LEAD` default offset SHALL be 1 and default fill SHALL be NULL.

#### Scenario: RANK over a partition
- **WHEN** `SELECT name, RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS r FROM t` is executed
- **THEN** rows in each `dept` are ranked by descending salary with ties sharing a rank

#### Scenario: LAG with default offset
- **WHEN** `SELECT x, LAG(x) OVER (ORDER BY ts) FROM t` is executed
- **THEN** each row contains the previous row's `x` in `ts` order, with NULL for the first row

### Requirement: Extended conditional and null-handling functions
The catalog SHALL support `IFNULL(a, b)` (two-argument COALESCE), `IF(cond, then, else)`, `GREATEST(a, b, ...)`, and `LEAST(a, b, ...)`. `GREATEST`/`LEAST` SHALL operate element-wise across their arguments.

#### Scenario: IF expression
- **WHEN** `SELECT IF(x > 0, 'pos', 'neg') FROM t` is executed
- **THEN** each row contains `pos` where `x > 0` and `neg` otherwise

#### Scenario: GREATEST across columns
- **WHEN** `SELECT GREATEST(a, b, c) FROM t` is executed
- **THEN** each row contains the row-wise maximum of `a`, `b`, `c`

### Requirement: Extended temporal functions
The catalog SHALL support `DATE_PART('<part>', expr)` and `EXTRACT(<part> FROM expr)` for at least the parts `year`, `month`, `day`, `hour`, `minute`, `second`, `dow`/`weekday`, plus the named extractors `DAYOFWEEK(expr)` and `DAYOFYEAR(expr)`/`ORDINAL_DAY(expr)` where the expression engine provides the extraction. Unsupported parts SHALL produce a clear error naming the part.

#### Scenario: EXTRACT year
- **WHEN** `SELECT EXTRACT(YEAR FROM dt) FROM t` is executed
- **THEN** the result matches the `DtYear` expression applied to `dt`

#### Scenario: DATE_PART with unsupported part
- **WHEN** `SELECT DATE_PART('femtosecond', dt) FROM t` is executed
- **THEN** an error is returned naming the unsupported part

### Requirement: Catalog error behavior
Unknown function names SHALL return an error identifying the function. Wrong arity or invalid argument types for cataloged functions SHALL return an error naming the function and the expected signature. All function names and aliases SHALL be matched case-insensitively.

#### Scenario: Unknown function
- **WHEN** `SELECT FROBNICATE(x) FROM t` is executed
- **THEN** an error identifies `FROBNICATE` as an unknown function

#### Scenario: Wrong arity
- **WHEN** `SELECT ATAN2(x) FROM t` is executed
- **THEN** an error states `ATAN2` requires two arguments
