# sql-ddl — Session-Scoped DDL Statements

## ADDED Requirements

### Requirement: CREATE TABLE AS SELECT
`SQLContext.Execute` SHALL support `CREATE TABLE <name> AS <select-statement>`. The statement SHALL evaluate the SELECT against the context's registered tables and register the materialized result under `<name>` in the context's table registry. Executing the statement SHALL return a result frame matching Polars semantics (a one-row frame reporting the operation, e.g. a `response` column with value `CREATE TABLE`). If a table with the same name is already registered, it SHALL be replaced.

#### Scenario: Create table from query
- **WHEN** `CREATE TABLE adults AS SELECT name FROM people WHERE age >= 18` is executed on a context where `people` is registered
- **THEN** a subsequent `SELECT * FROM adults` on the same context returns the filtered rows, and `Tables()` includes `adults`

#### Scenario: Create table replaces existing registration
- **WHEN** `CREATE TABLE t AS SELECT ...` is executed and `t` is already registered
- **THEN** the prior registration is replaced and subsequent queries against `t` see the new data

#### Scenario: Create table from invalid query
- **WHEN** the SELECT body references an unregistered table or fails to bind
- **THEN** `Execute` returns an error and the registry is not modified

### Requirement: DROP TABLE
`SQLContext.Execute` SHALL support `DROP TABLE <name>` and `DROP TABLE IF EXISTS <name>`. `DROP TABLE` SHALL remove the named table from the context's registry; dropping an unregistered table SHALL return an error unless `IF EXISTS` is specified, in which case it SHALL be a no-op.

#### Scenario: Drop registered table
- **WHEN** `DROP TABLE people` is executed on a context where `people` is registered
- **THEN** `Tables()` no longer includes `people` and subsequent queries against it fail to bind

#### Scenario: Drop missing table without IF EXISTS
- **WHEN** `DROP TABLE missing` is executed and `missing` is not registered
- **THEN** `Execute` returns an error naming the missing table

#### Scenario: Drop missing table with IF EXISTS
- **WHEN** `DROP TABLE IF EXISTS missing` is executed and `missing` is not registered
- **THEN** `Execute` succeeds without modifying the registry

### Requirement: TRUNCATE TABLE
`SQLContext.Execute` SHALL support `TRUNCATE TABLE <name>`. The statement SHALL replace the registered table with an empty frame that preserves the original schema (column names and dtypes). Truncating an unregistered table SHALL return an error.

#### Scenario: Truncate registered table
- **WHEN** `TRUNCATE TABLE people` is executed on a context where `people` is registered with rows
- **THEN** a subsequent `SELECT * FROM people` returns zero rows with the original column names and dtypes

#### Scenario: Truncate missing table
- **WHEN** `TRUNCATE TABLE missing` is executed and `missing` is not registered
- **THEN** `Execute` returns an error naming the missing table

### Requirement: SHOW TABLES
`SQLContext.Execute` SHALL support `SHOW TABLES`, returning a frame with a single `name` column (dtype String) listing all registered table names in sorted order.

#### Scenario: Show tables on populated context
- **WHEN** `SHOW TABLES` is executed on a context with tables `b` and `a` registered
- **THEN** the result frame has one `name` column with rows `a`, `b` in sorted order

#### Scenario: Show tables on empty context
- **WHEN** `SHOW TABLES` is executed on a context with no registered tables
- **THEN** the result frame has a `name` column and zero rows

### Requirement: EXPLAIN
`SQLContext.Execute` SHALL support `EXPLAIN <select-statement>`. The statement SHALL parse, bind, and plan the SELECT without executing it, and return a frame describing the logical plan (one plan-text row per line, matching the engine's existing plan rendering).

#### Scenario: Explain a valid query
- **WHEN** `EXPLAIN SELECT a FROM t WHERE a > 1` is executed on a context where `t` is registered
- **THEN** the result frame contains the logical plan text and the underlying query is not executed

#### Scenario: Explain an invalid query
- **WHEN** the inner SELECT fails to parse or bind
- **THEN** `Execute` returns the parse/bind error

### Requirement: DDL statement isolation per context
DDL statements SHALL only affect the `SQLContext` they are executed on. Tables created, dropped, or truncated in one context SHALL NOT be visible in or affect other contexts.

#### Scenario: CREATE TABLE is context-local
- **WHEN** `CREATE TABLE t AS SELECT ...` is executed on context A and context B exists with its own registry
- **THEN** `t` is queryable on context A and remains unknown to context B

### Requirement: Unsupported DML remains rejected
`INSERT`, `UPDATE`, `DELETE`, and `ALTER TABLE` statements SHALL continue to return clear "unsupported" parse errors, consistent with Polars SQL.

#### Scenario: INSERT remains unsupported
- **WHEN** `INSERT INTO t VALUES (1)` is executed
- **THEN** `Execute` returns an error stating the statement is unsupported
