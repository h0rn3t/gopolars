# sql-table-functions — File-Reading Table Functions in FROM

## ADDED Requirements

### Requirement: read_csv table function
The SQL engine SHALL support `read_csv('<path>')` as a table reference in FROM and JOIN clauses. The function SHALL read the CSV file via the existing `pkg/io/csv` reader with default options (header row, type inference) and expose the result as a table whose schema is derived from the file.

#### Scenario: Select from a CSV file
- **WHEN** `SELECT * FROM read_csv('data.csv')` is executed and `data.csv` exists
- **THEN** the result matches reading the file with the Go CSV reader and selecting all columns

#### Scenario: CSV file does not exist
- **WHEN** `SELECT * FROM read_csv('missing.csv')` is executed
- **THEN** `Execute` (or subsequent collection) returns an error that names the path

### Requirement: read_parquet table function
The SQL engine SHALL support `read_parquet('<path>')` as a table reference in FROM and JOIN clauses, backed by the existing `pkg/io/parquet` reader.

#### Scenario: Select from a Parquet file
- **WHEN** `SELECT a, b FROM read_parquet('data.parquet')` is executed and the file exists with columns `a`, `b`
- **THEN** the result matches reading the file with the Go Parquet reader and projecting `a`, `b`

### Requirement: read_json table function
The SQL engine SHALL support `read_json('<path>')` as a table reference in FROM and JOIN clauses, backed by the existing `pkg/io/json` reader (NDJSON and JSON as the reader supports).

#### Scenario: Select from a JSON file
- **WHEN** `SELECT * FROM read_json('data.ndjson')` is executed and the file exists
- **THEN** the result matches reading the file with the Go JSON reader

### Requirement: read_ipc table function
The SQL engine SHALL support `read_ipc('<path>')` as a table reference in FROM and JOIN clauses, backed by the existing `pkg/io/ipc` reader.

#### Scenario: Select from an IPC file
- **WHEN** `SELECT * FROM read_ipc('data.arrow')` is executed and the file exists
- **THEN** the result matches reading the file with the Go IPC reader

### Requirement: Table function aliasing and composition
Table functions SHALL accept an optional alias (`FROM read_csv('x.csv') AS t` or `FROM read_csv('x.csv') t`) and SHALL be usable anywhere a named table is allowed: in JOIN clauses, in CTE bodies, and in subqueries. Qualified column references SHALL resolve against the alias.

#### Scenario: Aliased table function in a join
- **WHEN** `SELECT t.a, u.b FROM read_csv('x.csv') AS t INNER JOIN people AS u ON t.id = u.id` is executed
- **THEN** the join executes with the file-backed table on the left and qualified columns resolve via the aliases

#### Scenario: Table function inside a CTE
- **WHEN** `WITH src AS (SELECT * FROM read_parquet('x.parquet')) SELECT count(*) FROM src` is executed
- **THEN** the CTE materializes from the file and the outer query aggregates over it

### Requirement: Table function argument validation
Table function arguments SHALL be validated at parse/bind time: the path argument MUST be a single string literal. A non-literal argument, wrong arity, or an unknown table function name SHALL produce a clear error.

#### Scenario: Unknown table function
- **WHEN** `SELECT * FROM read_xlsx('x.xlsx')` is executed
- **THEN** an error is returned identifying `read_xlsx` as an unknown table function

#### Scenario: Non-literal path argument
- **WHEN** `SELECT * FROM read_csv(col)` is executed
- **THEN** a parse/bind error is returned stating the path must be a string literal
