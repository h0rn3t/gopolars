# Full SQL Surface: DDL, SQL Table Functions, Complete Function Catalog

## Why

gopolars' SQL engine is SELECT-only with a minimal function catalog (~26 scalar, 6 aggregate, 6 window functions), while py-polars' SQL interface additionally supports session DDL (`CREATE TABLE AS`, `DROP TABLE`, `TRUNCATE TABLE`, `SHOW TABLES`, `EXPLAIN`), file-reading table functions in FROM (`read_csv`, `read_parquet`, `read_json`, `read_ipc`), and a much richer function catalog. Closing this gap removes the biggest remaining SQL parity holes and lets users run real-world Polars SQL workloads unchanged.

## What Changes

- **DDL statements** in `SQLContext.Execute`: `CREATE TABLE <name> AS <select>`, `DROP TABLE [IF EXISTS] <name>`, `TRUNCATE TABLE <name>`, `SHOW TABLES`, and `EXPLAIN <select>` — matching Polars SQL semantics (session-scoped catalog mutation; results returned as DataFrames where Polars returns them).
- **SQL table functions** in FROM clauses: `read_csv('path')`, `read_parquet('path')`, `read_json('path')`, `read_ipc('path')`, backed by the existing `pkg/io` readers, with alias support (`FROM read_csv('x.csv') AS t`).
- **Complete function catalog** expansion to match Polars SQL:
  - String: `STARTS_WITH`, `ENDS_WITH`, `LEFT`, `RIGHT`, `LTRIM`, `RTRIM`, `REVERSE`, `INITCAP`, `LPAD`, `RPAD`, `SPLIT_PART`, `STRPOS`/`POSITION`, `OCTET_LENGTH`, `BIT_LENGTH`, `REGEXP_LIKE`, `CONCAT_WS`, `STRING_TO_ARRAY` (where Expr support exists)
  - Math: `SIGN`, `CBRT`, `LOG`, `LOG2`, `LOG10`, `LOG1P`, `PI`, `DEGREES`, `RADIANS`, trig (`SIN`, `COS`, `TAN`, `ASIN`, `ACOS`, `ATAN`, `ATAN2`, `COT`) and degree variants where Expr support exists
  - Aggregates: `STDDEV`/`STDEV`, `VARIANCE`/`VAR`, `MEDIAN`, `FIRST`, `LAST`, `COUNT(DISTINCT col)`
  - Window: `RANK`, `DENSE_RANK`, `LAG`, `LEAD`, `FIRST_VALUE`, `LAST_VALUE`
  - Conditional/null: `IFNULL`, `IF`, `GREATEST`, `LEAST`
  - Temporal: `DATE_PART`/`EXTRACT`, `STRFTIME`, `ORDINAL_DAY`/`DAYOFYEAR`, `DAYOFWEEK`, `EPOCH`-style extraction where Expr support exists
- Existing argument restrictions relaxed where the Expr API allows (e.g., `REPLACE`/`SUBSTR` literal-only arguments stay as-is unless trivially liftable).
- Unsupported-statement errors updated: statements that become supported no longer error; remaining unsupported DML (`INSERT`, `UPDATE`, `DELETE`) keeps clear errors, matching Polars (which also rejects them).

## Capabilities

### New Capabilities

- `sql-ddl`: Session-scoped DDL statements (`CREATE TABLE AS`, `DROP TABLE`, `TRUNCATE TABLE`, `SHOW TABLES`, `EXPLAIN`) executed through `SQLContext`, mutating/inspecting the context's table registry.
- `sql-table-functions`: File-reading table functions (`read_csv`, `read_parquet`, `read_json`, `read_ipc`) usable as table references in FROM/JOIN clauses.
- `sql-function-catalog`: The expanded scalar, aggregate, window, conditional, and temporal SQL function catalog with Polars-SQL-compatible names, aliases, and semantics.

### Modified Capabilities

<!-- No existing specs in openspec/specs/ cover SQL; the SELECT-only engine spec lives in an archived change. No requirement-level changes to existing main specs. -->
None.

## Impact

- **Code**: `pkg/sql/parser.go` (statement dispatch), `pkg/sql/from.go` (table function parsing), `pkg/sql/functions.go` (catalog), `pkg/sql/binder.go` (catalog mutation for DDL, table-function schema resolution), `pkg/sql/planner.go` (new plan nodes / scan sources), `pkg/polars/sqlcontext.go` (DDL execution, registry mutation), `pkg/io/*` (consumed, not changed).
- **API**: `SQLContext.Execute` gains statements that return result frames (`SHOW TABLES`, `EXPLAIN`) or empty/affected results (`CREATE`/`DROP`/`TRUNCATE`). `SQLContext` interface unchanged; behavior of `Execute` extended.
- **Tests**: extend `pkg/sql/*_test.go`, `test/parity/unit/sql/`, `test/conformance/`; `unsupported_test.go` cases for now-supported statements move to positive tests.
- **Dependencies**: none added; table functions reuse `pkg/io/csv`, `pkg/io/parquet`, `pkg/io/json`, `pkg/io/ipc`.
