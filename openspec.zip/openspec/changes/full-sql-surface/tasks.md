# Tasks — Full SQL Surface

## 1. Statement AST and parser foundation

- [x] 1.1 Add `Statement` union types (`SelectStatement`, `CreateTableAs`, `DropTable`, `TruncateTable`, `ShowTables`, `Explain`) and `ParseStatement` entry point in `pkg/sql/parser.go`; keep `Parse` as a SELECT wrapper
- [x] 1.2 Parse `CREATE TABLE <name> AS <select>` (reject other CREATE forms with clear errors)
- [x] 1.3 Parse `DROP TABLE [IF EXISTS] <name>`, `TRUNCATE TABLE <name>`, `SHOW TABLES`, `EXPLAIN <select>`
- [x] 1.4 Keep `INSERT`/`UPDATE`/`DELETE`/`ALTER` as explicit unsupported errors; update `pkg/sql/unsupported_test.go` and `test/parity/unit/sql/unsupported_test.go` (move newly supported statements out)

## 2. DDL execution in SQLContext

- [x] 2.1 Dispatch on statement type in `pkg/polars/sqlcontext.go` `Execute`; route SELECT through the existing bind→plan path
- [x] 2.2 Implement `CREATE TABLE AS`: plan + collect inner SELECT, register result under name (overwrite allowed), return `response` frame; registry untouched on error
- [x] 2.3 Implement `DROP TABLE` (+ `IF EXISTS` no-op) and `TRUNCATE TABLE` (empty frame preserving schema/dtypes), with errors naming missing tables
- [x] 2.4 Implement `SHOW TABLES` returning sorted `name` column frame
- [x] 2.5 Implement `EXPLAIN` returning the rendered logical plan (reuse existing plan text rendering) without executing
- [x] 2.6 Tests: unit tests in `pkg/sql`/`pkg/polars` plus conformance tests covering all sql-ddl spec scenarios, including per-context isolation

## 3. SQL table functions

- [x] 3.1 Parse `read_csv|read_parquet|read_json|read_ipc('<literal>') [AS alias]` in table position (`pkg/sql/from.go`), with parse-time arity/literal validation and unknown-name errors
- [x] 3.2 Add reader injection to the binder (table-function resolver map alongside `Catalog`) to avoid import cycles; wire `pkg/io/{csv,parquet,json,ipc}` readers from `pkg/polars` (no cycle existed: resolution lives in `pkg/polars/tablefns.go` as a pre-bind rewrite)
- [x] 3.3 Resolve table functions at bind time to loaded frames; support aliases, joins, CTEs, subqueries, qualified column resolution
- [x] 3.4 Tests: positive tests per format with testdata files, alias/join/CTE composition, missing-file and bad-argument errors (sql-table-functions spec scenarios)

## 4. Function catalog refactor

- [x] 4.1 Convert `pkg/sql/functions.go` to a table-driven registry (`fnSpec`: canonical name, aliases, arity range, kind, builder) with uniform unknown-name and arity error messages
- [x] 4.2 Port all existing functions to the registry with current tests green (no behavior change)

## 5. New expression kernels (pkg/expr)

- [x] 5.1 Add string Expr methods + eval kernels: `EndsWith`, `StrPadStart`/`StrPadEnd`, `StrSplitPart`, `StrToTitle`, `StrPos`, separator-aware concat for `CONCAT_WS`
- [x] 5.2 Add `Atan2` Expr method + kernel; verify `Cot`, `Cbrt`, `Sign`, `Degrees`, `Radians`, `Log` variants are SQL-reachable
- [x] 5.3 Add `DtOrdinalDay` (day-of-year) kernel if absent; verify `DtWeekday` semantics against py-polars `dayofweek`
- [x] 5.4 Add dense-rank support to the rank kernel if missing (for `DENSE_RANK`) — implemented in the window executor (`pkg/exec/engine.go` applyWindows), where SQL window ranks execute
- [x] 5.5 Unit tests for every new kernel including NULL propagation

## 6. Catalog expansion — scalar functions

- [x] 6.1 String: `STARTS_WITH`, `ENDS_WITH`, `LEFT`, `RIGHT`, `LTRIM`, `RTRIM`, `REVERSE`, `INITCAP`, `LPAD`, `RPAD`, `SPLIT_PART`, `STRPOS`/`POSITION`, `OCTET_LENGTH`, `BIT_LENGTH`, `REGEXP_LIKE`, `CONCAT_WS`
- [x] 6.2 Math: `SIGN`, `CBRT`, `LOG` (1- and 2-arg), `LOG2`, `LOG10`, `LOG1P`, `PI()`, `DEGREES`, `RADIANS`, `SIN`, `COS`, `TAN`, `COT`, `ASIN`, `ACOS`, `ATAN`, `ATAN2`
- [x] 6.3 Conditional: `IFNULL`, `IF`, `GREATEST`, `LEAST` (row-wise fold)
- [x] 6.4 Temporal: `DATE_PART`/`EXTRACT` (year/month/day/hour/minute/second/dow/weekday with unsupported-part errors), `DAYOFWEEK`, `DAYOFYEAR`/`ORDINAL_DAY`

## 7. Catalog expansion — aggregates and window functions

- [x] 7.1 Aggregates: `STDDEV`/`STDEV`/`STDDEV_SAMP`, `VARIANCE`/`VAR`/`VAR_SAMP`, `MEDIAN`, `FIRST`, `LAST`
- [x] 7.2 `COUNT(DISTINCT col)` parsing in `pkg/sql/expr_parser.go` → dedicated `count_distinct` aggregate (distinct non-null, SQL semantics); reject DISTINCT on other aggregates with a clear error
- [x] 7.3 Window: `RANK`, `DENSE_RANK`, `LAG`/`LEAD` (offset + default args), `FIRST_VALUE`, `LAST_VALUE` through the existing OVER path

## 8. Parity tests and verification

- [x] 8.1 Parity tests in `test/parity/unit/sql/functions_test.go` for every new function (NULL/edge cases incl. SPLIT_PART out-of-range, LPAD truncation, CONCAT_WS null-skip, STRPOS-missing NULL)
- [x] 8.2 Tests for DDL round-trips (`CREATE` → `SELECT` → `TRUNCATE` → `DROP` → `SHOW TABLES`) in `test/unit/sql_ddl_test.go`; existing EXPLAIN golden (`test/unit/testdata/sql_explain.golden`) still green
- [x] 8.3 Update README SQL surface docs (POLARS_PARITY_TABLE.md is method-presence only; `sql` rows already ✅)
- [x] 8.4 Full verification: `go build ./... && go vet ./... && go test ./...` green; gofmt clean; no import cycles
