## Context

**Поточний стан**

- `series.Series` зберігає `data []any` + `nulls []bool` (`pkg/series/series.go`). Кожне присвоєння боксує значення; `Value(i)` повертає `any`.
- `frame.DataFrame.Filter` викликає `expr.Eval(predicate, rowAccessor{...})` для кожного рядка (`pkg/frame/frame.go`). `rowAccessor.ValueByName` робить lookup у `map[string]series.Series` і `s.Value(row)` на кожен доступ.
- `evalExprAsSeriesVectorized` має лише вузькі fast-path (cum_sum, rank, rolling, over); fallback — той самий построчний `expr.Eval` у `parallelForRows`.
- `pkg/io/arrow.ToTable` матеріалізує колонки в `[]any` (`pkg/io/arrow/arrow.go`).
- `pkg/simd` (build tag `amd64 && simd`, Go 1.26 `GOEXPERIMENT=simd`) експонує Sum/Min/Max/Add/Mul для `[]float64`; використовується переважно з `pkg/polars/series.go` після витягування float64 з `[]any`.

**Обмеження**

- Публічний API `pkg/polars` має залишатися стабільним на етапі 1.
- Проєкт уже залежить від `apache/arrow/go/v18` — доцільно вирівняти внутрішнє сховище з Arrow memory layout.
- Go не має generics для union усіх dtype одним типом — потрібен tagged union / interface на рівні chunk, не на кожному елементі.

## Goals / Non-Goals

**Goals:**

- Канонічне внутрішнє представлення колонки — плотний typed buffer + validity (bitmap або `[]bool` на перший етап).
- Hot path (`Filter`, `WithColumns` для арифметики/порівнянь, `select` проекції) без построчного `expr.Eval`.
- Імпорт з Arrow IPC/Parquet scan без повної materialization в `[]any`.
- Вимірюване прискорення (≥5× на filter+with_columns для 1M float64/int64 рядків у bench) відносно поточного main.
- Поетапна міграція з dual-read (chunk + legacy) для зниження ризику.

**Non-Goals:**

- Повна паритетність з Polars Rust engine (streaming executor rewrite) в одному change.
- JIT компіляція виразів у машинний код.
- GPU / distributed execution.
- Зміна Python parity matrix API на цьому етапі.
- Підтримка довільних `any` / nested struct як primary storage (залишаються boxed/slow path).

## Decisions

### 1. `ColumnChunk` як внутрішній примітив (не лише `Series`)

**Рішення:** Ввести `pkg/chunk` (або `pkg/column`) з `ColumnChunk`: `{ dtype, values: typed backing, validity }`. `series.Series` стає тонкою обгорткою над `ColumnChunk` + name metadata.

**Альтернативи:**

- *Зберігати `[]any` і кешувати typed view* — менше breaking, але боксинг залишається в пам’яті; виграш обмежений.
- *Використовувати лише `arrow.Array` без власного типу* — максимальна сумісність з IO, але важче custom kernels без залежності від усіх Arrow builders у hot path.

**Чому:** явний chunk дозволяє kernels працювати на `[]float64` без interface dispatch на елемент; Arrow — adapter, не єдине сховище.

### 2. Validity: bitmap bytes (Arrow-aligned) vs `[]bool`

**Рішення:** Етап 1 — `[]bool` для простоти міграції; етап 2 — compact bitmap (`[]byte` + bit ops), сумісний з Arrow validity buffer.

**Чому:** швидкий старт; bitmap — prerequisite для zero-copy з Arrow.

### 3. Вирази: batch evaluator + kernel registry

**Рішення:** Розширити `pkg/expr` пакетом `evalbatch`:

- Обхід AST один раз → `Plan` (вузли: `LoadCol`, `Literal`, `Binary`, `Compare`, `AndOr`, `Cast`).
- `Plan.Eval(ctx, chunks map[string]ColumnChunk) (ColumnChunk, error)` повертає результатний chunk (напр. `Bool` mask для filter).
- Row-wise `Eval` залишається для `RasterRowAccess` (reverse row), dynamic JSON, невідомих op.

**Альтернатива:** codegen з шаблонів — відкладено (Non-Goal).

### 4. Filter pipeline

**Рішення:** `Filter` → `mask := plan.EvalBool(...)` → `chunk.Take(mask)` або index gather по всіх колонках одним проходом індексів.

**Чому:** одна векторна оцінка предиката; slice по індексах без re-eval предиката.

### 5. SIMD через typed buffers

**Рішення:** `pkg/simd` приймає лише typed slices; нові entry points: `CompareEQFloat64`, `AndMask`, `FilterIndices` (compress). Generic fallback без build tag.

**Чому:** поточний SIMD марний, якщо дані в `[]any`; після chunk kernels SIMD стає релевантним для filter/reduce.

### 6. Arrow interop

**Рішення:** `pkg/io/arrow`:

- `FromArrowRecord(rec arrow.Record) → frame.DataFrame` через import arrays у `ColumnChunk` (copy якщо dtype unsupported).
- `ToArrowRecord(df) → arrow.Record` без проміжного `[]any`.

**Чому:** Parquet/IPC scan уже в екосистемі Arrow; усуває подвійну materialization.

### 7. Міграція API series/frame

**Рішення:** Dual mode:

1. `series.New` / `NewInput` приймають `[]any` → будують typed chunk (one-time cost).
2. Нові конструктори `series.FromFloat64`, `frame.FromChunks` для zero-copy internal/bench.
3. Hot paths перевіряють `chunk != nil`; legacy path deprecated у коментарях.

**BREAKING (internal):** прямий доступ до `Series` unexported fields заборонений; якщо тести лізуть у internals — оновити.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| Великий diff, регресії в 680 parity methods | Поетапні PR: chunk → filter/with_columns → group_by agg → решта; conformance suite + bench gates |
| Nested types (list, struct) не вписуються в dense buffers | Залишити slow boxed path; chunk лише для primitive + string |
| String колонки — variable width | Етап 1: `[]string` backing; пізніше Arrow LargeString offset buffer |
| Arrow import copy для unsupported types | Явний fallback + metric/log у debug |
| SIMD лише amd64+experiment | Generic kernels завжди; CI на обох шляхах |
| Пам’ять: dual storage під час міграції | Feature flag `UseTypedStorage` до cutover |

## Migration Plan

1. **Фаза A — Foundation:** `pkg/chunk`, refactor `series` to hold `*chunk.Column`, `[]any` builder shim.
2. **Фаза B — Batch expr:** `evalbatch` для Col/Lit/Binary/Compare/And/Or/Not/Cast (primitives).
3. **Фаза C — Frame hot paths:** `Filter`, `WithColumns` (subset), `Select` projection without eval.
4. **Фаза D — Arrow:** native import/export; оновити lazy scan materialize step.
5. **Фаза E — SIMD kernels:** mask compare, filter compress; wire group_by float reductions.
6. **Фаза F — Cutover:** remove `[]any` as canonical; keep `FromAny` for user input only.

Rollback: feature flag повертає row-wise `expr.Eval` path (зберегти до F).

## Open Questions

- Чи робити `string` canonical як `[]string` чи одразу Arrow `String` array?
- Наскільки глибоко інтегрувати `pkg/exec` lazy engine в цьому change vs окремий change?
- Чи потрібен `UInt64` / `Int32` в першій хвилі dtype чи достатньо Int64/Float64/Bool/String/Time?
- Політика null: Arrow-style (validity bit) vs окремий sentinel у typed slice?
