## 1. Typed column foundation (`typed-column-chunk`)

- [x] 1.1 Додати `pkg/chunk` з `ColumnChunk`, validity mask і конструкторами для Bool/Int64/Float64/String/Time
- [x] 1.2 Рефакторити `series.Series` на canonical `*chunk.Column`; `series.New` будує chunk з `[]any` (one-time)
- [x] 1.3 Реалізувати `Slice`, `Filter(mask)`, `Gather(indices)` на chunk без `[]any`
- [x] 1.4 Додати `series.FromInt64` / `FromFloat64` / `FromString` для zero-copy internal API
- [x] 1.5 Table-driven тести: null semantics, slice, gather vs поточний `series` behavior

## 2. Batch expression engine (`vectorized-expr-kernels`)

- [x] 2.1 Додати `pkg/expr/evalbatch` з `Plan` AST walk (Col, Lit, Unary, Binary, Compare, And/Or/Not, Cast)
- [x] 2.2 Реалізувати `EvalBool` → bool mask і `Eval` → typed chunk для підтримуваних dtype
- [x] 2.3 Conformance tests: batch vs row-wise `expr.Eval` на однакових фікстурах (primitives)
- [x] 2.4 Перевести `DataFrame.Filter` на batch mask + chunk gather (feature flag fallback)
- [x] 2.5 Перевести `WithColumns` subset (арифметика, compare, boolean logic) на batch path
- [x] 2.6 Залишити row-wise fallback для `RasterRowAccess` / unsupported ops; debug log при fallback

## 3. SIMD kernels (`simd-column-kernels`)

- [x] 3.1 Додати `CompareGTFloat64`, `CompareEQInt64`, `AndMask`, `CompressIndices` у `pkg/simd` (+ generic)
- [x] 3.2 Підключити mask generation у `evalbatch` для float64/int64 compare
- [x] 3.3 Оновити `polars` aggregations: читати float64 chunk напряму, без unpack з `[]any`
- [x] 3.4 Bench: filter+sum на 1M rows — порівняти main vs typed+simd; зафіксувати в performance budget script

## 4. Arrow native interop (`arrow-native-storage`)

- [x] 4.1 Реалізувати `FromArrowRecord` / `ToArrowRecord` у `pkg/io/arrow` через typed chunks
- [x] 4.2 Видалити row-loop materialization у `ToTable` для primitive dtypes
- [x] 4.3 Інтегрувати import у lazy scan materialize (де зараз будується `[]any`)
- [x] 4.4 Roundtrip тести: Arrow IPC ↔ DataFrame ↔ Arrow для Int64/Float64/Bool/String + nulls

## 5. Frame-wide migration and cutover

- [x] 5.1 Оновити `group_by` numeric reductions на typed chunk + simd reduce
- [x] 5.2 Оновити `Sort`/`Join` hot paths: читання chunk buffers замість `Value(i)` де можливо
- [x] 5.3 Feature flag `GOPOLARS_TYPED_STORAGE=0` для rollback на row-wise path
- [x] 5.4 Прибрати canonical `[]any` з `series.Series` після green CI; `[]any` лише в public constructors
- [x] 5.5 Оновити README/docs: архітектура сховища, SIMD build tags, очікуваний perf profile

## 6. Verification

- [x] 6.1 `go test ./...` і race detector без змін у поведінці parity tests
- [x] 6.2 Cross bench (`bench/cross`) — задокументувати delta vs Python Polars / Arrow baseline
- [x] 6.3 Перевірити coverage gate (≥75% `pkg/`) не падає після рефакторингу
