## Why

Профіль бенчмарків і реальних пайплайнів показує, що gopolars відстає від Polars на порядки не через «недокручені» дрібниці, а через фундаментальну модель виконання: кожне значення в колонці зберігається в `[]any` (боксинг), а більшість операцій (`Filter`, `WithColumns`, агрегації виразів) проходять через `expr.Eval` построчно з пошуком колонки в `map` на кожен рядок. Polars тримає плотні Arrow-буфери й виконує операції векторизовано (у т.ч. SIMD по всьому стовпцю). Поточний `pkg/simd` прискорює лише `Sum`/`Min`/`Max` для `float64` і лише після розпакування з `[]any`; він не задіяний у фільтрі та більшості виразів. Без зміни сховища та шляху виконання подальші мікрооптимізації не дадуть цільового прискорення.

## What Changes

- Ввести внутрішнє **типізоване колонкове сховище** (плотні буфери за `dtypes`, окремий бітмап/маска null) замість єдиного `[]any` як канонічного представлення.
- Додати **векторні ядра (kernels)** для ключових операцій: порівняння, арифметика, логіка, `filter` (mask generation), cast — без виклику `expr.Eval` на кожен рядок у hot path.
- Переписати **інтерпретатор виразів** так, щоб він будував або викликав batch-план (vectorized evaluation tree), а row-wise `Eval` залишився лише для рідкісних/динамічних випадків.
- Розширити **SIMD-шар**: працювати з типізованими `[]float64`/`[]int64` без проміжного `[]any`; підключити kernels для filter, compare, reduce там, де це виправдано.
- Оновити **Arrow bridge** (`pkg/io/arrow`): імпорт/експорт через `apache/arrow` arrays з мінімальним копіюванням, а не materialize в `[]any`.
- Зберегти публічний API `pkg/polars` стабільним на першому етапі; **BREAKING** можливий лише для внутрішніх пакетів (`frame`, `series`, `expr`) і опційних низькорівневих хелперів.
- Додати **регресійні бенчмарки** і цільові budget-пороги для filter / with_columns / group_by на типізованих даних.

## Capabilities

### New Capabilities

- `typed-column-chunk`: канонічне внутрішнє представлення колонки (typed buffer + validity bitmap), API для читання/запису без боксингу, конверсія з/до legacy `[]any`.
- `vectorized-expr-kernels`: batch-оцінка виразів і генерація масок для `Filter`/`WithColumns` без построчного `expr.Eval` у hot path.
- `simd-column-kernels`: SIMD-оптимізовані kernels поверх типізованих буферів (порівняння, filter mask, reduce, element-wise float64/int64).
- `arrow-native-storage`: zero-copy або low-copy інтеграція з `apache/arrow/go` arrays як джерелом/приймачем колонок.

### Modified Capabilities

- _(немає — `openspec/specs/` порожній; це перші capability-спеки для проєкту)_

## Impact

- **Пакети**: `pkg/series`, `pkg/frame`, `pkg/expr`, `pkg/simd`, `pkg/io/arrow`, `pkg/dtypes`; можливі зміни в `pkg/exec` (lazy collect) та `pkg/polars` (тонкий шар адаптації).
- **Залежності**: наявний `github.com/apache/arrow/go/v18` стане частиною runtime storage, не лише IO/bench; `turboslice` / `GOEXPERIMENT=simd` — для amd64 kernels.
- **Тести**: unit + bench у `bench/` та `test/`; оновлення cross-language bench fixtures.
- **Сумісність**: зовнішній Polars-like API без змін на етапі 1; внутрішні конструктори `series.New(..., []any)` поступово deprecated або як compatibility shim.
- **Ризики**: великий обсяг рефакторингу; потрібна поетапна міграція (dual storage → switch hot paths → remove `[]any` canonical).
