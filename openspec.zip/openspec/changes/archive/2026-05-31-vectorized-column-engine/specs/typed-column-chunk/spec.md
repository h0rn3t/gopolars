## ADDED Requirements

### Requirement: Typed column chunk is canonical storage

The system SHALL store each primitive column as a `ColumnChunk` with a declared `dtypes.DataType`, a dense typed value buffer, and a validity mask indicating null positions.

#### Scenario: Create float64 chunk from slice

- **WHEN** code constructs a `ColumnChunk` from `[]float64` values and a validity mask of equal length
- **THEN** the chunk SHALL expose `Len()` equal to the input length and `ValueAt(i)` for non-null indices SHALL return the i-th float64 without heap boxing per element

#### Scenario: Null positions are readable

- **WHEN** validity marks index `j` as null
- **THEN** `IsNull(j)` SHALL be true and `ValueAt(j)` SHALL NOT require callers to read a boxed `nil` from `[]any`

### Requirement: Legacy any slice conversion is one-time at ingest

The system SHALL provide conversion from `[]any` input (existing `series.New`) into a typed `ColumnChunk` at construction time.

#### Scenario: series.New builds typed backing

- **WHEN** `series.New` is called with `dtypes.Int64` and a `[]any` of int64 values
- **THEN** the resulting series SHALL hold a typed `[]int64` (or equivalent) backing and SHALL NOT retain `[]any` as the canonical storage after construction completes

### Requirement: Supported primitive dtypes in chunk layer

The chunk layer MUST support at minimum: `Bool`, `Int64`, `Float64`, `String`, and temporal types mapped to `time.Time` or int64 epoch nanos as documented in `dtypes`.

#### Scenario: Unsupported dtype falls back to boxed storage

- **WHEN** a column dtype is struct, list, or other nested type
- **THEN** the system MAY use a boxed slow-path storage but SHALL NOT block primitive columns from using typed chunks

### Requirement: Chunk slice and gather without per-element boxing

The system SHALL implement `Slice(indices []int)` and `Filter(mask []bool)` on `ColumnChunk` producing a new chunk by copying or gathering typed values in bulk.

#### Scenario: Filter by boolean mask

- **WHEN** a bool mask of length N is applied to a float64 chunk of length N
- **THEN** the output chunk length SHALL equal the count of true mask bits and values SHALL preserve order of surviving indices
