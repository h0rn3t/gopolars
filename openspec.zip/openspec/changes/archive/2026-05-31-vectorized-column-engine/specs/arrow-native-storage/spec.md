## ADDED Requirements

### Requirement: Import Arrow record without []any materialization

The system SHALL convert `arrow.Record` (or per-column `arrow.Array`) into `DataFrame` columns backed by typed chunks or Arrow arrays with at most one copy when dtype is supported.

#### Scenario: Import float64 arrow column

- **WHEN** `FromArrowRecord` receives a float64 Arrow array of length N
- **THEN** the resulting frame column SHALL NOT allocate an intermediate `[]any` of length N solely for storage

### Requirement: Export DataFrame to Arrow record

The system SHALL export primitive typed columns to `arrow.Record` using Arrow builders or array wrappers without round-tripping through `[]any`.

#### Scenario: Export matches import roundtrip for int64

- **WHEN** a DataFrame with one int64 column is exported to Arrow and imported back
- **THEN** values and null positions at every index SHALL equal the original frame

### Requirement: Unsupported Arrow types use documented fallback

When an Arrow type has no typed chunk mapping, the system SHALL copy into a documented slow representation and SHALL return an error or warning according to API contract.

#### Scenario: Unsupported nested list type

- **WHEN** import encounters a nested list array without a typed mapping
- **THEN** the importer SHALL either return a clear error or use boxed fallback explicitly marked as non-zero-copy in diagnostics

### Requirement: Existing polars ToArrow entry points use native path

Public `ToArrow` / scan materialization paths in `pkg/polars` and `pkg/io/arrow` SHALL delegate to the native import/export implementation once available.

#### Scenario: ToTable no longer builds []any per cell

- **WHEN** `iarrow.ToTable` is called on a frame whose columns are typed chunks
- **THEN** it SHALL construct Arrow arrays from typed backing without calling `s.Value(i)` in a row loop for primitive dtypes
