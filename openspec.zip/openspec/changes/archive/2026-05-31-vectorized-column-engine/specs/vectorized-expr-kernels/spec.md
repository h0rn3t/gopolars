## ADDED Requirements

### Requirement: Batch expression evaluation for primitive operations

The system SHALL evaluate expression trees over entire columns in batch mode without invoking row-wise `expr.Eval` for supported expression kinds.

#### Scenario: Filter uses batch bool mask

- **WHEN** `DataFrame.Filter` receives a predicate composed only of supported primitive operations (column refs, literals, comparisons, and/or/not)
- **THEN** the engine SHALL compute a `[]bool` mask in one vectorized pass and SHALL NOT call `expr.Eval` per row index

#### Scenario: Unsupported predicate falls back to row-wise eval

- **WHEN** a predicate uses an unsupported operation (e.g. row-relative `reverse` access pattern)
- **THEN** the system SHALL fall back to row-wise `expr.Eval` and SHALL document the fallback in debug diagnostics when enabled

### Requirement: WithColumns evaluates supported exprs to typed output chunk

The system SHALL implement batch evaluation for `WithColumns` when the expression plan is supported, materializing a typed `ColumnChunk` directly.

#### Scenario: Arithmetic with_columns on two float columns

- **WHEN** `WithColumns` adds `col("a") + col("b")` on float64 columns `a` and `b` of equal length
- **THEN** the result column SHALL be produced via vectorized float64 addition without constructing an intermediate `[]any` of length N

### Requirement: Expression plan is built once per operation

The system SHALL walk the expression AST once to build an execution plan reused for all rows in the batch.

#### Scenario: Column lookup happens once per column name

- **WHEN** a plan references column `x` ten times in nested expressions
- **THEN** the batch evaluator SHALL resolve the `x` chunk pointer once per evaluation, not once per row per reference

### Requirement: Public polars API behavior unchanged for supported inputs

For expressions and dtypes supported by batch kernels, results MUST match the semantics of the current row-wise evaluator (including null propagation rules).

#### Scenario: Null in comparison propagates

- **WHEN** either operand is null at index `i` in a comparison expression
- **THEN** the bool mask at `i` SHALL be false (or null-filter semantics equivalent to current `expr.Eval` behavior) as verified by conformance tests
