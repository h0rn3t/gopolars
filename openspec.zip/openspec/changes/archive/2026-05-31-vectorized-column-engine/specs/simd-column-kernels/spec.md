## ADDED Requirements

### Requirement: SIMD kernels operate on typed buffers only

The `pkg/simd` package SHALL expose kernels that accept dense typed slices (`[]float64`, `[]int64`, `[]bool` masks) and SHALL NOT require `[]any` inputs.

#### Scenario: Sum from float64 chunk

- **WHEN** aggregation requests sum over a float64 `ColumnChunk` with no nulls
- **THEN** the implementation SHALL pass the underlying `[]float64` slice directly to `simd.SumFloat64` or its generic fallback

### Requirement: Vectorized comparison kernels for filter masks

The system SHALL provide SIMD-accelerated (where build tags allow) element-wise comparison kernels that write bool masks used by `Filter`.

#### Scenario: Greater-than mask on amd64 with simd build

- **WHEN** built with `GOEXPERIMENT=simd` on amd64 and comparing `[]float64` column to a literal threshold
- **THEN** the mask generation SHALL use `pkg/simd` comparison helpers rather than a per-element Go loop in the hot path

#### Scenario: Generic port without simd tag

- **WHEN** built without simd experiment or on non-amd64
- **THEN** the same comparison API SHALL produce identical masks using scalar loops

### Requirement: Filter index compression kernel

The system SHALL provide a function that converts a bool mask to `[]int` indices of true entries for gather operations, optionally SIMD-accelerated.

#### Scenario: Compress mask to indices

- **WHEN** a mask `[true,false,true]` is compressed
- **THEN** the result indices SHALL be `[0,2]` in order

### Requirement: Document simd build requirements

The project SHALL document in `pkg/simd` and README that SIMD acceleration requires Go 1.26+ with `GOEXPERIMENT=simd` on amd64, and that correctness does not depend on SIMD being enabled.

#### Scenario: CI runs tests without simd

- **WHEN** CI runs default `go test ./...` without experiment tags
- **THEN** all tests SHALL pass using generic implementations
