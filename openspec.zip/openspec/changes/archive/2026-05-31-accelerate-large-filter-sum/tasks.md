## 1. Baseline & benchmark harness

- [x] 1.1 Add a realistic-selectivity profile to `bench/cross` (e.g. threshold chosen so ~50% of rows pass) alongside the existing ~0% case, so gather/materialization cost is exercised
- [x] 1.2 Record baseline `go test ./bench/cross -bench=BenchmarkCrossFilterSum -benchmem -count=10` into a benchstat-comparable file (ns/op, B/op, allocs/op for 100K/1M/10M)
- [x] 1.3 Add a micro-benchmark for `CompressIndices` and `EvalBool` in isolation (`pkg/simd`, `pkg/expr/evalbatch`) to measure alloc fixes directly

## 2. Eliminate redundant allocations (low risk)

- [x] 2.1 Rework `evalbatch.Plan.EvalBool` (`pkg/expr/evalbatch/evalbatch.go:89`) to expose the evaluated chunk's existing bool/null buffers instead of allocating two fresh N-length `[]bool` and copying element-by-element
- [x] 2.2 Update `filterBatch` (`pkg/frame/typed.go:51`) call site to the new EvalBool contract; document buffer ownership (read-only for caller)
- [x] 2.3 Rewrite `simd.CompressIndices` (`pkg/simd/kernels.go:44`) to count-then-allocate: popcount the mask, then `make([]int, count)` and fill
- [x] 2.4 Verify allocs/op drops on the micro-benchmarks and on `BenchmarkCrossFilterSum` (expect ≈12MB → small constant on 1M, low-selectivity profile)

## 3. Parallelize batch filter

- [x] 3.1 Add a parallelism threshold constant (calibrated by benchmark; default around 16–32K rows) and a helper that partitions a column into contiguous worker chunks
- [x] 3.2 Parallelize predicate mask evaluation in `filterBatch` using the partitioning helper (reuse the `parallelForRows` pattern from `pkg/frame/frame.go:1917`), writing disjoint ranges so order is preserved
- [x] 3.3 Add a unit test asserting parallel vs sequential `Filter` results are element-wise identical (including nulls) across sizes that straddle the threshold
- [x] 3.4 Re-run `BenchmarkCrossFilterSum`; confirm large-N speedup and no regression below the threshold

## 4. Fuse filter + reduce

- [x] 4.1 Decide and document the fusion trigger point (eager recognition of `Filter(...).Sum()` in `pkg/polars` vs lazy plan) per design Open Questions
- [x] 4.2 Implement single-pass masked reduce for sum (and at least min/max/count) over float64: accumulate `predicate[i] ? value[i] : 0` without `CompressIndices` or column `Slice`
- [x] 4.3 Add golden test: fused reduce result == materialized-then-reduce result, covering null and NaN cases
- [x] 4.4 Ensure unsupported predicates/reductions fall back to the materializing path with debug diagnostics
- [x] 4.5 Benchmark fused path vs materializing path on 1M/10M for both selectivity profiles

## 5. arm64 vectorization

- [x] 5.1 Restructure the generic reduce/compare loops (`pkg/simd/simd_generic.go`, `pkg/simd/kernels.go`) to be auto-vectorization friendly (multiple accumulators, bounds hoisted, no data dependencies); inspect with `go build -gcflags=-d=ssa/...` or assembly output
- [x] 5.2 Add a benchmark comparing scalar vs restructured loop on arm64; only proceed to hand-written arm64 assembly if auto-vectorization is insufficient
- [x] 5.3 If asm is needed, add an arm64 build-tagged implementation with a generic fallback; keep correctness independent of build tags
- [x] 5.4 Add a cross-arch equivalence test (results identical within defined float reduction-order tolerance; masks bit-for-bit equal)

## 6. Verification & documentation

- [x] 6.1 Run full `go test ./...` (generic build, no simd experiment) — all green
- [x] 6.2 Run differential/conformance tests against Polars to confirm result parity is preserved
- [x] 6.3 Produce final benchstat comparison (baseline vs new) for 100K/1M/10M on both selectivity profiles; paste into the implementing commit body
- [x] 6.4 Update `pkg/simd` docs/README to reflect arm64 vectorization status and the fused filter+reduce path
