## ADDED Requirements

### Requirement: Reduce and compare kernels are vectorized on arm64

The `pkg/simd` package SHALL provide reduce (sum/min/max) and compare kernels that are vectorized on arm64 — either via compiler auto-vectorization of the generic implementation or an arm64-specific path — so that non-amd64 platforms do not fall back to a purely scalar element-by-element loop in the hot path.

#### Scenario: Sum over float64 on arm64 is not purely scalar

- **WHEN** built and run on arm64 without `GOEXPERIMENT=simd`
- **THEN** `simd.SumFloat64` over a large `[]float64` SHALL execute a vectorized or auto-vectorized loop rather than a single-accumulator scalar loop

#### Scenario: Results are identical across architectures

- **WHEN** the same input is reduced or compared on amd64 and arm64
- **THEN** the numerical results SHALL be identical (within defined float reduction-order tolerance) and the boolean masks SHALL be bit-for-bit equal

### Requirement: Index compression allocates exactly the result size

The mask-to-indices compression kernel SHALL allocate an output `[]int` whose capacity matches the number of true entries in the mask, not the full mask length, so that a low-selectivity filter does not allocate `8 * len(mask)` bytes.

#### Scenario: Empty selectivity allocates no oversized index buffer

- **WHEN** `CompressIndices` is called on a mask of length N where zero entries are true
- **THEN** the returned slice SHALL have length 0 and SHALL NOT have pre-allocated capacity proportional to N

#### Scenario: Dense selectivity produces a correctly sized buffer

- **WHEN** `CompressIndices` is called on a mask where K entries are true
- **THEN** the returned slice SHALL contain exactly the K true indices in ascending order
- **AND** SHALL be produced without repeated growth reallocations
