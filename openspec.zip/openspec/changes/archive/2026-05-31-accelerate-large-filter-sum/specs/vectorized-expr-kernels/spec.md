## ADDED Requirements

### Requirement: Batch predicate evaluation runs in parallel above a row threshold

The system SHALL evaluate a supported `Filter` predicate across multiple worker goroutines when the column height exceeds a parallelism threshold, partitioning rows into contiguous chunks and producing a result whose row order is identical to the sequential evaluation.

#### Scenario: Large filter uses all available workers

- **WHEN** `DataFrame.Filter` receives a supported predicate over a column with height above the parallelism threshold
- **THEN** the batch evaluator SHALL distribute disjoint contiguous row ranges across up to `GOMAXPROCS` workers
- **AND** the surviving rows SHALL appear in the same order as a single-threaded evaluation of the same predicate

#### Scenario: Small filter stays sequential

- **WHEN** `DataFrame.Filter` receives a supported predicate over a column with height below the parallelism threshold
- **THEN** the evaluator SHALL run sequentially without spawning workers

#### Scenario: Parallel and sequential results are identical

- **WHEN** the same supported predicate is evaluated over the same data with parallelism enabled and disabled
- **THEN** the resulting filtered DataFrames SHALL be element-wise equal, including null handling

### Requirement: EvalBool does not allocate redundant mask and validity copies

When producing the boolean result of a predicate plan, the system SHALL NOT allocate fresh full-length `[]bool` mask and validity slices that duplicate buffers already held by the evaluated result chunk.

#### Scenario: Predicate over N rows allocates no duplicate N-length bool buffers

- **WHEN** a predicate plan is evaluated to a boolean result over a column of height N
- **THEN** the mask and validity exposed to the caller SHALL reference the evaluated chunk's existing buffers (or the chunk itself) rather than two newly allocated N-length `[]bool` slices populated by an element-wise copy loop

### Requirement: Fused filter-then-reduce evaluates in a single pass

For the pattern `filter(predicate).<reduce>()` where the predicate and reduction are supported, the system SHALL compute the reduction in a single masked pass over the source column without materializing an intermediate filtered column or building a surviving-index slice.

#### Scenario: filter(...).Sum() avoids materialization

- **WHEN** a supported predicate is followed by a `Sum` over a float64 column
- **THEN** the engine SHALL accumulate `predicate[i] ? value[i] : 0` in one pass
- **AND** SHALL NOT allocate a compressed index slice nor a sliced output column for the filtered rows

#### Scenario: Fused result matches materialized result

- **WHEN** the fused path computes a reduction over a filtered column
- **THEN** the result SHALL equal the value obtained by materializing the filtered column and reducing it, including null and NaN handling
