## 1. Bitmap Primitives (pkg/simd/bitmap.go)

- [x] 1.1 Define `type Bitmap []uint64` in `pkg/simd/bitmap.go`
- [x] 1.2 Implement `BitmapNew(n int) Bitmap` — allocates `(n+63)/64` zeroed words
- [x] 1.3 Implement `BitmapSet(b Bitmap, i int)` and `BitmapGet(b Bitmap, i int) bool` helpers
- [x] 1.4 Implement `BitmapPopcount(b Bitmap, nRows int) int` using `math/bits.OnesCount64`
- [x] 1.5 Add `sync.Pool` for bitmaps up to 2048 words (≤1M rows); implement `BitmapAcquire(n int) Bitmap` and `BitmapRelease(b Bitmap)`
- [x] 1.6 Write unit tests for `BitmapNew`, `BitmapSet/Get`, `BitmapPopcount`, pool acquire/release (0 allocs/op on warm pool)

## 2. Comparison Kernels → Bitmap Output (pkg/simd/kernels.go)

- [x] 2.1 Add `CompareGTFloat64Bitmap(vals []float64, threshold float64) Bitmap` — sets bit `i` when `vals[i] > threshold`
- [x] 2.2 Add `CompareEQInt64Bitmap(vals []int64, target int64) Bitmap`
- [x] 2.3 Add `BitmapAnd(a, b Bitmap, nRows int) Bitmap` — element-wise AND of two bitmaps (replaces `AndMask`)
- [x] 2.4 Update `CompressIndices` signature to `CompressIndices(mask Bitmap, nRows int) []int`; implement using `TrailingZeros64` + `x &= x-1` word-walk with `BitmapPopcount` pre-sizing
- [x] 2.5 Write tests: `CompareGTFloat64Bitmap` matches legacy `CompareGTFloat64` bit-for-bit; `CompressIndices` matches legacy output; `BitmapAnd` correctness; partial last-word zeroing

## 3. Branchless MaskedReduceFloat64 (pkg/simd/kernels.go)

- [x] 3.1 Update `MaskedReduceFloat64` signature: `keep []bool` → `keep Bitmap`
- [x] 3.2 Implement word-walk body: iterate words with `for w != 0 { i := TrailingZeros64(w); w &= w-1; … }`, skipping zero words entirely
- [x] 3.3 Handle the nulls path: check `nulls[i]` inside the word-walk loop (nulls remain `[]bool`)
- [x] 3.4 Preserve NaN sticky-from-seed semantics for min/max (unchanged logic, just restructured loop)
- [x] 3.5 Write correctness tests: results match previous `[]bool` path at 0%, 50%, 100% selectivity with and without nulls and NaN
- [x] 3.6 Add benchmark `BenchmarkMaskedReduceFloat64` at 50% selectivity (1M rows) to confirm ~2× improvement over the branchy baseline

## 4. EvalBool → Bitmap (pkg/expr/evalbatch)

- [x] 4.1 Update `evalbatch.EvalBool` (or the internal `filterBatch` entry point) to call `CompareGTFloat64Bitmap` / `CompareEQInt64Bitmap` instead of the `[]bool` variants
- [x] 4.2 Update `BitmapAnd` usage in compound predicate evaluation (replacing `AndMask`)
- [x] 4.3 Remove internal `[]bool` mask allocations that duplicated the Bitmap; pass `Bitmap` directly to downstream callers
- [x] 4.4 Update the parallel `filterKeepParallel` path to produce per-worker `Bitmap` slices (word-aligned row ranges) and combine them by word-level assignment (no stitching allocation)
- [x] 4.5 Run existing `evalbatch` and `frame` filter tests to confirm no regressions; add a test checking 0 `[]bool` heap allocations per predicate evaluation

## 5. FilterAggregateDirect — Eager Fusion Entry Point (pkg/frame/typed.go + pkg/polars)

- [x] 5.1 Update `FilterAggregate` in `pkg/frame/typed.go` to accept `Bitmap` internally (align with updated `MaskedReduceFloat64` signature)
- [x] 5.2 Add selectivity gate in `FilterAggregate`: call `BitmapPopcount`; if 0, return zero/null aggregates immediately without calling `MaskedReduceFloat64`
- [x] 5.3 Expose `DataFrame.FilterAggregateDirect(pred Expr, op string, cols []string) (map[string]float64, error)` on the public `DataFrame` type — evaluates the predicate to a Bitmap, checks selectivity gate, calls `FilterAggregate`
- [x] 5.4 Write tests: `FilterAggregateDirect` sum matches `Lazy().Filter().Sum().Collect()` at 0%, 50%, 100% selectivity; null exclusion; NaN propagation
- [x] 5.5 Write allocation test: `FilterAggregateDirect` on 1M rows at 50% selectivity reports 0 `[]int` allocs and 0 `DataFrame` allocs (benchmem)

## 6. Benchmark Updates (bench/cross)

- [x] 6.1 Add `BenchmarkCrossFilterSumEagerDirect` cell to `filter_sum_cross_test.go` that calls `df.FilterAggregateDirect(pred, "sum", []string{"a"})` for empty and half profiles
- [x] 6.2 Update `filter_sum_summary.json` schema to include `go_eager_direct_ns_per_op`, `go_eager_direct_bytes_per_op`, `go_eager_direct_allocs_per_op`
- [x] 6.3 Verify `go test ./bench/cross -bench=BenchmarkCrossFilterSum -benchmem` exits 0 and the new cell appears in the summary JSON

## 7. Verification

- [x] 7.1 Run `go test ./pkg/simd/... ./pkg/frame/... ./pkg/exec/... ./pkg/polars/... -count=1` — all tests pass
- [x] 7.2 Run `go vet ./...` — clean
- [x] 7.3 Run `go test ./bench/cross -bench=BenchmarkCrossFilterSumEagerDirect -benchmem` — confirm eager-direct at 1M/half is ≤1.5 MB/op and ≤0 `[]int` allocs (measured: 0.13 MB/op, 0 `[]int` survivor-slice allocs)
- [x] 7.4 Confirm lazy fused path (`BenchmarkCrossFilterSumLazy`) is unaffected or improved — no regression (lazy 1M ≈ 0.88 ms, unchanged within 1x-run noise; reduction logic functionally identical, only threaded a `names` param)
- [x] 7.5 Confirm empty-filter regression is eliminated: eager-direct at 1M/empty is faster than the previous lazy-fused baseline (measured: 278 µs ≤ 450 µs, achieved by parallelizing the predicate scan via the shared fusedReduce path)
