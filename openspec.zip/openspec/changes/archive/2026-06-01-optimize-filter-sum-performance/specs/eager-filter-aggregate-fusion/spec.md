## ADDED Requirements

### Requirement: Eager API exposes direct filter-aggregate fusion
The `DataFrame` type SHALL expose a `FilterAggregateDirect(pred Expr, op string, cols []string) (map[string]float64, error)` method that evaluates the predicate, computes the requested aggregation (`sum`, `min`, `max`, `mean`, `count`) in a single masked pass, and returns results without constructing a lazy plan or materializing a filtered DataFrame.

#### Scenario: FilterAggregateDirect sum matches lazy fused result
- **WHEN** `df.FilterAggregateDirect(pred, "sum", []string{"a"})` is called on a DataFrame with a supported float64 column
- **THEN** the returned value for `"a"` SHALL equal the value returned by `df.Lazy().Filter(pred).Sum().Collect(ctx)` for the same predicate

#### Scenario: FilterAggregateDirect produces no intermediate DataFrame allocation
- **WHEN** `FilterAggregateDirect` is called on a 1M-row DataFrame at 50% selectivity
- **THEN** the call SHALL allocate no `DataFrame`, no `[]int` survivor index slice, and no sliced column buffer — only the predicate bitmap and the result map

#### Scenario: FilterAggregateDirect handles empty result
- **WHEN** the predicate matches zero rows
- **THEN** the method SHALL return a map with the aggregation key set to 0 and count 0, without executing the reduction kernel

### Requirement: Selectivity gate skips reduction for empty filters
Before invoking `MaskedReduceFloat64`, the eager fusion path SHALL compute the bitmap popcount and return zero/null aggregates immediately when survivor count is zero.

#### Scenario: Zero survivors skips kernel
- **WHEN** the predicate bitmap has popcount 0
- **THEN** `MaskedReduceFloat64` SHALL NOT be called
- **AND** the returned aggregate SHALL be the appropriate zero/null sentinel for the requested operation

#### Scenario: Non-zero survivors always invokes kernel
- **WHEN** the predicate bitmap has popcount > 0
- **THEN** `MaskedReduceFloat64` SHALL be called with the full bitmap and value slice

### Requirement: Eager fusion preserves null and NaN semantics
`FilterAggregateDirect` SHALL produce results with identical null/NaN handling as the lazy fused path and the existing eager materialize-then-reduce path.

#### Scenario: Null rows excluded from sum
- **WHEN** a column has null values at rows that pass the predicate
- **THEN** those rows SHALL be excluded from the sum and count, matching the behavior of `Series.Sum()` on a materialized filtered column

#### Scenario: NaN propagation in min/max
- **WHEN** the first surviving row's value is NaN
- **THEN** min and max SHALL return NaN (sticky-from-seed), matching existing `MaskedReduceFloat64` semantics
