## Why

The gopolars eager `filter().sum()` path is 3–5× slower than Polars at >100K rows due to three compounding structural problems: a byte-mask that is 8× larger than a bitmap (bandwidth), a branchy reduction that mis-predicts at 50 % selectivity (throughput), and ~18 MB of scratch allocations per call. The library already ships a zero-materialization fused kernel (`MaskedReduceFloat64`) in the lazy path that is ~3× faster and ~8–9× lower-allocation—but it is never reached by the eager API, and even the lazy path is bottlenecked by the byte-mask floor (~2–19 MB/op at 1M–10M rows). Closing the remaining gap to Polars requires making the fused path accessible eagerly and converting the predicate representation from `[]bool` to `[]uint64` bitmaps.

## What Changes

- Add an **eager fast-path** so `df.Filter(pred)` immediately followed by any aggregation invokes `FilterAggregate` / `MaskedReduceFloat64` directly, bypassing the lazy planner overhead
- Gate fusion on selectivity: skip the fused path when predicate popcount ≈ 0 (empty-filter profile is slower with lazy overhead)
- Replace the `[]bool` predicate mask with a **`[]uint64` bitmap** end-to-end across `EvalBool`, `CompareGT*`, `AndMask`, `CompressIndices`, and `MaskedReduceFloat64`
- Rewrite `MaskedReduceFloat64` to use **branchless masked accumulation** (`sum += val * mask_bit`) instead of `if !keep[i] { continue }` (expected ~2× at 50 % selectivity)
- Pool the bitmap scratch via `sync.Pool` so repeated calls produce 0 heap allocations on the hot path

## Capabilities

### New Capabilities
- `eager-filter-aggregate-fusion`: Eager API fast-path that fuses `Filter` + aggregation into a single masked pass without plan construction overhead
- `bitmap-predicate-mask`: `[]uint64` bitmap representation for predicate results, replacing `[]bool` byte-masks throughout the filter pipeline

### Modified Capabilities
- `simd-column-kernels`: Kernel signatures and internals change to accept/return bitmaps instead of `[]bool`; `MaskedReduceFloat64` gains branchless accumulation
- `vectorized-expr-kernels`: `EvalBool` output type changes from `[]bool` to `[]uint64` bitmap

## Impact

- `pkg/simd/`: `CompareGTFloat64`, `MaskedReduceFloat64`, `CompressIndices`, `AndMask` — signature and implementation changes
- `pkg/frame/`: `filterBatch`, `filterKeep`, `FilterAggregate`, new `TryFilterAggregate` eager entry point
- `pkg/polars/`: `DataFrame` eager API gains optional aggregation fast-path
- `pkg/exec/engine.go`: selectivity-gated fusion logic
- Benchmark: `bench/cross/filter_sum_cross_test.go` and `harness.py` — new cells, B/op + allocs/op captured
- No breaking public API changes; the eager `Filter()` return type and `Sum()` method signatures are unchanged
