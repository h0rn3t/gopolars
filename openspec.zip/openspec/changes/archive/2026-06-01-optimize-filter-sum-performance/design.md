## Context

gopolars has two filter+aggregate paths:

1. **Eager** (`df.Filter(pred)` → `series.Sum()`): materializes a complete filtered DataFrame (~18 MB at 1M rows, 50% selectivity), then sums the copy. 3–5× slower than Polars at >100K rows.
2. **Lazy/fused** (`df.Lazy().Filter().Sum().Collect()`): invokes `FilterAggregate` → `MaskedReduceFloat64`; zero materialization, ~3× faster, ~8–9× less memory. Only reachable through the lazy planner.

Benchmarks (Part D of research) confirm the fused path narrows the gap to Polars from ~5.5× to ~1.4–1.9× at 1M rows. The remaining gap is dominated by the `[]bool` byte-mask (1 byte/row vs Arrow's 1 bit/row — 8× bandwidth penalty), a branchy `MaskedReduceFloat64` that hits the worst branch-predictor regime at 50% selectivity, and lazy-planner overhead (~126 allocs/call) that regresses empty-filter cases.

**Constraints:**
- Public API (`DataFrame.Filter`, `Series.Sum`) must not change signatures
- NaN/null semantics in `MaskedReduceFloat64` must be preserved exactly
- arm64 (M4 Pro) only: no `simd/archsimd`, no NEON assembly in scope for this change
- Must remain pure Go (no cgo, no assembly)

## Goals / Non-Goals

**Goals:**
- Expose the fused `FilterAggregate` kernel directly from the eager API so `df.Filter(pred).Series("col").Sum()` calls it without plan overhead
- Gate fusion on selectivity: skip when predicate result is near-empty (popcount ≈ 0)
- Replace `[]bool` predicate masks with `[]uint64` bitmaps throughout the filter pipeline (compare, AND, compress-indices, masked-reduce)
- Rewrite `MaskedReduceFloat64` with branchless masked accumulation for ~2× throughput at 50% selectivity
- Pool bitmap scratch buffers to approach 0 allocs/op on the fused hot path
- Keep the lazy planner path working unchanged

**Non-Goals:**
- NEON assembly or any architecture-specific code (deferred to R4 after R1–R3 are measured)
- Changing the streaming engine or lazy planner architecture
- Extending fusion to non-aggregate operators (e.g. fused filter+join)
- amd64/turboslice SIMD changes
- Multi-column aggregation fusion

## Decisions

### D1 — Bitmap representation: `[]uint64` packed words

**Decision:** Replace every `[]bool` predicate mask with `[]uint64` where bit `i%64` of word `i/64` encodes row `i`.

**Why over alternatives:**
- `[]byte` (1 byte/row, current) → 8× bandwidth penalty vs 1 bit/row; no word-at-a-time ops
- `[]uint8` packed nibbles → non-standard, harder to compose with `math/bits`
- Arrow `bitutil.Bitmap` wrapper → introduces a dependency on arrow-go just for internal masks; `[]uint64` is a primitive that `math/bits.OnesCount64` and `bits.TrailingZeros64` operate on natively
- `[]uint64` packed → matches `kelindar/column` (0 allocs/op precedent), Arrow spec layout, and enables free popcount for selectivity estimation via `bits.OnesCount64` (compiles to a single `CNT` on arm64)

Word size 64-bit on all target platforms; words are little-endian bit-indexed (bit 0 = LSB of word 0 = row 0). Length in words: `(nRows + 63) / 64`.

### D2 — Eager fusion via `TryFilterAggregate`

**Decision:** Add `DataFrame.TryFilterAggregate(pred, op, cols) (DataFrame, bool, error)` as an internal method. In `DataFrame.Filter`, after evaluating the bitmap predicate, inspect whether an aggregation is immediately pending via a new optional aggregation hint on the filter call, falling back to materialization when no hint is present.

**Simpler alternative — monkey-patching `Series.Sum`:** rejected because `Series` has no back-reference to the source predicate at sum time.

**Chosen approach:** Add a `DataFrame.FilterAggregateDirect(pred Expr, op string, cols []string) (map[string]float64, error)` method on the public `DataFrame` type (unexported variant already exists as `FilterAggregate`). Users can call this directly for the eager fused path. Additionally, wrap the common `filter + single-column sum` pattern in a convenience method.

**Selectivity gate:** Before invoking the fused kernel, sample popcount of the bitmap: if `survivors == 0`, skip `MaskedReduceFloat64` entirely (return zero/null directly). The lazy path currently runs the full kernel on empty results — this gate eliminates the empty-filter regression (D2 in research: lazy was 30% slower than eager at 0% selectivity).

### D3 — Branchless `MaskedReduceFloat64`

**Decision:** Replace `if !keep[i] { continue }` with predicated accumulation using integer-masked float arithmetic.

For sum: use the bitmap `[]uint64` word-at-a-time approach — iterate words, use `TrailingZeros64` + `x &= x-1` to visit only set bits (2.6–3.4 cycles/bit per Lemire 2018), accumulate without branching on individual rows. This beats `if !keep` at ≥25% selectivity and is faster than full-scan branchless (`sum += val * float64(bit)`) at low selectivity because zero-popcount words are skipped.

For min/max: use branchless `math.Min`/`math.Max` or inline `if v < min { min = v }` with likely-predictable comparison (branch prediction on monotone updates is well-behaved). The word-walk structure handles the skip-empty-word case for both.

NaN semantics: preserved — a NaN value encountered first becomes the seed; subsequent NaN is ignored by `<`/`>` comparisons (Go's IEEE 754 behavior unchanged).

### D4 — `sync.Pool` for bitmap scratch

**Decision:** Pool `[]uint64` bitmap buffers cap-bounded by `(maxPooledRows+63)/64` words. On `Get`, zero the buffer with `clear(buf)` (Go 1.21 builtin, maps to memset). On `Put`, only pool if `cap(buf) <= maxCap`.

**Why not arena:** Go arena experiment was put on hold indefinitely (Jan 2023, #51317). Not viable.

**Why cap-bound:** high-selectivity calls at 10M rows produce a 156 KB bitmap; pooling without a cap would keep large buffers alive indefinitely, inflating RSS. Cap at ~1M rows (16 KB) covers the common case; callers above that threshold allocate fresh (GC-reclaimed).

### D5 — `CompressIndices` retains `[]int` output, now bitmap-input

**Decision:** `CompressIndices(bitmap []uint64, nRows int) []int` — same output type (needed for eager `Filter` materialization path), new bitmap input. Uses `TrailingZeros64` + `x &= x-1` word walk to emit indices without a first-count pass (popcount is free from the bitmap, so we can pre-size).

## Risks / Trade-offs

- **FP reduction-order change** → `MaskedReduceFloat64` with word-walk visits rows in the same order (ascending index) — reduction order is preserved. Risk: low.
- **Null-bitmap confusion** → gopolars uses `[]bool` for both predicate masks *and* null indicators. Migrating predicate masks to `[]uint64` while nulls remain `[]bool` requires careful interface boundaries; document clearly which bitmap type each parameter is. Risk: medium. Mitigation: introduce a `type Bitmap []uint64` alias and use it consistently in simd package signatures.
- **Empty-filter gate false-positive** → popcount == 0 correctly identifies no survivors; the gate returns zero-count aggregates, which callers already handle as null (existing contract). Risk: low.
- **sync.Pool contention under goroutine parallelism** → the parallel filter path allocates per-worker bitmaps; pool them per-worker (pass a pool to `filterKeepParallel`). Risk: low.
- **Benchmark noise on Polars streaming** → research notes Polars streaming 10M at 0.86 ms may be an artifact. Do not optimize toward a noisy target; compare against Polars default-lazy as the primary baseline.

## Migration Plan

1. Add `pkg/simd/bitmap.go` with `type Bitmap []uint64`, `BitmapNew(n int)`, `BitmapSet`, `BitmapGet`, `BitmapPopcount`, `BitmapWordWalk` helpers and `sync.Pool` for small bitmaps
2. Update `CompareGTFloat64` → returns `Bitmap`; `CompareEQInt64` → returns `Bitmap`; `AndMask` → `BitmapAnd`
3. Update `MaskedReduceFloat64` signature: `keep []bool` → `keep Bitmap`; implement branchless word-walk
4. Update `CompressIndices` signature: `mask []bool` → `mask Bitmap, nRows int`
5. Update call sites: `evalbatch`, `frame/typed.go`, `frame/frame.go`
6. Add `DataFrame.FilterAggregateDirect` (public eager fused path) with selectivity gate
7. Update benchmark to call `FilterAggregateDirect` directly and report B/op + allocs/op
8. No breaking public API changes — `Filter()` return type and `Series.Sum()` unchanged

Rollback: all changes are behind the existing package boundary; reverting `pkg/simd/bitmap.go` and updating call sites restores the previous behavior. No schema or data format changes.

## Open Questions

- **Parallel filter bitmap stitching**: the current parallel path allocates per-worker `[]int` and concatenates. With bitmaps, stitching is a word-aligned OR — cleaner and allocation-free. Confirm that row ranges per worker are always 64-bit aligned (or handle the partial-word boundary at range edges).
- **`EvalBool` in `evalbatch`**: currently returns `[]bool`. Does changing it to `Bitmap` cascade into non-filter expression nodes? Scope the interface change carefully to avoid touching the full expression engine.
- **Benchmark `FilterAggregateDirect` vs lazy fused**: after implementation, re-run the 2×2 table (eager-direct / lazy-fused × Polars eager / streaming) to confirm eager-direct matches lazy-fused performance without planner overhead.
