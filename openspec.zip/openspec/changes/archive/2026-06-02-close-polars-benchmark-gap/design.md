## Context

gopolars stores primitive columns as dense typed `chunk.Column` buffers (`[]float64`/`[]int64`/`[]string`/`[]bool` + a `[]bool` validity mask) and already has typed fast paths for `Filter`, `FilterAggregateDirect`, `GroupBy.Agg` numeric reductions, and Arrow IO. But ~20 operations still route through two boxing primitives — `series.Value(i)` → `chunk.ValueAt(i) any` and the `[]any` → `series.New`/`chunk.FromAny` round-trip — producing 1–5 heap allocations per row (group_by, unique, join, rolling, cum_sum, rank, over, fill_null/fill_nan, drop_nans), or deep-copy whole columns on projection (select/with_columns), or scan the validity mask on every call (null_count). The full root-cause map with file:line evidence and cited reference designs (Polars/Arrow/DuckDB) is in [research/technical-gopolars-benchmark-optimization-2026-06-01.md](../../../research/technical-gopolars-benchmark-optimization-2026-06-01.md).

The binding constraint: the benchmark machine is **Apple M4 Pro (arm64)**, where Go 1.26 `simd/archsimd` is **amd64-only**. Every win here must come from portable Go — fewer allocations, better algorithmic complexity, and optional goroutine parallelism — not vectorization. This mirrors the conclusion of the prior `filter().sum()` work.

## Goals / Non-Goals

**Goals:**

- Eliminate per-row `interface{}` boxing on the affected operations by reading typed backing slices and writing typed output buffers (`series.FromColumn`/`FromFloat64`), never round-tripping through `[]any`.
- Make `select`/`with_columns` O(columns) by sharing immutable column buffers by pointer.
- Make `null_count` O(1) and `is_null`/`is_not_null` a single typed pass.
- Replace O(n·w) rolling with O(n) kernels using one output buffer, FP-stable.
- Materialize join output by typed column gather rather than per-cell boxing.
- Preserve **exact** observable behavior (null/NaN handling, FP results, sort order/stability) — every optimized op gets a parity test against current behavior / Python Polars.

**Non-Goals:**

- No SIMD or hand-written assembly (amd64-only / not portable to the bench machine).
- No public API signature changes.
- Not touching `filter().sum()` (already optimized via `FilterAggregateDirect`).
- Not guaranteeing full parity on `sort` — portable Go realistically reaches ≈3–10×, which may not fully close Py×15.5.
- Not removing the row-wise fallback — typed paths are additive; unsupported dtypes still box.

## Decisions

### D1. A shared typed-kernel layer, not per-op bespoke loops

The same shape recurs in every fix: `read typed slice → compute → build typed Series`. Introduce a small internal helper set — typed gather (`gather(col, idx []int) Column`), typed group-key hashing (dtype-switched), typed null/NaN coalesce, and a typed-slice → `Series` constructor that bypasses `[]any` — and route each op through it. **Why:** turns R5–R8 into thin call sites instead of duplicated boxed loops, and concentrates the correctness-sensitive code (null handling, gather bounds) in one tested place. Alternative (bespoke per op) rejected: it is what produced the current divergent boxed implementations.

### D2. Column immutability + copy-on-write for zero-copy projection (R1)

`Series.Rename` becomes metadata-only (`Series{name, col}` sharing the same `*chunk.Column`); `WithColumns`/`Select` build the result by shallow-copying the column *map*/order/schema and reusing the existing `*chunk.Column` pointers for unchanged columns, copying only newly evaluated ones. **Why this is safe:** `chunk.Column` is already de-facto immutable on read paths (`Slice`/`Filter`/`Shift`/`ConcatColumns` all allocate new columns; none mutate the receiver). **Why a guard is still required:** nothing *enforces* it, so a future in-place mutator would corrupt every frame sharing the buffer. Decision: rely on Go's GC for read-sharing (no manual refcount needed — multiple frames hold the same pointer; GC frees on last drop) and add a lightweight copy-on-write discipline: any method that would mutate a column's backing array in place must first clone if the column is shared/possibly-shared. Implementation options for the guard, in preference order: (a) a `frozen`/`shared` bool set when a column is handed to a second frame, checked by mutators; (b) a documented invariant + an audit test asserting no exported path mutates a column in place. **Alternative rejected:** a full atomic-refcount `Arc`-style wrapper (as Polars' `_get_inner_mut` does) — unnecessary under Go's GC for read-sharing and adds overhead to every clone; revisit only if the library later adds true in-place column mutation.

### D3. Typed group/distinct keys (R2)

For `len(keys)==1`, switch on column dtype and key the hash map on the unboxed typed value: `map[int64][]int`, `map[string][]int` (using the interned backing string `strs[i]`), `map[float64][]int` (or `math.Float64bits`). For multi-key, hash into a reused `[]byte` scratch (or fold per-column hashes into a `uint64`) instead of `fmt.Sprintf`+`strings.Join`. **Why:** removes both the `any` box and the per-row formatted string; the aggregation accumulators are already typed. Go 1.24's builtin map is a Swiss table, so `map[int64]` is already well-optimized; presize with `make(map[...], estimatedGroups)`. **Alternative:** custom open-addressing table over the typed slice — deferred; the typed builtin map closes most of the gap at ~100 groups, where the cost is allocation-bound not probe-bound.

### D4. Cached null count + typed validity ops (R3)

Add a `nullCount int` field to `chunk.Column` with `-1 == unknown`; set it in constructors where the count is known, recompute lazily on a `-1` read, and reset to `-1` at every mutation/aliasing site (`FromAny` writes, `Shift`, `copyRow`/`Slice`/`Filter`, `View` sub-slicing, `Clone`, `ConcatColumns`). `is_null`/`is_not_null` build a `[]bool` directly from `col.Nulls()` (copy / invert) via `chunk.NewBool`+`series.FromColumn`, never `[]any`+`FromAny`. **Why the sentinel pattern:** it is Arrow's proven `kUnknownNullCount = -1` design (cited). **Trade-off:** correctness depends on covering *every* mutation site — centralize through the few helper functions and add a test that asserts the cached count equals a fresh scan after each mutating op. **Optional follow-on (not required this change):** migrate `Column.nulls` to a packed `simd.Bitmap` (the repo already has `BitmapPopcount` via `math/bits.OnesCount64`), which makes `null_count` a popcount and `is_null` a near-zero-copy mask op; deferred because it touches every validity read/write and the cache captures the headline `null_count` win at lower risk.

### D5. O(n) rolling kernels (R4)

Rewrite the shared `evalRolling` (and the parallel `seriesFacade.rolling`) to write one preallocated `[]float64` output:

- **sum / mean:** a running accumulator (`+= entering, -= leaving`) with **Kahan/Neumaier compensated summation** (separate `err_add`/`err_sub` terms, matching Polars' `SumWindow`); mean divides by a running `valid_count`.
- **min / max:** a **monotonic-index deque** (`[]int` ring, cap `w+1`): evict expired front, pop dominated tail, push new index; front is the current extremum. Amortized O(1)/element (Lemire 2006; matches Polars' `ArgMinMaxWindow`).
- **nulls / `min_periods`:** track a running null/valid count; emit null when `valid_count < min_periods` (default = window size); only push non-null indices to the deque; provide a no-nulls fast path.

**Why Kahan:** a naive subtract-leaving running sum drifts (catastrophic cancellation), and the benchmark column is mixed-sign — the worst case. Go does not reassociate floats and has no fast-math, so the compensation is preserved; functions must not be built under any FMA-fusing path. **Alternative for adversarial magnitudes:** periodic full window recompute every K steps — kept as a documented fallback. **Reference:** `polars-compute` (cited), not arrow-rs.

### D6. Columnar join output (R7)

Keep the existing build/probe that collects `pairs []{left,right}`. Replace the `map[string][]any` + per-cell `Value()` materialization with: collect `leftIdx`/`rightIdx` slices from `pairs`, then build each output column once via typed gather (`col.Slice(idx)`/`chunk.Gather`) + `series.FromColumn`, null-filling outer `-1` indices. Build the probe key by typed hashing of the key column(s) rather than `fmt.Sprintf`. Cover all modes (inner/left/right/full/semi/anti/cross/asof). **Benchmark fix:** the current `bench/top30` join self-joins on a 5-distinct-value key, exploding 1 K rows to 202 K outputs (and making "join 1M" non-completing); switch to the 1000-distinct-value column `i` and re-add a completable `join 1M`. **Why:** quote the allocation reduction (2.28 M → hundreds), since the ×70.7 time ratio is inflated by the cross-product artifact.

### D7. Parallel + radix numeric sort (R9), gated

For numeric columns above a length threshold, sort via a parallel merge across `NumCPU` and/or an LSD radix sort using the Lemire/Herf order-preserving transform for signed/float keys (`mask = uint64(int64(x)>>63) | 0x8000000000000000; x ^ mask`); keep stdlib `slices.Sort` for small slices and string/arbitrary-comparator columns. **Dependency decision:** prefer an inline implementation (small, no supply-chain/maintenance risk) over vendoring; if a vetted small library is used it must be justified and pinned. **Expectation set explicitly:** ≈3–10× in portable Go, possibly short of Py×15.5 — measure Phase 1–2 first and reassess whether R9 is worth it.

### D8. Parallelism threshold and false-sharing avoidance

Goroutine fan-out (group_by, validity ops, coalesce, sort) is gated on row count (reuse the existing `Filter` parallelism threshold), with each worker writing a disjoint contiguous output range to avoid false sharing. Below the gate, run sequentially. **Why:** below ~1µs/iteration the scheduler overhead dominates; cheap ops on small columns must stay serial.

## Risks / Trade-offs

- **Column aliasing after zero-copy projection (D2)** → a guard (`frozen`/`shared` flag with clone-before-write) plus an audit test that no exported path mutates a shared column in place; ship R1 behind the existing `GOPOLARS_TYPED_STORAGE` rollback if needed.
- **Rolling running-sum FP drift (D5)** → Kahan/Neumaier compensation + parity tests asserting equality with a full-window-recompute reference on mixed-sign and large-magnitude inputs.
- **null_count cache staleness (D4)** → centralize mutation through helpers; test cached-vs-scanned equality after every mutating op; the packed-bitmap alternative (recompute via popcount) sidesteps the cache entirely if invalidation proves fragile.
- **Sort gap may not fully close (D7)** → expectations set; sort is last and reassessed after measurement; no correctness risk as long as order/stability/NaN placement match.
- **Benchmark artifact masking real impact (D6)** → fix the join key cardinality so the suite measures throughput, and report alloc deltas not just time ratios.
- **Scope creep across 9 recommendations** → strict phasing; each phase is independently shippable and individually benchmarked, so value lands incrementally even if later phases slip.

## Migration Plan

Phased rollout, each phase independently shippable and benchmarked:

1. Capture a clean baseline: `GOPOLARS_BENCH_PYTHON=1 go test ./bench/top30 -bench=BenchmarkTop30$ -benchmem -count=10` + `benchstat`; persist `allocs/op` into the committed `bench/top30` summary.
2. Land the foundational typed kernels (D1) + Phase 1 (R1–R3, R5); re-benchmark; verify parity tests + `go test ./... -race`.
3. Land Phase 2 (R4, R6, R7) with the join benchmark fix; re-benchmark.
4. Measure, then decide on Phase 3 (R8, R9).

Rollback: the global `GOPOLARS_TYPED_STORAGE=0` flag already forces the row-wise path; the new typed paths preserve the existing fallback for unsupported dtypes, so any single op can revert to the boxed path without affecting others.

## Open Questions

- Migrate `Column.nulls` to a packed `simd.Bitmap` now, or only after the cached-count approach is proven? (Lean: cache now, bitmap as a separate later change.)
- Inline radix/parallel sort vs vendoring a small library — decide during Phase 3 based on measured Phase 1–2 results and whether `sort` parity is still a priority.
- Exact parallelism thresholds per op — tune empirically against the bench suite rather than fixing in the spec.
