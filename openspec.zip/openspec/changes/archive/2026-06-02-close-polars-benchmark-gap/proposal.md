## Why

The README "Benchmark: gopolars vs Python Polars" table shows Python Polars winning 5–768× on ~20 operations at 1 M rows. A code-grounded investigation (pprof + direct reading; full analysis with file:line evidence and cited references in [research/technical-gopolars-benchmark-optimization-2026-06-01.md](../../../research/technical-gopolars-benchmark-optimization-2026-06-01.md)) found that **one anti-pattern explains 13 of those losses**: per-element `interface{}` boxing via `series.Value(i)` → `chunk.ValueAt(i) any`, plus the `[]any` → `series.New`/`chunk.FromAny` round-trip — producing 1–5 heap allocations *per row*. The remaining losses are whole-column deep-copies on projection, a missing O(1) null-count cache, and O(n·w) rolling kernels. The typed accessors that avoid all of this (`chunk.Float64s/Int64s/Strings/Nulls`, `series.FromColumn/FromFloat64`) already exist but are unused on these paths. Closing this gap directly advances the project's tracked "Performance parity on all workloads" goal.

## What Changes

- **Foundational typed kernels (do first):** shared helpers for typed gather, typed group-key hashing, typed null/NaN coalesce, and typed-slice → `Series` construction that never allocates `[]any`, so each op below becomes a thin call rather than a bespoke boxed loop.
- **Phase 1 (cheap, high-impact, low-risk):**
  - Zero-copy projection: `Series.Rename` becomes metadata-only and `DataFrame.WithColumns`/`Select` share unchanged columns by pointer instead of deep-copying them. (`with_columns` Py×440, `select` Py×52.7.)
  - Typed single-key hashing for `group_by` / `unique` / `n_unique`. (Py×26.3, Py×11.8.)
  - O(1) cached `null_count`; `is_null` / `is_not_null` built directly from the typed validity mask. (Py×768, Py×162/163.)
  - `cum_sum` writes a typed output buffer. (Py×3.3, −1 M allocs.)
- **Phase 2 (medium effort, clear references):**
  - O(n) rolling `sum`/`mean`/`min`/`max` (running compensated accumulator + monotonic deque, single output buffer). (Py×30–42, 895 MB/op → ~constant.)
  - Typed `fill_null` / `fill_nan` coalesce + typed `drop_nans`. (fill_null expr Py×70.6 / df Py×37.9, drop_nans Py×84.)
  - Columnar `join` output via typed index-gather + typed join keys, across all join modes; fix the join benchmark to a high-cardinality key. (allocs 2.28 M → hundreds.)
- **Phase 3 (reassess after measuring 1–2):**
  - Typed `rank` (typed argsort) and `over` (typed partition hash). (Py×11.1, Py×5.9.)
  - Parallel + radix `sort` for numeric columns, gated on length. (Py×15.5; portable Go realistically reaches ≈3–10×.)
- All changes are **additive typed fast paths** — the existing row-wise fallback is preserved for unsupported dtypes. Results (null/NaN handling, FP semantics, sort stability, ordering) are unchanged; each op gets a parity test.

## Capabilities

### New Capabilities

- `zero-copy-projection`: `Select` / `WithColumns` / `Rename` share immutable column buffers by pointer; columns are copy-on-write so a mutation never affects a frame that shares the buffer.
- `typed-group-aggregation`: `group_by`, `unique`, and `n_unique` build group/distinct keys from typed backing slices without per-row `interface{}` boxing or `fmt.Sprintf`.
- `efficient-validity-ops`: `null_count` is O(1) via a cached count with an "unknown" sentinel; `is_null` / `is_not_null` are produced from the typed validity mask without an `[]any` round-trip.
- `linear-rolling-windows`: rolling `sum`/`mean`/`min`/`max` run in O(n) with a single preallocated output buffer and FP-stable accumulation, preserving null and `min_periods` semantics.
- `columnar-join`: equi-join output is materialized by typed index-gather over collected `(left,right)` index pairs, with typed (non-string-formatted) join keys, across all join modes.
- `parallel-numeric-sort`: numeric-column sorts use a parallel and/or radix path above a length threshold while preserving the existing sort order, stability, and NaN placement.

### Modified Capabilities

- `vectorized-expr-kernels`: extend typed batch evaluation to `cum_sum`, `fill_null`, `fill_nan`, `rank`, and `over`, which currently fall back to row-wise `expr.Eval` with `[]any` boxing.
- `typed-column-chunk`: add an immutability / copy-on-write contract and a cached null count to the chunk primitive so columns can be safely shared by pointer (supports `zero-copy-projection` and `efficient-validity-ops`).

## Impact

- **Code:** `pkg/series/series.go` (Rename/Clone), `pkg/frame/frame.go` (`Select`, `WithColumns`, `clone`, `evalCumulative`/`evalRank`/`evalOver`/`evalRolling`, `Unique`/`NUnique`, row-wise fallback), `pkg/frame/groupby.go`, `pkg/frame/join.go`, `pkg/chunk/chunk.go` (validity mask, cached count, immutability guard, gather), `pkg/polars/series.go` (validity/NaN ops, series rolling), `pkg/expr/evalbatch/evalbatch.go` (coalesce ops), `pkg/simd/bitmap.go` (reuse popcount).
- **APIs:** no public signature changes; behavior preserved. The internal `chunk.Column` gains a copy-on-write contract (any future in-place mutator must clone-before-write).
- **Benchmarks:** `bench/top30` (join key cardinality fix; re-add a completable `join 1M`; persist `allocs/op`). Before/after captured with `-benchmem -count=10` + `benchstat`.
- **Dependencies:** portable Go only — no SIMD/assembly (the bench machine is arm64, where Go 1.26 `simd/archsimd` is amd64-only). The parallel/radix sort may vendor a small library or be implemented inline, justified in design.
- **Risk:** the column-immutability contract (aliasing) and the rolling running-sum FP drift (compensated summation) are the two correctness-sensitive areas; both are addressed in design.md with guards and parity tests.
