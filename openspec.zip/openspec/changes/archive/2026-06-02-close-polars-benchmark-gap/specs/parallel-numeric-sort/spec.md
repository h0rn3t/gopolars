## ADDED Requirements

### Requirement: Numeric sorts use a parallel or radix path above a length threshold

Sorting a numeric (`int64`/`float64`) column whose length exceeds a configured threshold SHALL use a parallel comparison sort and/or a radix sort, rather than a single-threaded comparison sort. Below the threshold, and for string or arbitrary-comparator columns, the system SHALL use the standard library sort.

#### Scenario: large numeric sort uses the accelerated path

- **WHEN** an int64 or float64 column above the length threshold is sorted
- **THEN** the system SHALL dispatch to the parallel and/or radix path

#### Scenario: small sort uses the standard library

- **WHEN** a column below the length threshold (or a string/arbitrary-comparator column) is sorted
- **THEN** the system SHALL use `slices.Sort`/`sort` without spawning workers

### Requirement: Sort order, stability, and NaN placement are preserved

The accelerated sort SHALL produce output identical to the existing sort: the same total order, the same documented stability guarantee, and the same placement of NaN values.

#### Scenario: accelerated output equals the existing sort

- **WHEN** the same column is sorted via the accelerated path and the existing sort
- **THEN** the resulting order of values SHALL be identical

#### Scenario: NaN placement matches existing behavior

- **WHEN** a float64 column containing NaN values is sorted
- **THEN** NaN values SHALL appear in the same positions as the existing sort produces

#### Scenario: radix key transform preserves order for signed and float keys

- **WHEN** a radix sort is applied to signed int64 or float64 keys
- **THEN** the order-preserving key transform SHALL yield the same ascending order as a comparison sort over the original values
