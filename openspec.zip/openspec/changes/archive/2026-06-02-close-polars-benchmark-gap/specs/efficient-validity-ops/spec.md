## ADDED Requirements

### Requirement: null_count is O(1) after first computation

`null_count` SHALL return a cached count in constant time after the first computation, rather than scanning the validity mask on every call. The cached count SHALL be marked unknown (recomputed lazily) whenever the column's values or validity are mutated, sliced, or aliased.

#### Scenario: repeated null_count does not rescan

- **WHEN** `null_count` is called more than once on an unmodified column of N rows
- **THEN** only the first call SHALL scan the validity mask; subsequent calls SHALL return the cached value without an O(N) scan

#### Scenario: null_count is correct after mutation

- **WHEN** a column's validity is changed after a prior `null_count` call
- **THEN** the next `null_count` SHALL reflect the new number of nulls (recomputed because the cache was invalidated)

#### Scenario: null_count value matches a full scan

- **WHEN** `null_count` is computed on any column
- **THEN** the returned value SHALL equal the number of indices marked null by a full validity scan

### Requirement: is_null and is_not_null are produced from the typed validity mask

`is_null` and `is_not_null` SHALL build their boolean result directly from the typed validity mask (copying or inverting it) without round-tripping values through an `[]any` slice and `chunk.FromAny`. Allocation SHALL be bounded by a single output buffer, independent of per-row boxing.

#### Scenario: is_null does not box per row

- **WHEN** `is_null` is evaluated on a column of N rows
- **THEN** the result SHALL be built from the validity mask in a single pass with allocation independent of N beyond the one output buffer
- **AND** no `[]any` of length N SHALL be allocated

#### Scenario: is_not_null is the exact inverse of is_null

- **WHEN** both `is_null` and `is_not_null` are evaluated on the same column
- **THEN** for every index the two results SHALL be boolean inverses
