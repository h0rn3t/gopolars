## ADDED Requirements

### Requirement: Typed batch evaluation for cumulative, rank, window, and coalesce expressions

The system SHALL evaluate `cum_sum`, `fill_null`, `fill_nan`, `rank`, and `over` over typed column backing slices, writing typed output buffers, without producing one `interface{}` box per row or round-tripping the result through an `[]any` slice and `chunk.FromAny`. For any dtype not supported by the typed path, the system SHALL fall back to the existing row-wise `expr.Eval` and SHALL surface the fallback in debug diagnostics when enabled.

#### Scenario: cum_sum writes a typed output without boxing

- **WHEN** `cum_sum` is evaluated on a 1,000,000-row numeric column
- **THEN** the running total SHALL be written into a typed output buffer (e.g. `[]float64`)
- **AND** no `interface{}` box SHALL be allocated per row

#### Scenario: fill_null and fill_nan use a typed coalesce kernel

- **WHEN** `fill_null` (or `fill_nan`) with a literal replacement is evaluated on a primitive column
- **THEN** the operation SHALL be recognized by the batch evaluator (not routed to the row-wise fallback)
- **AND** the result SHALL be produced by a typed coalesce over the backing slice without per-row boxing

#### Scenario: rank uses a typed comparator

- **WHEN** `rank` is evaluated on a primitive column
- **THEN** ordering SHALL be computed via a typed argsort/comparator over the backing slice rather than a per-comparison `interface{}`-boxing comparator
- **AND** the output ranks SHALL be written into a typed buffer

#### Scenario: over uses a typed partition key

- **WHEN** `over` partitions by a primitive key column
- **THEN** partition assignment SHALL use a typed key (no `fmt.Sprintf` per row), and per-partition results SHALL be written without per-row boxing

#### Scenario: unsupported dtype still falls back

- **WHEN** any of these expressions is applied to a dtype with no typed kernel (e.g. nested/struct)
- **THEN** the system SHALL fall back to the row-wise path and produce correct results

#### Scenario: results match the row-wise path

- **WHEN** any of `cum_sum`, `fill_null`, `fill_nan`, `rank`, `over` is evaluated via the typed path and the row-wise fallback on the same data
- **THEN** the outputs SHALL be equal (within floating-point tolerance for floating-point results)
