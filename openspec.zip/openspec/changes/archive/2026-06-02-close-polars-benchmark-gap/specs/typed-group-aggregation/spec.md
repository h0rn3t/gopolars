## ADDED Requirements

### Requirement: Single-key grouping hashes the typed backing slice without boxing

When `GroupBy` is performed on a single key column of a primitive dtype, the system SHALL build group keys by reading the typed backing slice (`Int64s`/`Float64s`/`Strings`) and keying a typed map (e.g. `map[int64]`, `map[string]`, `map[float64]`), and SHALL NOT box each row value into `interface{}` via `Value(i)` nor format it via `fmt.Sprintf`. Total heap allocation SHALL scale with the number of distinct groups, not the number of rows.

#### Scenario: int64 single-key group_by allocates per group, not per row

- **WHEN** `group_by` aggregates a 1,000,000-row frame on a single int64 key with G distinct groups
- **THEN** allocations SHALL scale with G, not with the row count
- **AND** no `fmt.Sprintf` or `interface{}` box SHALL be produced per row

#### Scenario: string single-key group_by reuses interned backing strings

- **WHEN** `group_by` groups on a single string key
- **THEN** the map key SHALL be the existing backing string value, not a freshly formatted string per row

### Requirement: unique and n_unique compute distinctness without per-row boxing

`Unique` and `NUnique` SHALL determine distinct rows by reading the typed backing slice into a typed set, without per-row `interface{}` boxing or per-row string concatenation. Total allocation SHALL scale with the number of distinct values, not the row count.

#### Scenario: single-column unique does not box per row

- **WHEN** `unique` is computed on a single primitive column of N rows
- **THEN** no `interface{}` box or concatenated string SHALL be allocated per row

### Requirement: Grouping and distinct results are unchanged

The typed grouping and distinct paths SHALL produce identical group membership, aggregate values, and distinct rows as the prior row-wise implementation, including null handling.

#### Scenario: typed group_by matches row-wise result

- **WHEN** the same `group_by(...).agg(...)` is evaluated via the typed path and the row-wise fallback
- **THEN** group keys and aggregate values SHALL be equal

#### Scenario: multi-key grouping still supported

- **WHEN** `group_by` is given more than one key column
- **THEN** the system SHALL still produce correct groups (via a composite typed key) and SHALL NOT regress correctness relative to the row-wise path
