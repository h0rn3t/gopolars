## ADDED Requirements

### Requirement: Chunk caches its null count

A `ColumnChunk` SHALL maintain a cached null count with an "unknown" sentinel. The count SHALL be computed lazily on first request and returned in constant time thereafter, and SHALL be reset to the unknown sentinel whenever the chunk's values or validity are mutated, sliced/gathered, aliased via a sub-range view, cloned, or concatenated.

#### Scenario: cached count returned without rescan

- **WHEN** the chunk's null count is requested twice without intervening mutation
- **THEN** the second request SHALL return the cached value without rescanning the validity mask

#### Scenario: count invalidated on mutation or aliasing

- **WHEN** a chunk is produced by slicing, gathering, shifting, sub-range viewing, cloning, or concatenating, or its validity is modified
- **THEN** the cached null count SHALL be the unknown sentinel until next computed, and the next computation SHALL equal a full validity scan

### Requirement: Chunk immutability and copy-on-write contract

A `ColumnChunk` SHALL be treated as immutable once it may be shared by more than one frame. Any operation that mutates a chunk's backing value buffer or validity mask in place SHALL first clone the chunk when it is shared, guaranteeing that read-only sharing of a chunk by multiple frames is safe and that a mutation through one owner does not change another owner's view.

#### Scenario: shared chunk is not mutated in place

- **WHEN** a chunk is shared by two frames and one frame performs an operation that would alter values in place
- **THEN** the operation SHALL act on a private clone, leaving the other frame's chunk unchanged

#### Scenario: gather and slice continue to allocate new chunks

- **WHEN** `Slice(indices)` or `Filter(mask)` is applied to a chunk
- **THEN** the result SHALL be a new chunk and the source chunk SHALL be unmodified
