## 1. Baseline & foundational typed kernels

- [x] 1.1 Capture a clean baseline: `GOPOLARS_BENCH_PYTHON=1 go test ./bench/top30 -bench=BenchmarkTop30$ -benchmem -count=10 -timeout=600s` + `benchstat`; persist `allocs/op` and `B/op` into the committed `bench/top30` summary so each later phase has a before/after delta. (Baseline captured in `bench/top30/benchmem.txt`.)
- [x] 1.2 Add a typed gather helper (`chunk.Gather(col, idx []int) Column` / confirm `col.Slice([]int)`) that builds a new chunk from a typed backing slice with null-fill for sentinel `-1` indices; unit-test bounds and null-fill.
- [x] 1.3 Add a dtype-switched typed group-key hashing helper (single-key `int64`/`float64`/`string`; multi-key into a reused `[]byte`/folded `uint64`) with no `interface{}` boxing. (`chunk.GroupIDs`.)
- [x] 1.4 Add a typed null/NaN coalesce helper over `Float64s()`/`Nulls()` (fill null/NaN with a literal) returning a typed chunk. (`chunk.FillNullFloat64`/`FillNaNFloat64`/`DropNaNFloat64`.)
- [x] 1.5 Confirm/extend the typed-slice → `Series` constructors (`series.FromColumn`/`FromFloat64`/`FromInt64`/`FromString`/`FromBool`) so every primitive op can build output without `[]any`; add any missing dtype variant. (Added `series.FromBool`.)

## 2. Phase 1 — R1 Zero-copy projection

- [x] 2.1 Make `Series.Rename` metadata-only (share the `*chunk.Column`, do not `Clone()`) — `pkg/series/series.go:85-89`.
- [x] 2.2 Make `Select` return shared column pointers for plain `Col` projections instead of `Rename`→`Clone` — `pkg/frame/frame.go` (`Select` 243-256, `evalExprAsSeries` 1610-1617). (Inherited from zero-copy `Rename`; verified by pointer-identity test.)
- [x] 2.3 Make `WithColumns` shallow-copy the column map/order/schema and reuse unchanged columns by pointer instead of `d.clone()` deep-copying all columns — `pkg/frame/frame.go:294-308,1595-1608`. (`shallowClone`.)
- [x] 2.4 Add a copy-on-write guard to `chunk.Column` (a `shared`/`frozen` flag set when handed to a second frame; in-place mutators clone-before-write) — `pkg/chunk/chunk.go`. (`MarkShared`/`IsShared`/`CloneIfShared`.)
- [x] 2.5 Add aliasing parity tests: a mutation on a frame derived via projection does not alter the source frame; add an audit test asserting no exported path mutates a shared column in place.
- [x] 2.6 Benchmark `select`/`with_columns`; confirm allocations drop to O(columns) and no row-count-proportional copy remains. (Select 1M: 13→5 allocs, 26 MB→544 B; with_columns alias: 23→6 allocs, 53 MB→832 B.)

## 3. Phase 1 — R2 Typed group/distinct keys

- [x] 3.1 Add a single-key typed-hash fast path in `GroupBy.Agg` (switch on key dtype; key `map[int64]`/`map[string]`/`map[float64]` from the backing slice) — `pkg/frame/groupby.go:22-34`. (Via `chunk.GroupIDs`.)
- [x] 3.2 Add the same single-key typed path in `Unique` and `NUnique` (no `key += fmt.Sprintf`) — `pkg/frame/frame.go:158-168,917-931`.
- [x] 3.3 Implement the multi-key composite key via a reused `[]byte` scratch / folded hash (no `fmt.Sprintf`+`strings.Join`). (`chunk.GroupIDs` composite encoder.)
- [x] 3.4 Parity tests vs the row-wise path (group membership, aggregate values, distinct rows, null handling); benchmark `group_by`/`unique` — confirm allocs scale with groups, not rows. (group_by 1M: 1,000,171→245 allocs; unique 1M: 2,000,022→29 allocs.)

## 4. Phase 1 — R3 Cached null count + typed validity ops

- [x] 4.1 Add a `nullCount int` field (`-1` = unknown) to `chunk.Column`; set it in constructors where the count is known — `pkg/chunk/chunk.go:22-33`. (Stored as `int64`, accessed atomically.)
- [x] 4.2 Reset the cache to `-1` at every mutation/aliasing site: `FromAny` writes, `Shift`, `copyRow`/`Slice`/`Filter`, `View` sub-slice, `Clone`, `ConcatColumns`.
- [x] 4.3 Rewrite `NullCount` to compute-and-cache on `-1`, else return the cached value — `pkg/polars/series.go:73-81`. (`chunk.Column.NullCount`.)
- [x] 4.4 Rewrite `is_null`/`is_not_null` to build a `[]bool` directly from `col.Nulls()` via `series.FromBool`, never `[]any`+`FromAny` — `pkg/polars/series.go:83-99`.
- [x] 4.5 Tests: cached-count equals a fresh scan after each mutating op; `is_null`/`is_not_null` are exact inverses; benchmark `null_count` (1.6 ns/op, 0 allocs) and `is_null` (4 allocs/op).

## 5. Phase 1 — R5 cum_sum typed output

- [x] 5.1 Replace the `[]any` accumulator in `evalCumulative` with a typed `[]float64` written via `series.FromFloat64` — `pkg/frame/frame.go:1678-1707`.
- [x] 5.2 Parity test vs prior output; benchmark `cum_sum` — confirm ~0 allocs/row. (1M: 1,000,014→8 allocs, 42 MB→9 MB.)

## 6. Phase 2 — R4 O(n) rolling windows

- [x] 6.1 Implement a running compensated (Kahan/Neumaier) accumulator kernel for `rolling_sum`/`rolling_mean` — `pkg/chunk/rolling.go` (`rollSumState`, Neumaier add/subtract).
- [x] 6.2 Implement a monotonic-index deque kernel for `rolling_min`/`rolling_max` — `pkg/chunk/rolling.go` (`rollingExtreme`).
- [x] 6.3 Add running null/valid-count tracking + `min_periods` handling (emit null when valid < min); no-nulls handled; only non-null/non-NaN indices pushed to the deque.
- [x] 6.4 Rewrite `evalRolling` to dispatch to the new kernels writing a single preallocated output buffer — `pkg/frame/frame.go` (`rollingFloat64Input` + dispatch).
- [x] 6.5 Rewrite `seriesFacade.rolling` to share the same O(n) kernels — `pkg/polars/series.go` (`rollingFloat64Col` + dispatch, skipNaN=true).
- [x] 6.6 FP-parity tests vs full-window recompute (mixed-sign/large-magnitude within tol; exact min/max); null/min_periods/NaN tests; benchmark — rolling_mean 1M/w100: 938 MB→9 MB, 2,000,016→10 allocs.

## 7. Phase 2 — R6 Typed fill_null / fill_nan / drop_nans

- [x] 7.1 Add `fill_null_expr`/`fill_nan_expr` to `evalbatch` and wire a typed coalesce kernel (reuse 1.4) — `pkg/expr/evalbatch/evalbatch.go` (`coalesceNode`, `supported`).
- [x] 7.2 Route Series/DataFrame `FillNan`/`DropNans`/`FillNull` through the typed `Float64s()`/`Nulls()` path — `pkg/polars/series.go`, `pkg/frame/frame.go`.
- [x] 7.3 Parity tests (null vs NaN semantics; typed-vs-rowwise expr) + benchmarks: Series fill_null/fill_nan/drop_nans now 4 allocs/op (~9 MB output buffer).

## 8. Phase 2 — R7 Columnar join

- [x] 8.1 Replace the `map[string][]any` + per-cell output assembly with typed index-gather (`materializeJoin`): collect leftIdx/rightIdx, build each column once via `chunk.Gather` + `series.FromColumn`, null-filling -1 — `pkg/frame/join.go`.
- [x] 8.2 Build join keys by typed hashing of the key column(s) via `chunk.AppendRowKey` (typed byte encoding, no `fmt.Sprintf`/concat).
- [x] 8.3 Verify all join modes (inner/left/right/full/semi/anti/cross/asof) produce identical rows/null-fill (parity tests per mode in `typed_join_test.go`).
- [x] 8.4 Fix the `bench/top30` join to join the 1M frame against the deduplicated 1000-value `i` dimension (completes at every size) — `top30_bench_test.go`, `harness.py`.
- [x] 8.5 Benchmark — allocations fall ~2.28 M → ~2,050 (1M fact×1000 dim); the per-cell boxing is eliminated (alloc delta, not the artifact-inflated time ratio).

## 9. Phase 3 — R8 Typed rank / over (reassess after measuring Phases 1–2)

- [x] 9.1 Implement a typed argsort for `rank` (no `compareAny` per-comparison boxing, typed `[]int64` output) — `pkg/frame/frame.go` (`evalRank`/`rankSeries`). rank 1M: 999,762→11 allocs.
- [x] 9.2 Implement `over` with a typed partition hash (`chunk.GroupIDs`) + typed accumulation, removing the `fmt.Sprintf` partition key and per-row boxing — `pkg/frame/frame.go` (`evalOver`). over 1M: 5,000,183→18 allocs.
- [x] 9.3 Parity tests (typed-vs-rowwise) + benchmarks for `rank` and `over`.

## 10. Phase 3 — R9 Parallel + radix numeric sort (reassess; expect ≈3–10×, possibly short of Py×15.5)

- [x] 10.1 Implement an LSD radix argsort for `int64`/`float64` using the Lemire/Herf order-preserving key transform; gate on length/single-key/no-null/no-NaN; keep `slices.Sort` otherwise — `pkg/chunk/radix.go` + `frame.radixArgsort`. Decided inline (no vendored dep; sequential radix is bandwidth-bound, parallel merge omitted as low marginal gain).
- [x] 10.2 Tests: sorted output, stability (equal-key order), row integrity, descending; radix key transform order-preservation test.
- [x] 10.3 Benchmark `sort`: 1M float64 206 ms→25.7 ms (~8x). Kept — clear win within the predicted 3–10x range.

## 11. Validation & wrap-up

- [x] 11.1 `go test ./... -race` and `go vet ./...` pass; all new parity tests green.
- [x] 11.2 Re-ran the `bench/top30` suite (`-light`); regenerated the committed `bench/top30` summary (+ `benchmem.txt`, baseline preserved in `benchmem_baseline.txt`) and updated the README benchmark table. Highlights: select 1M Py×52.7→Go×163, with_columns 1M Py×440→Go×25.5, sort 1M Py×15.5→Py×3.4, fill_null 1M Py×37.9→Py×1.3, cum_sum 1M Py×3.3→Go×3.7, rolling_* 1M Py×30-42→Go×1.5-1.8, null_count Py×768→Go×398, join now completes at 1M.
- [x] 11.3 Confirmed `GOPOLARS_TYPED_STORAGE=0` forces the row-wise path and every optimized op preserves a correct fallback for unsupported dtypes (typed-vs-rowwise parity tests + dedicated fallback tests; full suite passes with the flag set).
