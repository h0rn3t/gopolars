## Why

`pkg/polars` is the **public API surface** users import (`import "github.com/h0rn3t/gopolars/pkg/polars"`), yet it sits at **1.5% statement coverage** while the lower layers (`pkg/frame` 77%, `pkg/series` 79%, `pkg/cache` 100%, `pkg/dtypes` 100%, `pkg/simd` 99.6%) are exercised in depth. The package is 7,687 lines across 15 production files and 0 dedicated test files — only `fill_test.go` (110 lines), `validity_test.go` (87 lines) and `filter_aggregate_direct_test.go` (201 lines) exist, and they target a handful of internal paths, not the contract. Every refactor of the type-erasing `DataFrame`/`Series`/`LazyFrame`/`IO`/`SQLContext`/`Expr` wrappers — including the in-flight `close-polars-time-gaps` perf work and the prior `close-polars-benchmark-gap` work — is presently a bet that the user-facing surface still works. The codecov config (`codecov.yml`) is informational, so there is no CI gate catching a silent regression here. Closing this gap protects every user call site and turns the codecov signal from noise into a useful regression alarm.

## What Changes

- Add table-driven Go tests for **every public type and top-level function** exported from `pkg/polars`, in a sibling `*_test.go` per production file, plus a small number of cross-cutting parity tests for the wrappers.
- Cover the **DataFrame** interface (`pkg/polars/dataframe.go`, 1,352 lines): schema accessors, head/tail, select/with_columns/drop/rename, filter/sort, group_by/agg, join, melt, pivot, null/validity, fill_null, casting, arithmetic, comparison, cumulative, rolling/window, write, copy/clone, to_arrow, height/width/n_rows/n_cols, column iteration, and the `PyDataFrameInterchange` shim.
- Cover the **Series** interface and all namespaces (`pkg/polars/series.go` 2,674 lines + `series_low_priority.go` 648 + `series_namespace.go` 223): constructors via `NewSeries`, `Value`/`Values`, `IsNull`/`IsNotNull`/`NullCount`, `Cast`/`Rechunk`/`Slice`/`Filter`/`Shift`/`Rename`/`Clone`/`Sort`, and each namespace's public surface (`SeriesStrNS`, `SeriesDtNS`, `SeriesArrNS`, `SeriesBinNS`, `SeriesCatNS`, `SeriesStructNS`) and the matching methods on `Series` itself.
- Cover the **Expr** constructors (`pkg/polars/expr.go`, 57 lines): `Col`, `Lit`, `Count`, `Sum`, `Min`, `Max`, `Mean`, `NUnique`, `When` — including nested composition.
- Cover the **LazyFrame** interface + `GroupBy`/`LazyGroupBy` (`pkg/polars/lazyframe.go`, 1,089 lines): `Select`/`WithColumns`/`Filter`/`Sort`/`GroupBy`/`Join`/`Limit`/`SinkParquet`/etc., `Collect` happy path and `CollectAsync`, schema accessors, and the `ParseSQL` / `SQLFromDataFrame` entry points.
- Cover the **IO** interface and the `Read{CSV,IPC,JSON,Parquet}`/`Scan{CSV,IPC,JSON,Parquet}`/`Write*` inputs (`pkg/polars/io.go` + `io_types.go`), including round-trip through temp files and streaming `Sink*` paths.
- Cover the **SQLContext** interface (`pkg/polars/sqlcontext.go`, 104 lines): `Register`/`Unregister`/`Execute`/`Tables`/`Get` including the failure modes.
- Cover the **type-erasing aggregation wrappers** (`pkg/polars/analytics.go`, 214 lines): `Melt`, `Pivot`, `RollingMean`, `GroupByDynamic`, `WindowSum` — every input struct's `Validate`/defaulting path and the happy path on a small frame.
- Cover the **Python interop** functions (`pkg/polars/python_interop.go`, 47 lines): `PyArrayDataFrame`, `PyArraySeries`, `PyArrowTableDataFrame`, `PyArrowTableSeries`.
- Cover the **compatibility helper** (`pkg/polars/compatibility.go`, 23 lines): `ClassifyChange` over its full `ChangeClass` taxonomy (`compatible`/`additive`/`breaking`) using the same heuristic matrix used in the unit test of the change that introduced it.
- All tests are **pure Go** (no Python, no external services), use only `testing` + `testify/require` (already used in the repo per `pkg/series/*_test.go`), and run under `go test -race`. They build a small in-memory frame per case and assert on round-trip values; no benchmark or performance assertion in this change.
- **No production code changes.** No public signature changes. No new dependencies. No `GOPOLARS_*` env-var additions.

## Capabilities

### New Capabilities

- `polars-dataframe-api`: Public `DataFrame` interface — every method returns the documented types and respects null/invalid inputs; the type-erasing wrappers compose with the existing `frame`/`series` kernels without panicking.
- `polars-series-api`: Public `Series` interface and all six namespaces (`Str`, `Dt`, `Arr`, `Bin`, `Cat`, `Struct`) — value/null/cast/sort/filter/clone paths, plus each namespace's documented surface.
- `polars-lazyframe-api`: Public `LazyFrame`, `GroupBy`, `LazyGroupBy` interfaces plus `ParseSQL` and `SQLFromDataFrame` entry points — schema accessors, `Collect`, `CollectAsync`, `Sink*`, and the failure paths return errors rather than panicking.
- `polars-io-api`: Public `IO` interface and all `Read*`/`Scan*`/`Write*` input structs — round-trip through temp files for CSV/IPC/JSON/Parquet, including header/schema options, and each `Validate` path.
- `polars-sql-context-api`: Public `SQLContext` interface — `Register`/`Unregister`/`Execute`/`Tables`/`Get` happy and failure paths.
- `polars-expr-api`: Public `Expr` constructors — `Col`/`Lit`/`Count`/`Sum`/`Min`/`Max`/`Mean`/`NUnique`/`When` and their composition produce evaluable expressions.
- `polars-aggregation-wrappers`: Type-erasing aggregation wrappers — `Melt`, `Pivot`, `RollingMean`, `GroupByDynamic`, `WindowSum` and their input structs (`Validate` + defaulting + happy path).
- `polars-python-interop`: Python interop functions — `PyArrayDataFrame`, `PyArraySeries`, `PyArrowTableDataFrame`, `PyArrowTableSeries` produce the documented shapes.
- `polars-compatibility-helper`: `ClassifyChange` returns the correct `ChangeClass` (`compatible`/`additive`/`breaking`) for the documented patterns.

### Modified Capabilities

<!-- None: there are no existing specs for the `pkg/polars` public surface (the closest, `vectorized-expr-kernels` and `typed-column-chunk`, describe the lower-layer kernels in `pkg/frame`/`pkg/chunk`/`pkg/expr`, not the type-erasing wrapper API in `pkg/polars`). All capabilities here are new, with the wrappers tested against the same underlying kernels. -->

## Impact

- **Code (test only, no production changes):** new `pkg/polars/dataframe_test.go`, `series_test.go`, `series_namespace_test.go`, `series_low_priority_test.go`, `lazyframe_test.go`, `io_test.go`, `sqlcontext_test.go`, `expr_test.go`, `analytics_test.go`, `python_interop_test.go`, `compatibility_test.go`, `parity_test.go` (cross-cutting). Existing `fill_test.go`, `validity_test.go`, `filter_aggregate_direct_test.go` are kept and migrated where they cover the new surface.
- **APIs:** zero. Public signatures unchanged; no new exports; no deprecations.
- **CI:** `go test ./...` continues to gate; `go test -race ./pkg/polars/...` is added to the test matrix (already supported by Go's race detector). The codecov config remains informational; per-package coverage on `pkg/polars` becomes the user-visible signal (project target: **≥ 80% statements**, with the `series_low_priority.go` shim and `python_interop.go` allowed to land at 60%+ since they intentionally wrap external surfaces).
- **Dependencies:** none added. `testify/require` is already used in the repo; if absent, `t.Errorf`/`t.Fatalf` is used as a fallback to avoid pulling a new module. No test-only module, no `testdata` binaries committed.
- **Performance:** no benchmarks in this change. Existing `bench/top30` is untouched. Test runtime budget target: total `pkg/polars` tests under 30s on the existing 5m `golangci-lint` runner.
- **Risk:** low. Adding tests, not changing production code. The two risk areas are (a) tests that lock in current buggy behavior — mitigated by writing each test from the public docstring/intent first, then asserting; (b) flaky tests from shared temp dirs — mitigated by using `t.TempDir()` and unique-per-test filenames. CI runs under `-race` so any new race introduced by tests is caught immediately.
