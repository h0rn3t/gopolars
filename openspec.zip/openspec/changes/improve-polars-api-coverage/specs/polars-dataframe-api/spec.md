# polars-dataframe-api

## ADDED Requirements

### Requirement: DataFrame schema and shape accessors
The `polars.DataFrame` interface MUST expose `Height`, `Width`, `NRows`, `NCols`, `Columns`, `Schema`, `Column(name)`, `DTypes`, `GetColumn(name)`, `GetColumns()` returning the documented types and values.

#### Scenario: Shape accessors on a 3-column frame
- **WHEN** a caller constructs a `DataFrame` with 3 columns and 4 rows via `polars.NewDataFrame` and reads `Height`, `Width`, `NCols`, `NCols`, `Columns`
- **THEN** the accessors return `4`, `3`, `3`, `3` and `[]string{"a","b","c"}` in that order without panic

#### Scenario: Schema reports column name and dtype pairs
- **WHEN** a caller reads `Schema()` on a frame with Int64/Float64/String columns
- **THEN** the result contains the three name→dtype entries in column order

#### Scenario: Missing column returns nil and false
- **WHEN** a caller invokes `GetColumn("missing")` on a frame without that column
- **THEN** the second return is `false` and the first is `nil`

### Requirement: DataFrame row and column selection
`Head(n)`, `Tail(n)`, `Slice(start, length)`, `Limit(n)`, `Select(cols...)`, `WithColumns(...)`, `Drop(names...)`, `Rename(mapping)`, `Cast(dtypes)`, `Clone()`, `Clear()` MUST return a new `DataFrame` of the documented shape and never mutate the receiver.

#### Scenario: Head returns the first n rows
- **WHEN** a caller invokes `Head(2)` on a 4-row frame
- **THEN** the result has `Height() == 2` and the row values equal the first two input rows

#### Scenario: Select and Drop return disjoint column sets
- **WHEN** a caller invokes `Select("a")` then `Drop("a")` on the same frame
- **THEN** the first has one column named `"a"`, the second has the original columns minus `"a"`

#### Scenario: Rename preserves data and column count
- **WHEN** a caller renames `"a"→"x"` and reads the column back
- **THEN** the frame has the same number of columns and `"x"` holds the original `"a"` values

### Requirement: DataFrame row filters and sort
`Filter(mask)`, `Sort(by, ...)`, `Distinct()`, `Unique(subset)` MUST return a `DataFrame` whose row set matches the documented predicate and whose sort is stable for equal keys.

#### Scenario: Filter with a boolean column keeps matching rows
- **WHEN** a caller invokes `Filter` with a boolean series whose `True` indices are `[0, 2]`
- **THEN** the result has `Height() == 2` and the row indices match

#### Scenario: Sort produces ascending order
- **WHEN** a caller invokes `Sort("a")` on a frame whose `"a"` column is `[3,1,2]`
- **THEN** the result's `"a"` column equals `[1,2,3]`

#### Scenario: Sort is stable on equal keys
- **WHEN** a caller invokes `Sort("a")` on a frame where `"a"` has duplicate values and `"b"` carries a tie-breaker
- **THEN** the result preserves the original relative order of equal-`"a"` rows as reported by `"b"`

### Requirement: DataFrame group-by and aggregation
`GroupBy(by...)`, `agg := df.GroupBy(...).Agg(exprs...)` MUST return a `DataFrame` whose group key columns are unique and whose aggregate columns match the spec of each `Expr`.

#### Scenario: GroupBy with Sum yields one row per group
- **WHEN** a caller groups by `"g"` (3 unique values) and aggregates `Sum("v")`
- **THEN** the result has `Height() == 3` and the sum column equals the per-group total

#### Scenario: GroupBy with multiple aggregations
- **WHEN** a caller groups by `"g"` and aggregates both `Sum("v")` and `Mean("v")`
- **THEN** the result has 2 aggregate columns and the values are consistent with the same grouping

### Requirement: DataFrame joins
`Join(other, on, how)` MUST return a `DataFrame` whose column set and row set match the documented join kind for `inner`/`left`/`right`/`outer`/`cross`/`semi`/`anti`.

#### Scenario: Inner join keeps only matching keys
- **WHEN** a caller performs an inner join on key `"k"` between a left frame with keys `[1,2,3]` and a right frame with keys `[2,3,4]`
- **THEN** the result has `Height() == 2` and the key column contains only `2` and `3`

#### Scenario: Left join keeps all left rows
- **WHEN** a caller performs a left join with the same inputs
- **THEN** the result has `Height() == 3` and the right-side columns for the unmatched key `1` are null

### Requirement: DataFrame melt and pivot
`Melt(df, MeltInput)` and `Pivot(df, PivotInput)` MUST return a `DataFrame` whose columns and rows match the documented long-form / wide-form transformation.

#### Scenario: Melt with two value columns
- **WHEN** a caller melts a frame with `id_vars=["g"]` and `value_vars=["a","b"]`
- **THEN** the result has columns `["g","variable","value"]` and one row per `(g, variable)` combination

#### Scenario: Pivot with one index and one value column
- **WHEN** a caller pivots a long frame with `index="g"`, `columns="k"`, `values="v"`
- **THEN** the result has one row per unique `g` and one column per unique `k`

### Requirement: DataFrame null and validity operations
`IsNull()`, `IsNotNull()`, `FillNull(strategy)`, `DropNulls()`, `DropNaNs()` MUST return a `DataFrame` or `Series` consistent with the operation and never panic on empty inputs.

#### Scenario: FillNull with a literal value replaces nulls
- **WHEN** a caller invokes `FillNull` with a literal `int64(0)` on a column containing nulls
- **THEN** the result column has no nulls and the non-null values are preserved

#### Scenario: DropNulls removes rows with any null
- **WHEN** a caller invokes `DropNulls` on a frame whose row 0 has a null
- **THEN** the result has one fewer row and the value at the position previously occupied by the null row is gone

### Requirement: DataFrame arithmetic and comparison
`Add`, `Sub`, `Mul`, `Div`, `Rem`, arithmetic on a literal, and `Eq`/`Ne`/`Lt`/`Le`/`Gt`/`Ge`/`And`/`Or`/`Not` MUST return a `DataFrame` or `Series` whose values are the elementwise result of the operation on numeric or boolean columns.

#### Scenario: Add of two numeric columns is elementwise
- **WHEN** a caller adds columns `"a"` (values `[1,2,3]`) and `"b"` (values `[10,20,30]`)
- **THEN** the result column is `[11,22,33]`

#### Scenario: Eq returns a boolean series
- **WHEN** a caller compares a numeric column to a literal
- **THEN** the result is a boolean `Series` of the same height

### Requirement: DataFrame cumulative and rolling/window
`CumSum`, `CumMax`, `CumMin`, `CumProd`, `Diff`, `PctChange`, `RollingMean(input)`, `RollingSum(input)`, `GroupByDynamic(input)`, `WindowSum(input)` MUST return a `DataFrame` or `Series` whose length and values match the documented window parameters.

#### Scenario: RollingMean with window=3
- **WHEN** a caller invokes `RollingMean` with `WindowSize=3` on a column `[1,2,3,4,5]`
- **THEN** the result is `[NaN, NaN, 2, 3, 4]` (or the package's documented partial-window convention)

#### Scenario: GroupByDynamic with a time index
- **WHEN** a caller invokes `GroupByDynamic` with `Every="1h"` on a frame with a datetime index and a value column
- **THEN** the result has one row per bucket and the aggregated value is the documented per-bucket reduction

### Requirement: DataFrame write and interop
`WriteCSV`, `WriteIPC`, `WriteJSON`, `WriteParquet`, `ToArrow`, `ToSeries`, `PyDataFrameInterchange` MUST round-trip the frame's rows and schema to the documented output.

#### Scenario: Round-trip via Parquet
- **WHEN** a caller writes a frame to a temp Parquet file and reads it back via `IO`
- **THEN** the read frame has the same `Height`, `Width`, `Columns`, and cell values

#### Scenario: ToArrow preserves schema
- **WHEN** a caller invokes `ToArrow` on a frame with Int64/Float64/String columns
- **THEN** the returned arrow table's schema contains three fields with the documented dtypes

#### Scenario: PyDataFrameInterchange returns a DataFrame
- **WHEN** a caller invokes `PyDataFrameInterchange(df)`
- **THEN** the returned `DataFrame` is non-nil and has the same `Height` and `Columns` as the input
