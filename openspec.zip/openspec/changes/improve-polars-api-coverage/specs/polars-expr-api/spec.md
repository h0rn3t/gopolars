# polars-expr-api

## ADDED Requirements

### Requirement: Expr column reference and literal
`polars.Col(name)` MUST return an `Expr` whose `String()` / `Format()` / `Evaluate(df)` against a frame with that column produces the matching sub-series; `polars.Lit(v)` MUST return an `Expr` that evaluates to a constant series of `v`.

#### Scenario: Col references the named column
- **WHEN** a caller builds `polars.Col("a")` and evaluates it against a frame with column `"a"`
- **THEN** the resulting series has the same `Name()`, `Len()`, and `Values()` as the input column

#### Scenario: Lit produces a constant
- **WHEN** a caller builds `polars.Lit(int64(7))` and evaluates it against a 4-row frame
- **THEN** the resulting series has `Len() == 4` and every value equals `7`

### Requirement: Expr aggregation constructors
`Sum(e)`, `Min(e)`, `Max(e)`, `Mean(e)`, `Count()`, `NUnique(e)` MUST return an `Expr` that, when used in a `GroupBy(...).Agg(...)` call, produces an aggregate column with the documented reduction.

#### Scenario: Sum aggregate
- **WHEN** a caller groups by `"g"` and aggregates `Sum(polars.Col("v"))`
- **THEN** the aggregate column equals the per-group sum of `"v"`

#### Scenario: Min and Max aggregates
- **WHEN** a caller groups by `"g"` and aggregates `Min` and `Max` on `"v"`
- **THEN** the two aggregate columns equal the per-group min and max

#### Scenario: Mean aggregate
- **WHEN** a caller groups by `"g"` and aggregates `Mean(polars.Col("v"))`
- **THEN** the aggregate column equals the per-group mean

#### Scenario: Count aggregate
- **WHEN** a caller groups by `"g"` and aggregates `polars.Count()`
- **THEN** the aggregate column equals the per-group row count

#### Scenario: NUnique aggregate
- **WHEN** a caller groups by `"g"` and aggregates `NUnique(polars.Col("v"))`
- **THEN** the aggregate column equals the per-group distinct count of `"v"`

### Requirement: Expr conditional
`When(cond, then, otherwise)` MUST return an `Expr` that, when evaluated, produces a series whose values are `then[i]` where `cond[i]` is true and `otherwise[i]` where `cond[i]` is false.

#### Scenario: When picks then where the predicate is true
- **WHEN** a caller builds `When(polars.Col("a").Gt(polars.Lit(int64(0))), polars.Lit(int64(1)), polars.Lit(int64(0)))` and evaluates
- **THEN** the result is a series with value `1` where `"a" > 0` and `0` otherwise

#### Scenario: When with non-bool cond returns an error
- **WHEN** a caller builds `When` with a non-boolean `cond` expression
- **THEN** evaluating the expression returns a non-nil `error` rather than panicking

### Requirement: Expr composition
Expr values MUST be composable: passing an `Expr` to `Sum`, `Min`, `Max`, `Mean`, `NUnique`, `When` produces a valid expression that evaluates without panic against a frame whose schema supports the inner expressions.

#### Scenario: Sum of a literal produces a constant aggregate
- **WHEN** a caller builds `Sum(polars.Lit(int64(3)))` and uses it in a `GroupBy(...).Agg(...)`
- **THEN** the aggregate column equals `3` for every group

#### Scenario: When with a nested Sum
- **WHEN** a caller builds `When(polars.Col("a").Gt(polars.Lit(int64(0))), polars.Lit(int64(1)), polars.Lit(int64(0)))` and uses it as a select expression
- **THEN** the resulting frame has the expected values for every row
