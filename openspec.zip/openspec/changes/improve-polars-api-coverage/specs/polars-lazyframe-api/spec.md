# polars-lazyframe-api

## ADDED Requirements

### Requirement: LazyFrame construction and schema accessors
`polars.NewLazyFrame(input)`, `Schema()`, `Columns()`, `DTypes()`, `Width()`, `Height()` MUST produce a `LazyFrame` whose accessors return the schema supplied at construction.

#### Scenario: NewLazyFrame exposes the input schema
- **WHEN** a caller constructs a lazy frame with three Int64 columns named `["a","b","c"]`
- **THEN** `Schema()` returns the three name→dtype entries, `Columns()` returns `["a","b","c"]`, `Width()` returns `3`

#### Scenario: Height reports the input row count
- **WHEN** a caller constructs a lazy frame with `Height: 1024`
- **THEN** `Height()` returns `1024`

### Requirement: LazyFrame projection, filter, sort
`Select(exprs...)`, `WithColumns(exprs...)`, `Drop(names...)`, `Filter(expr)`, `Sort(exprs...)`, `Limit(n)`, `Slice(offset, length)` MUST return a `LazyFrame` whose `Collect()` output matches the documented transformation.

#### Scenario: Select projects the named columns
- **WHEN** a caller calls `Select(polars.Col("a"))` and `Collect()` on a 3-column frame
- **THEN** the resulting eager frame has `Width() == 1` and `Columns() == ["a"]`

#### Scenario: Filter keeps only rows where the predicate is true
- **WHEN** a caller calls `Filter(polars.Col("a").Gt(polars.Lit(int64(0))))` and `Collect()`
- **THEN** every row in the result has `"a" > 0`

#### Scenario: Limit caps the number of output rows
- **WHEN** a caller calls `Limit(5)` and `Collect()` on a 100-row frame
- **THEN** the eager result has `Height() == 5`

### Requirement: LazyFrame group-by and aggregation
`GroupBy(by...)` returning a `LazyGroupBy`, `agg := lgb.Agg(exprs...)`, MUST `Collect()` to a `DataFrame` whose group key columns are unique and whose aggregate columns match the expression.

#### Scenario: GroupBy with Sum
- **WHEN** a caller groups by `"g"` and aggregates `Sum(polars.Col("v"))` on a frame with 3 groups
- **THEN** the result has `Height() == 3` and the sum column equals the per-group total

#### Scenario: GroupBy with multiple aggregations
- **WHEN** a caller groups by `"g"` and aggregates `Sum` and `Mean` on `"v"`
- **THEN** the result has 2 aggregate columns with values consistent with the same grouping

### Requirement: LazyFrame join
`Join(other, on, how)` MUST return a `LazyFrame` whose `Collect()` result matches the documented join kind for the supported `JoinType` values.

#### Scenario: Inner join via lazy frame
- **WHEN** a caller performs an inner join on key `"k"` between two lazy frames
- **THEN** the collected result contains only rows whose key appears in both inputs

#### Scenario: Left join via lazy frame
- **WHEN** a caller performs a left join on key `"k"` between two lazy frames
- **THEN** the collected result contains all left rows; right-side columns for unmatched left keys are null

### Requirement: LazyFrame collect paths
`Collect()` MUST run the plan synchronously and return an eager `DataFrame`; `CollectAsync()` MUST return a `polars.AsyncCollectResult` whose `Result()` resolves to an eager `DataFrame` or an error.

#### Scenario: Synchronous Collect returns a DataFrame
- **WHEN** a caller invokes `Collect()` on a lazy frame
- **THEN** the returned value is a non-nil `DataFrame`

#### Scenario: Async Collect resolves to a DataFrame
- **WHEN** a caller invokes `CollectAsync()` and reads the result via `Result()`
- **THEN** the resolved value is a non-nil `DataFrame` whose `Columns()` matches the lazy schema

#### Scenario: Collect on a failed plan returns an error
- **WHEN** a caller invokes `Collect()` on a lazy frame whose `Select` references a missing column
- **THEN** the second return is a non-nil `error` and the first return is `nil`

### Requirement: LazyFrame sink paths
`SinkParquet`, `SinkIPC`, `SinkCSV`, `SinkNDJSON` MUST write the result of the plan to the path given in the input and return an error only on I/O failure.

#### Scenario: SinkParquet produces a readable file
- **WHEN** a caller invokes `SinkParquet` to a `t.TempDir()` path and then reads the file via `IO.ReadParquet`
- **THEN** the read frame has the same columns and row count as the lazy plan output

#### Scenario: Sink to an unwritable path returns an error
- **WHEN** a caller invokes `SinkParquet` to a path inside a non-existent directory
- **THEN** the call returns a non-nil `error`

### Requirement: LazyFrame SQL entry points
`polars.ParseSQL(ParseSQLInput)` and `polars.SQLFromDataFrame(ctx, source, query, table)` MUST return a `LazyFrame` that, when collected, produces the documented query result.

#### Scenario: ParseSQL produces a valid LazyFrame
- **WHEN** a caller invokes `ParseSQL` with a SELECT against a registered table
- **THEN** `Collect()` returns a `DataFrame` whose `Columns()` includes the projected columns

#### Scenario: SQLFromDataFrame uses the in-memory source
- **WHEN** a caller invokes `SQLFromDataFrame` with an in-memory frame as the FROM source
- **THEN** `Collect()` returns rows sourced from that frame
