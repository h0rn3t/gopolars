# polars-io-api

## ADDED Requirements

### Requirement: IO construction and registration
`polars.NewIO()` MUST return a non-nil `polars.IO` whose `Read*`/`Scan*`/`Write*` methods are callable on a `*testing.T` test process.

#### Scenario: NewIO returns a non-nil IO
- **WHEN** a caller invokes `polars.NewIO()`
- **THEN** the returned value is a non-nil `polars.IO` and is not equal to a second invocation's result (each call is independent)

### Requirement: IO Read paths
`ReadCSV`, `ReadIPC`, `ReadJSON`, `ReadParquet` MUST return a `DataFrame` whose `Columns`, `DTypes`, and row values match the input file.

#### Scenario: ReadCSV round-trip
- **WHEN** a caller writes a frame to a temp CSV file and reads it back via `IO.ReadCSV`
- **THEN** the read frame has the same `Columns()` and the same per-row values for the supported dtypes

#### Scenario: ReadParquet round-trip
- **WHEN** a caller writes a frame to a temp Parquet file and reads it back via `IO.ReadParquet`
- **THEN** the read frame has the same `Columns()`, `DTypes()`, and `Height()`

#### Scenario: ReadIPC round-trip
- **WHEN** a caller writes a frame to a temp IPC file and reads it back via `IO.ReadIPC`
- **THEN** the read frame has the same `Columns()` and the same row values

#### Scenario: ReadJSON round-trip
- **WHEN** a caller writes a frame to a temp NDJSON file and reads it back via `IO.ReadJSON`
- **THEN** the read frame has the same `Columns()` and the same row values for the supported dtypes

#### Scenario: Read missing file returns an error
- **WHEN** a caller invokes `IO.ReadCSV` on a path that does not exist
- **THEN** the call returns a non-nil `error` and a `nil` `DataFrame`

### Requirement: IO Scan paths (lazy)
`ScanCSV`, `ScanIPC`, `ScanJSON`, `ScanParquet` MUST return a `LazyFrame` whose `Collect()` produces the same result as the corresponding `Read*` path.

#### Scenario: ScanCSV followed by Collect
- **WHEN** a caller scans a CSV file and calls `Collect()`
- **THEN** the result has the same `Columns()` and `Height()` as a direct `ReadCSV` of the same file

#### Scenario: ScanParquet honors row-limit pushdown
- **WHEN** a caller scans a Parquet file with `NRows: 5` set on the input and calls `Collect()`
- **THEN** the result has `Height() == 5`

### Requirement: IO Write paths
`WriteCSV`, `WriteIPC`, `WriteJSON`, `WriteParquet` MUST write a file at the given path that the matching `Read*` path can read back without data loss for the supported dtypes.

#### Scenario: WriteCSV then ReadCSV preserves rows
- **WHEN** a caller invokes `IO.WriteCSV` to a temp path and then `IO.ReadCSV` on that path
- **THEN** the read frame equals the written frame on a per-cell basis for the supported dtypes

#### Scenario: WriteParquet then ReadParquet preserves schema
- **WHEN** a caller invokes `IO.WriteParquet` and reads it back
- **THEN** the read frame's `Schema()` reports the same name→dtype pairs as the input

#### Scenario: Write to an unwritable path returns an error
- **WHEN** a caller invokes `IO.WriteCSV` with a path inside a non-existent directory
- **THEN** the call returns a non-nil `error`

### Requirement: IO input validation
The `ReadCSVInput`, `ReadIPCInput`, `ReadJSONInput`, `ReadParquetInput`, `ScanCSVInput`, `ScanIPCInput`, `ScanJSONInput`, `ScanParquetInput`, `WriteCSVInput`, `WriteIPCInput`, `WriteJSONInput`, `WriteParquetInput` struct fields MUST be honored: e.g., `HasHeader` on CSV controls whether the first row is treated as a header; `Compression` on Parquet controls the codec.

#### Scenario: ReadCSV with HasHeader=false treats first row as data
- **WHEN** a caller writes a CSV without a header and reads it with `HasHeader: false`
- **THEN** the read frame's `Height()` includes the first row and the column names are the auto-generated `column_0..N-1`

#### Scenario: ReadParquet with a column projection
- **WHEN** a caller writes a 3-column Parquet file and reads it with `Columns: []string{"a"}`
- **THEN** the read frame has `Width() == 1` and `Columns() == ["a"]`
