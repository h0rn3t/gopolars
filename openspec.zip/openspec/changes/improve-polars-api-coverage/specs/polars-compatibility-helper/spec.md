# polars-compatibility-helper

## ADDED Requirements

### Requirement: ClassifyChange categorizes descriptions
`polars.ClassifyChange(description)` MUST return `polars.ChangeClassCompatible` for descriptions that match the "compatible" pattern (default), `polars.ChangeClassDeprecating` for descriptions containing the substring "deprecat" (case-insensitive), and `polars.ChangeClassBreaking` for descriptions containing "breaking", "remove " (with trailing space), or "drop " (with trailing space) — all case-insensitive.

#### Scenario: Compatible description
- **WHEN** a caller invokes `ClassifyChange("Fix off-by-one in null count.")` or another phrase matching none of the keywords
- **THEN** the result is `polars.ChangeClassCompatible`

#### Scenario: Deprecating description
- **WHEN** a caller invokes `ClassifyChange("Deprecate the legacy entry point.")` or `ClassifyChange("DEPRECATE old function")` (case-insensitive)
- **THEN** the result is `polars.ChangeClassDeprecating`

#### Scenario: Breaking description
- **WHEN** a caller invokes `ClassifyChange("Breaking change in API surface.")` or `ClassifyChange("Remove deprecated Foo()")` or `ClassifyChange("Drop support for old format")` (case-insensitive)
- **THEN** the result is `polars.ChangeClassBreaking`

#### Scenario: Ambiguous description defaults to compatible
- **WHEN** a caller invokes `ClassifyChange("")` or any other description matching no keyword
- **THEN** the result is the documented default `polars.ChangeClassCompatible`

### Requirement: ChangeClass constants expose the documented values
The exported constants `polars.ChangeClassCompatible`, `polars.ChangeClassDeprecating`, `polars.ChangeClassBreaking` MUST have the values `"compatible"`, `"deprecating"`, `"breaking"` respectively.

#### Scenario: Constant values
- **WHEN** a caller compares each constant to its expected string
- **THEN** `ChangeClassCompatible == "compatible"`, `ChangeClassDeprecating == "deprecating"`, `ChangeClassBreaking == "breaking"`

