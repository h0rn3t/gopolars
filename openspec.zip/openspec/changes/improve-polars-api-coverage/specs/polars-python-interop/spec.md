# polars-python-interop

## ADDED Requirements

### Requirement: PyArray conversion
`polars.PyArrayDataFrame(df)` and `polars.PyArraySeries(s)` MUST return a `[][]any` and `[]any` respectively whose length matches the frame's `Height()` and whose inner element types match the documented dtypes.

#### Scenario: PyArrayDataFrame rows equal frame values
- **WHEN** a caller invokes `PyArrayDataFrame` on a 2-row, 2-column Int64 frame
- **THEN** the result has length `2`, each inner slice has length `2`, and every element is the original `int64` value

#### Scenario: PyArraySeries length equals series length
- **WHEN** a caller invokes `PyArraySeries` on a 4-element Int64 series
- **THEN** the result has length `4` and every element is the original `int64` value

#### Scenario: PyArrayDataFrame on an empty frame returns an empty slice
- **WHEN** a caller invokes `PyArrayDataFrame` on a 0-row frame
- **THEN** the result is a `[][]any` of length `0` (not `nil`, and not a panic)

### Requirement: PyArrowTable conversion
`polars.PyArrowTableDataFrame(df)` and `polars.PyArrowTableSeries(s)` MUST return a non-nil `iarrow.Table` whose schema equals the frame's or series's `Schema()` and whose row count matches the height.

#### Scenario: PyArrowTableDataFrame schema matches
- **WHEN** a caller invokes `PyArrowTableDataFrame` on a frame with Int64 and String columns
- **THEN** the returned arrow table's schema contains the same two fields with the same dtypes

#### Scenario: PyArrowTableSeries schema matches
- **WHEN** a caller invokes `PyArrowTableSeries` on a series named `"x"` with dtype Int64
- **THEN** the returned arrow table's schema contains one field named `"x"` of dtype Int64

#### Scenario: PyArrowTableDataFrame on a frame with unsupported dtype returns an error
- **WHEN** a caller invokes `PyArrowTableDataFrame` on a frame containing a dtype the conversion cannot represent
- **THEN** the call returns a non-nil `error` and a `nil` table
