# polars-aggregation-wrappers

## ADDED Requirements

### Requirement: Melt
`polars.Melt(df, MeltInput)` MUST return a `DataFrame` whose `Columns()` equals `id_vars + ["variable", "value"]` and whose `Height()` equals `len(id_vars_rows) * len(value_vars)` for the documented inputs.

#### Scenario: Melt with one id and two value columns
- **WHEN** a caller invokes `Melt` with `id_vars=["g"]` and `value_vars=["a","b"]` on a 2-row frame
- **THEN** the result has `Columns() == ["g","variable","value"]` and `Height() == 4`

#### Scenario: Melt with empty value_vars
- **WHEN** a caller invokes `Melt` with `value_vars=[]string{}`
- **THEN** the call returns a `DataFrame` with the documented empty-result shape (no value rows)

### Requirement: Pivot
`polars.Pivot(df, PivotInput)` MUST return a `DataFrame` whose `Columns()` includes the unique values of the `Columns` field and whose `Height()` equals the unique `Index` count.

#### Scenario: Pivot with one index and two unique column values
- **WHEN** a caller invokes `Pivot` with `Index="g"`, `Columns="k"`, `Values="v"` on a frame whose unique `k` values are `["x","y"]`
- **THEN** the result has one row per unique `"g"` and one column per unique `"k"`

#### Scenario: Pivot with aggregate function
- **WHEN** a caller invokes `Pivot` with `AggregateFunction="sum"` on a frame with duplicate `(index, column)` pairs
- **THEN** the result's cell values are the documented per-`(index,column)` aggregate

### Requirement: RollingMean
`polars.RollingMean(df, RollingMeanInput)` MUST return a `DataFrame` whose value column is the rolling mean of the input column over the documented window.

#### Scenario: RollingMean with a window of 3
- **WHEN** a caller invokes `RollingMean` with `WindowSize=3` on a 5-row numeric column
- **THEN** the result column has the documented values for partial and full windows

#### Scenario: RollingMean with a non-numeric column returns an error
- **WHEN** a caller invokes `RollingMean` on a String column
- **THEN** the call returns a non-nil `error`

### Requirement: GroupByDynamic
`polars.GroupByDynamic(df, DynamicGroupInput)` MUST return a `DataFrame` with one row per time bucket and aggregate columns computed over the bucket.

#### Scenario: GroupByDynamic with 1h buckets
- **WHEN** a caller invokes `GroupByDynamic` with `Every="1h"` on a frame with a datetime index and a value column
- **THEN** the result has one row per unique hour bucket and the value column is the per-bucket reduction

#### Scenario: GroupByDynamic with an invalid `Every` string returns an error
- **WHEN** a caller invokes `GroupByDynamic` with `Every="not-a-duration"`
- **THEN** the call returns a non-nil `error`

### Requirement: WindowSum
`polars.WindowSum(df, WindowSumInput)` MUST return a `DataFrame` whose value column is the windowed sum of the input column over the documented window.

#### Scenario: WindowSum with a window of 3
- **WHEN** a caller invokes `WindowSum` with `WindowSize=3` on a 5-row numeric column
- **THEN** the result column has the documented values for partial and full windows

#### Scenario: WindowSum with a non-numeric column returns an error
- **WHEN** a caller invokes `WindowSum` on a String column
- **THEN** the call returns a non-nil `error`
