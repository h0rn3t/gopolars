# polars-series-api

## ADDED Requirements

### Requirement: Series construction and basic accessors
`polars.NewSeries(input)`, `Name()`, `DataType()`, `Len()`, `IsNull(i)`, `IsNotNull(i)`, `Value(i)`, `Values()`, `Column()` MUST produce a `polars.Series` whose accessors return the values supplied to `NewSeries`.

#### Scenario: NewSeries with Int64 values
- **WHEN** a caller constructs a series named `"x"` with values `[1,2,3]` and a non-null bitmap
- **THEN** `Name()` returns `"x"`, `DataType()` reports Int64, `Len()` returns `3`, `Value(0)` returns `int64(1)`

#### Scenario: NewSeries with a nullable column
- **WHEN** a caller constructs a series with values `[1,0,3]` and a null bitmap marking index 1
- **THEN** `IsNull(1)` is `true`, `IsNotNull(1)` is `false`, `IsNull(0)` is `false`

### Requirement: Series transformation methods
`Cast(dtype)`, `Rechunk()`, `Slice(start, length)`, `Filter(mask)`, `Shift(n)`, `Rename(name)`, `Clone()`, `Sort(ascending)`, `Reverse()` MUST return a new `Series` of the documented length and dtype and never mutate the receiver.

#### Scenario: Cast changes dtype and preserves values where representable
- **WHEN** a caller invokes `Cast` from Int64 to Float64 on `[1,2,3]`
- **THEN** the result has dtype Float64 and the values are `[1.0, 2.0, 3.0]`

#### Scenario: Slice keeps the documented half-open range
- **WHEN** a caller invokes `Slice(1, 2)` on a 4-element series
- **THEN** the result has `Len() == 2` and the values are the original indices `1` and `2`

#### Scenario: Filter drops indices where the mask is false
- **WHEN** a caller filters a series with mask `[true, false, true]`
- **THEN** the result has `Len() == 2` and the values are the original indices `0` and `2`

#### Scenario: Sort ascending and descending
- **WHEN** a caller invokes `Sort(true)` and `Sort(false)` on `[3,1,2]`
- **THEN** the two results equal `[1,2,3]` and `[3,2,1]` respectively

### Requirement: Series string namespace
`Series.Str` (a `SeriesStrNS`) MUST expose the documented string operations on a series whose dtype is String: `Lengths`, `ToLowercase`, `ToUppercase`, `Strip`, `StripChars`, `StartsWith`, `EndsWith`, `Contains`, `Replace`, `ReplaceAll`, `Slice(s, n)`, `Concat`, `Join`, `Split`, `Extract`, `ExtractAll`, `CountMatch`, `ZFill`, `PadStart`, `PadEnd`, `Head`, `Tail`, `ToInteger`, `ToFloat`.

#### Scenario: Lengths returns integer lengths per element
- **WHEN** a caller invokes `Str.Lengths()` on `["a","bb","ccc"]`
- **THEN** the result is an Int32/Int64 series with values `[1,2,3]`

#### Scenario: ToLowercase / ToUppercase preserve length and dtype
- **WHEN** a caller invokes `Str.ToLowercase()` on `["AbC"]`
- **THEN** the result equals `["abc"]`

#### Scenario: Replace replaces the first occurrence by default
- **WHEN** a caller invokes `Str.Replace("a", "X")` on `["aaa"]`
- **THEN** the result equals `["Xaa"]`

### Requirement: Series datetime namespace
`Series.Dt` (a `SeriesDtNS`) MUST expose the documented datetime operations on a Date/Datetime series: `Year`, `Month`, `Day`, `Hour`, `Minute`, `Second`, `Millisecond`, `Microsecond`, `Nanosecond`, `Weekday`, `Week`, `DayOfYear`, `OrdinalDay`, `TotalDays`, `TotalSeconds`, `TotalMilliseconds`, `TotalMicroseconds`, `TotalNanoseconds`, `ToUnixEpoch`, `ConvertTimeZone`, `ReplaceTimeZone`, `Truncate`, `Round`, `AddBusinessDays`, `IsBusinessDay`, `BusinessDayCount`, `OffsetBy`, `Combine`.

#### Scenario: Year returns the calendar year
- **WHEN** a caller constructs a Datetime series with timestamps `2024-01-15T00:00:00Z` and `2025-06-01T00:00:00Z`
- **THEN** `Dt.Year()` returns `[2024, 2025]`

#### Scenario: Truncate honors the resolution argument
- **WHEN** a caller invokes `Dt.Truncate("1h")` on a per-second datetime series
- **THEN** every timestamp is snapped down to the start of its hour

### Requirement: Series list/array namespace
`Series.Arr` (a `SeriesArrNS`) MUST expose `Lengths`, `Min`, `Max`, `Sum`, `Mean`, `Median`, `Std`, `Var`, `First`, `Last`, `Get(i)`, `Join(sep)`, `Contains`, `Concat`, `Slice`, `ToStruct`, `ToList`, `Unique`, `NUnique`, `Sort`, `Reverse`, `Shift`, `Explode`, `Flatten`, `IsEmpty`, `NullCount`, `ArgMin`, `ArgMax` on a list/array-typed series.

#### Scenario: Lengths on a list-typed series
- **WHEN** a caller constructs a list series `[[1,2],[3,4,5],[6]]`
- **THEN** `Arr.Lengths()` returns `[2, 3, 1]`

#### Scenario: Get returns the element at the given index
- **WHEN** a caller invokes `Arr.Get(1)` on a list-typed series whose first list is `[10,20,30]`
- **THEN** the result for row 0 is the value `20`

### Requirement: Series binary namespace
`Series.Bin` (a `SeriesBinNS`) MUST expose `Lengths`, `Concat`, `Contains`, `StartsWith`, `EndsWith`, `Decode(encoding)`, `Encode(encoding)`, `Hex`, `FromHex`, `Base64Encode`, `Base64Decode` on a binary-typed series.

#### Scenario: Hex and FromHex round-trip
- **WHEN** a caller invokes `Bin.Hex()` and then `Bin.FromHex()` on a binary series
- **THEN** the round-tripped values equal the original bytes

#### Scenario: Base64 round-trip
- **WHEN** a caller invokes `Bin.Base64Encode()` and then `Bin.Base64Decode()` on a binary series
- **THEN** the round-tripped values equal the original bytes

### Requirement: Series categorical namespace
`Series.Cat` (a `SeriesCatNS`) MUST expose `Categories`, `SetCategories`, `AppendCategories`, `RemoveCategories`, `IsIn`, `GetCategories`, `ToLocal`, `ToPhysical` on a categorical-typed series.

#### Scenario: Categories returns the documented category list
- **WHEN** a caller constructs a categorical series with categories `["a","b","c"]`
- **THEN** `Cat.Categories()` returns `["a","b","c"]`

#### Scenario: SetCategories with a strict order
- **WHEN** a caller invokes `Cat.SetCategories(["c","b","a"], true)` and reads `Categories()`
- **THEN** the result is the new order `["c","b","a"]`

### Requirement: Series struct namespace
`Series.Struct` (a `SeriesStructNS`) MUST expose `Fields`, `Field(name)`, `RenameFields`, `ToStruct`, `Unnest`, `JsonEncode`, `JsonDecode` on a struct-typed series.

#### Scenario: Fields lists the struct field names
- **WHEN** a caller constructs a struct series with fields `{"a":Int64,"b":String}`
- **THEN** `Struct.Fields()` returns the names `["a","b"]` in declaration order

#### Scenario: Field returns the sub-series
- **WHEN** a caller invokes `Struct.Field("a")` on a struct series
- **THEN** the result is a non-nil series whose `Name()` equals `"a"`
