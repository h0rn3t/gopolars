# polars-sql-context-api

## ADDED Requirements

### Requirement: SQLContext construction
`polars.NewSQLContext()` MUST return a non-nil `polars.SQLContext` and each call MUST return a fresh, independent context (a name registered in one context is not visible in another).

#### Scenario: NewSQLContext returns a non-nil context
- **WHEN** a caller invokes `polars.NewSQLContext()`
- **THEN** the returned value is a non-nil `polars.SQLContext`

#### Scenario: Two contexts are independent
- **WHEN** a caller registers `"t"` in context A and then lists tables in context B
- **THEN** context B's `Tables()` does not contain `"t"`

### Requirement: SQLContext registration
`Register(name, frame)`, `Unregister(name)`, `Tables()`, `Get(name)` MUST reflect the registered frames.

#### Scenario: Register adds the table name
- **WHEN** a caller registers a frame under `"t"` and then calls `Tables()`
- **THEN** the returned slice contains `"t"`

#### Scenario: Unregister removes the table name
- **WHEN** a caller registers `"t"`, then unregisters `"t"`, then calls `Tables()`
- **THEN** the returned slice does not contain `"t"`

#### Scenario: Get returns the registered frame
- **WHEN** a caller registers a frame under `"t"` and then calls `Get("t")`
- **THEN** the returned `DataFrame` has the same `Columns()` and `Height()` as the input

#### Scenario: Get of an unregistered name returns an error
- **WHEN** a caller calls `Get("missing")` on a context with no such table
- **THEN** the call returns a non-nil `error`

### Requirement: SQLContext execution
`Execute(query)` MUST return a `LazyFrame` whose `Collect()` result matches the documented SQL semantics for the supported subset (SELECT, FROM, WHERE, GROUP BY, ORDER BY, LIMIT, JOIN).

#### Scenario: Execute with a SELECT * FROM t
- **WHEN** a caller registers a frame under `"t"` and executes `"SELECT * FROM t"`
- **THEN** the collected result has the same `Columns()` and `Height()` as the registered frame

#### Scenario: Execute with a WHERE filter
- **WHEN** a caller executes `"SELECT a FROM t WHERE a > 0"`
- **THEN** every row in the collected result satisfies `a > 0`

#### Scenario: Execute with an unsupported construct returns an error
- **WHEN** a caller executes an SQL string that the parser cannot handle
- **THEN** the call returns a non-nil `error`
