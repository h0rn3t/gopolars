## Context

`pkg/polars` is the type-erasing public API that every external user of gopolars imports. It composes the already-tested lower layers (`pkg/frame` 77%, `pkg/series` 79%, `pkg/cache` 100%, `pkg/dtypes` 100%, `pkg/simd` 99.6%) behind four interfaces — `DataFrame`, `Series`, `LazyFrame`, `IO`, plus `SQLContext` and the small `Expr` constructor family — but currently ships at **1.5% statement coverage** with only `fill_test.go` (110 lines), `validity_test.go` (87 lines), and `filter_aggregate_direct_test.go` (201 lines) as test artifacts. The package totals 7,687 lines across 15 production files: `dataframe.go` 1,352, `series.go` 2,674, `lazyframe.go` 1,089, `series_low_priority.go` 648, `types.go` 515, `series_namespace.go` 223, `analytics.go` 214, `io.go` 161, `io_types.go` 110, `sqlcontext.go` 104, `expr.go` 57, `sql.go` 55, `python_interop.go` 47, `compatibility.go` 23.

Two prior changes (`close-polars-benchmark-gap`, `close-polars-time-gaps`) and one in-flight one (`close-polars-time-gaps`) refactored the lower layers while leaving this surface untested — every refactor was a bet that the wrappers still produce the documented types. The codecov config (`codecov.yml`) is informational and the unit flag points at `pkg/`, so a silent regression here goes unnoticed. Test runtime budget on the existing 5m `golangci-lint` runner is comfortable (today's `go test ./...` finishes in ~25s); the proposal's "under 30s" target on `pkg/polars` alone is therefore safe.

## Goals / Non-Goals

**Goals:**

- Every exported type, method, function, and constructor in `pkg/polars` is exercised by at least one table-driven test in a sibling `*_test.go`.
- **`pkg/polars` statement coverage ≥ 80%** measured by `go test -cover`, with the explicit allowances in the proposal (`series_low_priority.go`, `python_interop.go` 60%+ allowed).
- Each test asserts on the **publicly documented behavior** (return type, error vs panic, value parity), not on internal helpers — so the tests do not lock in current implementation choices and survive the next refactor.
- All tests run under `go test -race` with no flakes; total `pkg/polars` runtime ≤ 30s.
- No production code changes; no new module dependencies; no new public exports; no new env vars.

**Non-Goals:**

- Not refactoring `pkg/polars` for testability (e.g., not extracting interfaces just to mock them; not adding `pkg/polars/internal/...` packages).
- Not adding fuzz tests, benchmarks, or property-based tests in this change — focused coverage uplift only.
- Not promoting the existing 1.5% to 100% in `series_low_priority.go` / `python_interop.go` (they wrap external surfaces and are explicitly lower-priority in the proposal).
- Not touching `pkg/frame`, `pkg/series`, `pkg/cache`, `pkg/dtypes`, `pkg/simd`, `pkg/io/*`, `pkg/plan/*`, `pkg/sql` — out of scope for this change.
- Not changing the codecov config to enforce a gate (the proposal keeps it informational; this change strengthens the signal, the gate is a separate decision).
- Not adding tests for `examples/*` (excluded by `codecov.yml` ignore list; they are runnable programs, not API surface).

## Decisions

### D1. One test file per production file, plus a parity file

Mirror the production layout: `dataframe_test.go` next to `dataframe.go`, `series_test.go` next to `series.go`, `series_namespace_test.go` next to `series_namespace.go`, `series_low_priority_test.go` next to `series_low_priority.go`, `lazyframe_test.go` next to `lazyframe.go`, `io_test.go` next to `io.go`, `sqlcontext_test.go` next to `sqlcontext.go`, `expr_test.go` next to `expr.go`, `analytics_test.go` next to `analytics.go`, `python_interop_test.go` next to `python_interop.go`, `compatibility_test.go` next to `compatibility.go`. A single `parity_test.go` carries cross-cutting checks (e.g., `DataFrame` round-trips through every IO format; `Expr` from `pkg/polars/expr.go` produces a frame that equals a hand-built frame from `pkg/frame`). The three existing tests (`fill_test.go`, `validity_test.go`, `filter_aggregate_direct_test.go`) are **kept** and the cases that belong to the new surface are migrated into the per-file tests; the originals are left as-is when their content is already correct, to avoid churn.

**Why per-file:** Go's `go test` discovers by file; one file per production file keeps coverage attribution simple (`go test -coverprofile` shows per-file %; the reviewer can see at a glance which surface is under-tested). It also keeps diffs small in code review — a single 600-line `polars_test.go` would be un-reviewable. **Alternative rejected:** a single `polars_api_test.go` — same reason, plus harder to map failures to the API surface. **Alternative rejected:** keep tests inside the production file with `//go:build test` — Go's convention is to put tests in a sibling file; mixing them hurts tooling (coverage highlighting, IDE jump-to-test).

### D2. Table-driven tests, `testing` only, with `testify/require` if present

Each test is a single `func TestXxx(t *testing.T)` with a `tests := []struct{ name string; ... }{...}` slice and one `t.Run(name, func(t *testing.T) { ... })` per case. The repo's existing `pkg/series/*_test.go` uses `testify/require`; if a future migration is planned, this change should follow it. If `testify` is not in `go.mod` (the proposal says to avoid pulling a new module), fall back to `t.Errorf` / `t.Fatalf` with explicit message formatting. Each case carries: input (small in-memory frame, ≤ 32 rows), action (one method call), expected (return value, error, or panic-recovered). The cases are grouped by behavior class (happy / null / dtype-mismatch / boundary) so adding a case does not require re-reading the whole file.

**Why table-driven:** standard Go idiom; lets each case be run as a subtest (`go test -run TestDataFrame/Filter/null_input`); reads as a spec rather than as a procedure. **Why `testify/require`:** `require.NoError` / `require.Equal` produces a clean failure path and stops the case on first mismatch — appropriate for API contract tests. **Why fall back to stdlib:** the proposal's "no new dependencies" guardrail.

### D3. Build a small fixture frame once per test, mutate per case

A helper `newTestFrame(t *testing.T) DataFrame` (in each test file, local copy) builds a 4-column, ~8-row in-memory frame (Int64, Float64, String, Bool, plus a nullable Int64 column) using `NewDataFrame` and `NewSeries`. The helper is a regular function, not exported, and lives at the top of its test file. Where a test needs a different shape (e.g., a single-column frame for `Series` tests, a wider frame for `GroupBy`), a local helper is added next to the test that needs it. No `testdata/` binaries are committed; no temp files for the in-memory cases. IO round-trips use `t.TempDir()` per test (per Go convention since 1.15) so they parallelize cleanly.

**Why per-test-file helpers, not a shared `testutil` package:** the proposal explicitly avoids creating a new internal package; copying a 10-line helper to each file is cheaper than adding an `internal/testutil` for this change. **Why `t.TempDir()`:** automatic cleanup, parallel-safe, scoped to the test. **Alternative considered:** committing parquet/csv/ipc fixtures under `testdata/` — rejected, the proposal says no new committed binaries.

### D4. Mirror the spec's contract: assert on public types and documented errors

For each method, the test asserts the **type signature and value equality** that the public docs and the `pkg/polars/types.go` interface promise: the return is the documented type, the frame's `Height`/`Width`/`Columns` match the expected, and any error matches the expected sentinel (using `errors.Is` where the package defines one, `strings.Contains` on the message otherwise). Tests do **not** peek into unexported fields or call unexported helpers; this keeps the test stable across refactors. Where a method has no current way to surface a "wrong input" error (it panics instead), the test uses `defer recover()` to assert the panic message — and notes that in a comment so the next refactor is nudged to return an error.

**Why assert on type, not internals:** the whole point of the wrapper layer is that the implementation can be swapped (typed storage, parallel group-by, etc.). **Alternative rejected:** deep-struct equality on `DataFrame` — would couple tests to the concrete `frame.DataFrame` struct and break whenever the wrapper is swapped. **Why `errors.Is` first, message-match fallback:** some package errors are not yet sentinel-typed; the fallback catches the current behavior and a follow-up can promote them to sentinels.

### D5. `python_interop.go` coverage target relaxed; tested via the real `Py*` functions

The four `Py*` functions return `[][]any` / `[]any` / `iarrow.Table`. Testing them does not require Python — they take `DataFrame`/`Series` and produce the in-memory shape. The test builds a small frame, calls each function, and asserts on the returned Go values and the arrow table's schema and row count. The 60%+ target reflects that some defensive nil-checks and the `PyDataFrameInterchange` shim may have untestable branches (defensive code that never triggers on the supported inputs).

**Why testable in pure Go:** the functions are pure converters; the "Py" prefix is a historical name. **Why 60%+ not 80%:** some branches are intentional no-ops or unreachable guards; chasing 100% would require contrived inputs that the production code path would never see.

### D6. Coverage measurement: `go test -coverprofile` + per-file report

The CI script adds `go test ./pkg/polars/... -count=1 -coverprofile=$COV -covermode=count` (matching the existing `go test ./...` invocation in the repo) and the `codecov.yml` `unit` flag already covers `pkg/`. The 80% target is checked locally with `go tool cover -func=cover.out | grep "total:"` before commit; CI surfaces the per-file % in the existing codecov comment. No new CI step is required.

**Why per-file reporting:** surfaces which wrapper is under-tested in a single PR; complements the per-package aggregate.

## Risks / Trade-offs

- **Tests lock in current behavior, including bugs.** → D4: every test is written from the **public docs/interface signature**, not by reading the implementation first; the case asserts the documented contract. A test that fails because the current code is wrong is **not deleted** — it is filed as a follow-up.
- **Flaky tests from shared temp dirs / parallel IO.** → D3: `t.TempDir()` and unique filenames per test; CI already runs `go test -race` which catches data races in the tests themselves. Tests do not sleep or rely on wall-clock time.
- **`testify` not in `go.mod`.** → D2: fall back to stdlib `t.Errorf`/`t.Fatalf`. The repo's `go.sum` shows `testify` is **not** a direct dependency (only indirect via arrow), so the fallback is the default.
- **Coverage target misses on a few files (`series_low_priority.go`, `python_interop.go`).** → Proposal: explicit 60%+ allowance; the per-package aggregate still clears 80% because `dataframe.go`, `lazyframe.go`, `series.go` together account for ~5,100/7,687 LOC and reach 80%+.
- **Test runtime regression on `go test -race`.** → Each test is in-memory except IO round-trips, which are bounded to ≤ 8 rows and `t.TempDir()`; the 30s target leaves headroom for `-race`'s 2-5x overhead.
- **Refactor of `pkg/polars` later invalidates some tests.** → D1 (per-file), D4 (public-types-only), D2 (table-driven): all three decisions bias the tests toward contract assertions, so a refactor that preserves the public API passes the tests; a refactor that breaks the API is exactly what the tests should catch.
- **`go test ./pkg/polars/...` and the in-flight `close-polars-time-gaps` change both edit test files in the repo.** → The two changes touch disjoint directories (`pkg/polars` vs `pkg/frame`+`pkg/chunk`); merge order does not matter. If a future conflict appears, the tests here are pure additions and `git merge` handles it trivially.

## Migration Plan

This change is a single PR adding test files; no production code changes; no data migration; no user-visible API change.

1. Add the helper `newTestFrame` in each new test file (D3) and run a single test to verify it builds and the helper produces a usable frame.
2. Add tests file-by-file in the order of the proposal: `expr_test.go` (smallest, surfaces the pattern) → `compatibility_test.go` → `analytics_test.go` → `sqlcontext_test.go` → `io_test.go` → `lazyframe_test.go` → `series_low_priority_test.go` → `series_namespace_test.go` → `series_test.go` → `dataframe_test.go` → `python_interop_test.go` → `parity_test.go`. After each file, run `go test -race ./pkg/polars/... -cover` and confirm the package-level % rises monotonically.
3. Migrate the three existing test files (`fill_test.go`, `validity_test.go`, `filter_aggregate_direct_test.go`) into the new per-file layout only where a test case is **better located** in the new file (e.g., a fill case that should live in `dataframe_test.go` near the `FillNull` test). Cases that are already in the right file stay put.
4. Run `go test -race ./...` and `go vet ./...` and `golangci-lint run` to confirm the rest of the repo is unaffected.
5. Capture the final `pkg/polars` coverage number in the PR description; record the per-file %s.

**Rollback:** trivial — `git revert` of the PR removes only test files; the production code is unchanged. No user-facing impact either direction.

## Open Questions

- Whether to also seed a `pkg/polars/testdata/` of small round-trip fixtures (CSV, JSON, IPC, Parquet) so the IO tests can assert on exact byte parity instead of "row count and column names" — defer to first run; add only if a test is flaky.
- Whether to convert the existing `pkg/polars`-internal errors (currently `fmt.Errorf`) to exported sentinels (`ErrXxx`) so tests can use `errors.Is` cleanly — out of scope here; the fallback message-match is good enough and a sentinel-promotion is a separate change.
- Whether the per-file layout should be one `_test.go` per **public type** (so `sql_test.go` and `sqlcontext_test.go` both exist) or per **production file** (so `sqlcontext_test.go` carries both) — currently per production file (D1); switch to per public type only if the SQL surface splits into two production files.
