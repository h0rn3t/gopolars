## Why

The cross-language `filter+sum` benchmark (`bench/cross`, single 1M-row float64 column) loses to Python Polars on every path — Py ×1.8–×2.5 on the fused paths (`eager_direct`, `lazy`) and Py ×5.1 on naive `eager`. The fused paths exist precisely to be fast, yet the *best* Go path (`eager_direct`) still trails: 891 µs vs 484 µs (empty) and 2.60 ms vs 856 µs (half). The root cause is structural, not micro: every fused reduce makes **two scalar passes** over the value array — pass 1 (`CompareGTFloat64Bitmap`) builds a packed predicate bitmap (~125 KB alloc), pass 2 (`MaskedReduceFloat64`) walks the bitmap to accumulate. Polars does the same work in **one** vectorized pass with no intermediate mask. Halving the memory traffic and dropping the bitmap allocation for the dominant `col <cmp> lit` predicate is the single highest-leverage win available without writing architecture-specific assembly.

## What Changes

- **Single-pass fused filter→reduce kernels** for the hot `col <cmp> lit` shape over a float64 column: `ReduceWhere*Float64` that scan the value array once, accumulating sum/min/max/count for rows passing the comparison **without materializing a bitmap or a second pass**. Branchless, multiple-accumulator form (same ILP/auto-vectorization shape as the existing `SumFloat64`), with a scalar/null-aware tail. Covers `gt/ge/lt/le/eq/ne`.
- **Fast-path routing in the fused reduce**: when the compiled predicate is a single-column `col <cmp> lit` comparison against a float64 column with no other operands, `FilterAggregateDirect` and the lazy `Filter().<reduce>().Collect()` path dispatch to the single-pass kernel instead of `EvalBool` (bitmap) + `MaskedReduceFloat64`. Any unsupported predicate (multi-column, AND/OR, casts, non-float64) falls back to the existing bitmap path unchanged.
- **No bitmap allocation on the fast path**: the fast path allocates only the result map — not the ~125 KB predicate bitmap — restoring the "near-zero allocation" intent of the fused entry point.
- **Benchmark + parity coverage**: re-run `bench/cross` filter+sum, record the new deltas, and add an equality/allocation test pinning the single-pass result to the existing bitmap path (byte-identical within reduction-order tolerance).

Out of scope (deferred, noted in design): arm64 NEON assembly for the scan, and the naive `eager` path's materialization cost (covered by the separate `parallel-row-materialization` work).

## Capabilities

### New Capabilities

- `fused-filter-reduce-single-pass`: A kernel family that reduces a float64 column over the rows passing a `col <cmp> lit` predicate in a single pass over the values, allocating no predicate bitmap and producing results identical (within float reduction-order tolerance) to the bitmap-driven `EvalBool` + `MaskedReduceFloat64` path.

### Modified Capabilities

- `eager-filter-aggregate-fusion`: `FilterAggregateDirect` (and the shared fused-reduce path behind the lazy reduce) SHALL route the single-column `col <cmp> lit` float64 case through the single-pass kernel, allocating only the result map — not the predicate bitmap — while keeping results and null/NaN semantics identical to the bitmap path. Predicates outside the fast-path shape fall back to the existing bitmap path.

## Impact

- **Code**: new kernels in `pkg/simd` (`kernels.go` + generic/amd64 variants as applicable); fast-path dispatch in `pkg/frame/typed.go` (`fusedReduce`); a small predicate-shape detector reading the compiled `evalbatch.Plan` (or the `expr.Expr` predicate directly).
- **APIs**: no public API change. `DataFrame.FilterAggregateDirect`, `Lazy().Filter().Sum().Collect()`, and `Series.Sum()` signatures and results are unchanged.
- **Benchmarks/tests**: `bench/cross/filter_sum_summary.json` re-baselined; new equality + allocation tests under `pkg/simd` and `pkg/frame`.
- **Dependencies**: none added.
