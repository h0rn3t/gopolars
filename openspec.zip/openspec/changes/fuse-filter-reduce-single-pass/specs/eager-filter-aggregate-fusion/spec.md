## MODIFIED Requirements

### Requirement: Eager API exposes direct filter-aggregate fusion

The `DataFrame` type SHALL expose a `FilterAggregateDirect(pred Expr, op string, cols []string) (map[string]float64, error)` method that evaluates the predicate, computes the requested aggregation (`sum`, `min`, `max`, `mean`, `count`) in a single masked pass, and returns results without constructing a lazy plan or materializing a filtered DataFrame. When the predicate is a single-column `col <cmp> lit` comparison over a float64 column and the aggregated column set is that same column, the implementation SHALL dispatch to the single-pass filter-reduce kernel (no predicate bitmap); all other predicate shapes SHALL use the bitmap (`EvalBool` + `MaskedReduceFloat64`) path. Both paths SHALL produce identical results.

#### Scenario: FilterAggregateDirect sum matches lazy fused result

- **WHEN** `df.FilterAggregateDirect(pred, "sum", []string{"a"})` is called on a DataFrame with a supported float64 column
- **THEN** the returned value for `"a"` SHALL equal the value returned by `df.Lazy().Filter(pred).Sum().Collect(ctx)` for the same predicate

#### Scenario: Single-pass fast path allocates only the result map

- **WHEN** `FilterAggregateDirect` is called on a 1M-row DataFrame at 50% selectivity with a `col <cmp> lit` predicate over the aggregated float64 column
- **THEN** the call SHALL allocate no `DataFrame`, no `[]int` survivor index slice, no sliced column buffer, and no predicate `Bitmap` — only the result map

#### Scenario: Non-fast-path predicate falls back to the bitmap path

- **WHEN** the predicate is not a single-column `col <cmp> lit` float64 comparison (e.g. multi-column, `AND`/`OR`, or a cast)
- **THEN** `FilterAggregateDirect` SHALL evaluate it via `EvalBool` into a `Bitmap` and reduce with `MaskedReduceFloat64`
- **AND** the result SHALL be identical to what the single-pass path would return for an equivalent predicate

#### Scenario: FilterAggregateDirect handles empty result

- **WHEN** the predicate matches zero rows
- **THEN** the method SHALL return a map with the aggregation key set to 0 and count 0

### Requirement: Selectivity gate skips reduction for empty filters

On the bitmap (fallback) path, before invoking `MaskedReduceFloat64`, the eager fusion path SHALL compute the bitmap popcount and return zero/null aggregates immediately when survivor count is zero. On the single-pass fast path no bitmap is built, so an empty result emerges directly from the single scan (count 0, sum `0.0`) without a separate popcount step.

#### Scenario: Zero survivors skips kernel on the bitmap path

- **WHEN** the predicate bitmap has popcount 0
- **THEN** `MaskedReduceFloat64` SHALL NOT be called
- **AND** the returned aggregate SHALL be the appropriate zero/null sentinel for the requested operation

#### Scenario: Non-zero survivors always invokes kernel on the bitmap path

- **WHEN** the predicate bitmap has popcount > 0
- **THEN** `MaskedReduceFloat64` SHALL be called with the full bitmap and value slice

#### Scenario: Single-pass empty result needs no popcount

- **WHEN** the single-pass fast path runs a `col <cmp> lit` predicate that no row passes
- **THEN** the method SHALL return count 0 and sum `0.0` from the single scan without computing a bitmap popcount

### Requirement: Eager fusion preserves null and NaN semantics

`FilterAggregateDirect` SHALL produce results with identical null/NaN handling as the lazy fused path and the existing eager materialize-then-reduce path, on both the single-pass fast path and the bitmap fallback path.

#### Scenario: Null rows excluded from sum

- **WHEN** a column has null values at rows that pass the predicate
- **THEN** those rows SHALL be excluded from the sum and count, matching the behavior of `Series.Sum()` on a materialized filtered column

#### Scenario: NaN propagation in min/max

- **WHEN** the first surviving row's value is NaN
- **THEN** min and max SHALL return NaN (sticky-from-seed), matching existing `MaskedReduceFloat64` semantics

#### Scenario: Fast path and bitmap path agree on null/NaN

- **WHEN** the same predicate and column (containing nulls and NaN) are reduced through both the single-pass fast path and the bitmap fallback path
- **THEN** the sum, min, max, mean, and count SHALL be identical (sum within reduction-order tolerance)
