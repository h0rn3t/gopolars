## ADDED Requirements

### Requirement: Single-pass filter-reduce kernel for `col <cmp> lit` over float64

The `pkg/simd` package SHALL provide a kernel family that reduces a `[]float64` over the rows passing a `vals[i] <cmp> lit` comparison in a **single pass** over the values, returning `(sum, min, max float64, count int)`, without allocating or consuming a predicate `Bitmap`. The family SHALL cover the comparisons `gt`, `ge`, `lt`, `le`, `eq`, `ne`.

#### Scenario: Result matches the bitmap-driven path

- **WHEN** the single-pass kernel reduces a 1M-row float64 column at 50% selectivity for `col > lit`
- **THEN** the returned sum SHALL equal the value produced by `CompareGTFloat64Bitmap` + `MaskedReduceFloat64` for the same inputs, within float64 reduction-order tolerance
- **AND** the returned min, max, and count SHALL be exactly equal

#### Scenario: One pass, no bitmap allocation

- **WHEN** the single-pass kernel is invoked on a null-free float64 column
- **THEN** it SHALL NOT allocate a `simd.Bitmap` or any per-row mask buffer
- **AND** it SHALL read the value array exactly once

#### Scenario: All six comparisons supported

- **WHEN** the kernel is invoked with each of `gt`, `ge`, `lt`, `le`, `eq`, `ne` against a literal
- **THEN** the contributing rows SHALL be exactly those `i` for which `vals[i] <cmp> lit` holds

#### Scenario: Non-passing NaN/Inf rows do not poison the sum

- **WHEN** the column contains `NaN` and `±Inf` values at rows that do NOT pass the comparison
- **THEN** those rows SHALL contribute exactly `0.0` to the sum (via bit-mask select, not multiply-by-mask)
- **AND** the returned sum SHALL be finite and equal to the sum over only the passing rows

#### Scenario: min/max preserve seeded NaN semantics

- **WHEN** the first contributing (passing, non-null) row's value is `NaN`
- **THEN** min and max SHALL both be `NaN` (sticky-from-seed), identical to `MaskedReduceFloat64`

#### Scenario: Null rows excluded

- **WHEN** a `nulls` slice is supplied and `nulls[i]` is true for a row that passes the comparison
- **THEN** row `i` SHALL be excluded from sum, min, max, and count

#### Scenario: Empty selectivity yields a clean zero result

- **WHEN** no row passes the comparison
- **THEN** count SHALL be 0 and sum SHALL be `0.0` (never `NaN`), and callers SHALL treat min/max as empty
