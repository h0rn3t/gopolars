## 1. Single-pass kernels (pkg/simd)

- [x] 1.1 Add `ReduceWhereFloat64(vals []float64, cmp Cmp, lit float64, nulls []bool) (sum, min, max float64, count int)` (or one fn per comparison) covering `gt/ge/lt/le/eq/ne`, scanning `vals` once with no `Bitmap`. *(Shipped as a family: `SumWhereFloat64` + `MinMaxWhereFloat64`, `Cmp` enum covers all six.)*
- [x] 1.2 Implement the sum path branchlessly via bit-mask select (`Float64frombits(bits & -mask)`), 8 independent accumulators + scalar tail (mirror `SumFloat64`'s shape) — verify no `0*NaN` poisoning.
- [x] 1.3 Implement min/max via the same seeded-on-first-contributing-row logic as `MaskedReduceFloat64` (NaN sticky-from-seed), riding the same load; `count` = passing rows.
- [x] 1.4 Add a null-aware variant/branch: when `nulls != nil`, exclude `nulls[i]` rows; keep it a single pass.
- [x] 1.5 Unit test: `ReduceWhere*` equals `CompareGTFloat64Bitmap`+`MaskedReduceFloat64` over randomized data at 0%/50%/100% selectivity (sum within reduction-order tolerance; min/max/count exact).
- [x] 1.6 Unit test: NaN/±Inf among non-passing rows → finite sum equal to passing-only sum; empty selectivity → count 0, sum 0.0 (not NaN).
- [x] 1.7 Allocation test: `testing.AllocsPerRun` over `ReduceWhere*` on a null-free column allocates 0 (no bitmap).

## 2. Predicate shape detection (pkg/expr/evalbatch)

- [x] 2.1 Add `Plan.AsColCmpLit() (col, cmp string, litF float64, ok bool)` returning the tuple only when `root` is a single `col <cmp> lit` comparison over a float64 column with a numeric literal. *(Returns `simd.Cmp`; reports ok for gt/ge/lt/le — eq/ne fall back to the bitmap path to preserve their special NaN handling.)*
- [x] 2.2 Unit test the accessor: positive for the four comparisons + int literal; negative for col-vs-col, lit-on-left, and bare-column predicates.

## 3. Wire the fast path (pkg/frame/typed.go)

- [x] 3.1 In `FilterAggregate`/`FilterAggregateDirect`, try `fusedReduceFast` (which calls `plan.AsColCmpLit()`) before `EvalBool`; take the single-pass path only when `ok` and the aggregated `names` is exactly that one column. Otherwise keep the existing bitmap path unchanged.
- [x] 3.2 Map the kernel's `(sum,count)` / `(min,max,count)` into `colReduction` and on to `directResult`/`fusedResult` for `sum/min/max/mean/count` — unchanged downstream.
- [x] 3.3 Apply the same single-pass kernel per worker range in `reduceWhere` above `parallelFilterThreshold`; merge partials with `colReduction.merge`.

## 4. Equivalence & regression tests (pkg/frame, pkg/polars)

- [x] 4.1 Test `FilterAggregateDirect` fast path vs hand-computed reference agree on sum/min/max/mean/count for gt/ge/lt/le with nulls and NaN present (`TestFilterAggregateDirectComparisonsMatchReference`).
- [x] 4.2 Existing `FilterAggregateDirect == Lazy().Filter().<reduce>().Collect()` tests still pass (now both run the fast path).
- [x] 4.3 Allocation test: `FilterAggregateDirect` on 1M at 50% selectivity allocates no predicate bitmap (existing `TestFilterAggregateDirectAllocations` ≤ 8 still passes; B/op fell 130 KB → 3.3 KB).
- [x] 4.4 Full suite green: `go test ./...` (generic build) exits 0, 0 FAIL. *(GOEXPERIMENT=simd is amd64-only; host is arm64, so the generic build is authoritative here.)*

## 5. Benchmark & re-baseline

- [x] 5.1 Re-ran `bench/cross` filter+sum at 1M; captured new Go time / B/op / allocs for `eager_direct` and `lazy` on empty + half.
- [x] 5.2 Result: `eager_direct` 891 µs→160 µs (empty), 2.60 ms→161 µs (half); `lazy` 1.01 ms→159 µs / 2.60 ms→161 µs. B/op 130–135 KB→3.3–8.4 KB (predicate bitmap eliminated). Both fused paths now beat the Python baseline (empty ~400–484 µs, half ~856–980 µs) by 2.5–6×, at ~50 GB/s (memory-bandwidth-bound). `half` == `empty` (branchless, selectivity-independent).
- [x] 5.3 arm64 NEON go/no-go: **NO**. The single-pass kernel is already memory-bandwidth-bound (~50 GB/s at 1M); a NEON scan cannot beat the DRAM ceiling, so the assembly/maintenance cost is not warranted. The naive `eager` materialize path remains the only slow row and is out of scope (separate `parallel-row-materialization` work).

## 6. Validate

- [x] 6.1 `openspec validate fuse-filter-reduce-single-pass --strict` passes.
