## Context

The fused filter→reduce paths (`DataFrame.FilterAggregateDirect` and the lazy `Lazy().Filter().<reduce>().Collect()`) both funnel through `pkg/frame/typed.go:fusedReduce`, which does two scalar passes over the value array:

1. `evalbatch.Plan.EvalBool` → `CompareGTFloat64Bitmap` (or sibling) — **pass 1**: builds a packed `simd.Bitmap` (~`height/8` bytes; ~125 KB at 1M).
2. `simd.MaskedReduceFloat64(vals, mask, nulls)` — **pass 2**: word-walks the bitmap, accumulating sum/min/max/count.

This is correct and already past `[]any` boxing, but it reads the 8 MB value array twice and allocates the bitmap on every call. Python Polars does the same `df.filter(col > t)["a"].sum()` in one vectorized (NEON on arm64) pass. The measured gap on `bench/cross` filter+sum (1M float64, single column) is Py ×1.8 (empty) to Py ×3.0 (half) even on the best Go path. On this arm64 host there is additionally no NEON kernel at all — `simd_amd64.go` requires `amd64 && simd`, so everything falls to scalar `simd_generic.go`.

Constraint: results must stay identical to the existing bitmap path within the float64 reduction-order tolerance already accepted by the `simd-column-kernels` spec, and null/NaN semantics must match `MaskedReduceFloat64` exactly. No public API change.

## Goals / Non-Goals

**Goals:**

- Collapse the fused reduce to **one pass** over the values for the dominant `col <cmp> lit` (single float64 column) predicate, with **no predicate-bitmap allocation**.
- Cover `gt/ge/lt/le/eq/ne` and the `sum/min/max/mean/count` reductions.
- Keep results and null/NaN semantics byte-identical (within reduction-order tolerance) to the bitmap path; everything outside the fast-path shape falls back unchanged.
- Preserve the existing parallel split (`fusedReduceParallel`) — the new kernel slots in per worker-window.

**Non-Goals:**

- arm64 NEON / hand-written assembly for the scan (deferred — same go/no-go discipline as `rowop-simd-gap-assessment`; revisit if pure-Go single-pass still trails after measurement).
- The naive `eager` path (`df.Filter(pred)` then `Series.Sum()`) and its materialization cost — that's the separate `parallel-row-materialization` work; the fused paths are the parity targets here.
- General multi-column / AND-OR / cast predicates — these keep the bitmap path.

## Decisions

### 1. Single pass, no bitmap — for the `col <cmp> lit` shape only

Add a kernel family `ReduceWhere<Cmp>Float64(vals []float64, lit float64, nulls []bool) (sum, min, max float64, count int)` in `pkg/simd` that scans `vals` once, accumulating only rows where `vals[i] <cmp> lit`. No `Bitmap` is built.

*Alternative considered:* keep two passes but compute an inline `[]bool` instead of a `Bitmap` — still two passes and an N-byte alloc. Rejected. *Alternative:* fuse an arbitrary predicate by streaming the batch evaluator — high complexity for the long tail; rejected (YAGNI). General predicates keep the existing bitmap path.

### 2. Sum via bit-mask select, NOT multiply-by-mask (correctness)

A non-passing row may hold `NaN`/`±Inf` (it simply fails `> t`). `sum += v * b2f(pass)` would compute `0 * NaN = NaN` and poison the accumulator. Instead select branchlessly through the float bit pattern:

```
maskBits := -uint64(b2u(vals[i] <cmp> lit))      // all-ones if pass, else 0
sum += math.Float64frombits(math.Float64bits(vals[i]) & maskBits)  // exact 0.0 for non-pass
```

This yields a true `0.0` (never `NaN`) for non-passing rows, so the sum is exact. Use 8 independent accumulators over an unrolled loop (same ILP shape as `SumFloat64`) so a superscalar core / auto-vectorizer keeps several FADDs in flight, with a scalar tail.

### 3. min/max via seeded compare in the same pass (semantics-preserving)

Branchless min/max with `±Inf` sentinels would use plain `<`/`>` and make `NaN` lose every comparison — changing the existing **NaN sticky-from-seed** semantics of `MaskedReduceFloat64`. To stay identical, min/max are computed with the same seeded-on-first-contributing-row logic as today, inside the single pass (a per-row branch, but no extra memory traffic and no bitmap). Sum/count remain branchless; min/max ride along on the same load. `mean = sum/count`; `count` is just the passing count.

### 4. Shape detection reads the compiled plan

Add an accessor on `evalbatch.Plan` (e.g. `AsColCmpLit() (col string, cmp string, litF float64, ok bool)`) that returns the fast-path tuple when `root` is a single `col <cmp> lit` comparison whose column is float64 and whose literal is numeric; `ok=false` otherwise. `fusedReduce` calls it first and takes the fast path only when the predicate column equals the single aggregated column (the benchmark case). Multi-column aggregation (each column needs the predicate mask) falls back to the bitmap path — not the hot path.

*Alternative:* inspect `expr.Expr` directly in `pkg/frame`. Rejected — `fusedReduce` already holds the compiled `*evalbatch.Plan`; the accessor keeps predicate-shape knowledge in the package that owns predicates.

### 5. Parallelism unchanged

Above `parallelFilterThreshold` (32768), `fusedReduceParallel` partitions rows and merges partials. The single-pass kernel replaces the per-window `EvalBool`+`MaskedReduceFloat64` with one `ReduceWhere*` call per window; merge logic (sum add, min/max combine, count add) is unchanged.

## Risks / Trade-offs

- **min/max branch in the hot loop** → mitigated: it shares the single load with the branchless sum; still one pass, no bitmap. The benchmark target (sum) stays fully branchless.
- **Auto-vectorization not guaranteed on arm64** → even if the bit-mask-select loop stays scalar, it is single-pass and memory-bound, which already beats the two-pass bitmap path. NEON is the deferred follow-up if measurement shows a residual gap.
- **0×NaN poisoning** → mitigated by bit-mask select (Decision 2); covered by a dedicated equality scenario with NaN/Inf among non-passing rows.
- **Semantic drift in min/max NaN handling** → mitigated by reusing the exact seeded-compare logic (Decision 3) and an equality test against `MaskedReduceFloat64`.
- **Fast-path shape too narrow** → acceptable: `col <cmp> lit` over one float64 column is exactly the benchmarked and most common reduce predicate; anything else falls back with identical results.

## Migration Plan

Purely additive fast path with a fallback. Land kernels + equality/allocation tests first (fast path provable in isolation), then wire the `fusedReduce` dispatch. Rollback = delete the dispatch branch; the bitmap path is untouched. Re-baseline `bench/cross/filter_sum_summary.json` after landing.

## Open Questions

- Should `count`-only reductions short-circuit to a branchless count (no value loads beyond the compare)? Minor; decide during implementation from the benchmark.
- Does the single-pass kernel close enough of the gap that arm64 NEON stays deferred? Resolved by the post-implementation `bench/cross` re-run.
