## Context

After `close-polars-benchmark-gap`, gopolars' affected operations are allocation-minimal: the per-row `interface{}` boxing is gone and outputs are written into typed buffers. A fresh `bench/top30` run (Apple M4 Pro, arm64, Go 1.26, Python Polars 1.41.2; 1M rows) shows the residual gaps are now **algorithmic / single-threaded**, not allocation:

| op | Go 1M | Py 1M | gap | allocs/op (already) |
|----|-------|-------|-----|---------------------|
| `rank` | 339 ms | 14.3 ms | Py ×24 | 13 |
| `group_by` | 18.0 ms | 1.62 ms | Py ×11 | 21 |
| `sort` | 39.4 ms | 12.0 ms | Py ×3.3 | 22 |

The same binding constraint as before applies: the bench machine is **arm64**, where Go 1.26 `simd/archsimd` is amd64-only, so every win must come from portable Go — better algorithmic complexity and goroutine parallelism, not vectorization. The building blocks already exist: `chunk.ArgsortFloat64`/`ArgsortInt64` (O(n) radix), `chunk.GroupIDs` (typed group keys), `frame.radixArgsort` (single-key radix sort fast path), and `parallelForRows` (the established row-count parallelism gate).

## Goals / Non-Goals

**Goals:**

- `rank` runs in O(n) for null-free numeric columns by reusing the radix argsort, with **identical ordinal rank values** to the current `sort.SliceStable` path.
- `group_by` grouping + aggregation scales across `NumCPU` for large frames, with **identical group membership and aggregate values** to the sequential typed path.
- Numeric-key `sort` sorts disjoint ranges in parallel and merges, with **identical order, stability, and NaN/null placement**; the leading numeric key of a multi-key sort uses the radix path with comparator tie-breaks.
- Every fast path is additive and gated; the sequential path is preserved for small inputs, nullable/NaN/non-numeric columns, and arbitrary comparators.

**Non-Goals:**

- No SIMD / hand-written assembly (amd64-only / not portable to the bench machine).
- No public API signature changes.
- Not changing rank tie semantics (gopolars currently assigns a strict ordinal rank, 1..n, via a stable sort — that exact behavior is preserved, not switched to dense/average rank).
- Not parallelizing every op — only the three measured time gaps; other ops stay as shipped.
- Not promising full parity on `rank`/`group_by` (Python's Rust core is multi-threaded SIMD); the goal is a large, safe portable-Go reduction, measured and reassessed.

## Decisions

### D1. Radix ordinal rank (R-rank)

`evalRank` currently builds `indexes := [0..n)`, `sort.SliceStable(indexes, compareAny-or-typed-less)`, then writes `out[indexes[r]] = r+1`. The permutation is the only thing that matters; the ordinal rank is just the inverse permutation. Replace the sort with the existing radix argsort for the null-free numeric fast path:

```
idx := chunk.ArgsortFloat64(f64s)   // or ArgsortInt64; already stable LSD radix
out := make([]int64, n)
for r, i := range idx { out[i] = int64(r + 1) }
return series.FromInt64(name, out, nil)
```

**Why identical:** the current fast path already uses `sort.SliceStable` with a strict `<` comparator, so equal keys keep input order; `chunk.ArgsortFloat64` is a **stable** LSD radix, so it yields the same permutation (hence the same ordinal ranks) for equal keys. Gate exactly as `frame.radixArgsort` does today: single column, `NullCount()==0`, no NaN (scan), Float64/Int64; otherwise fall back to `sort.SliceStable`. The same swap applies to the `rank`-within-`over` branch (per-partition: radix-argsort each bucket's values). **Alternative rejected:** writing a bespoke counting-rank — unnecessary, the radix argsort is already written, tested, and stable.

### D2. Parallel typed group-by (R-group)

The sequential path is `GroupIDs(keyCols) → buckets [][]int → per-group evalAgg`. Parallelize in two stages, gated on `height` via the existing `parallelForRows` threshold:

1. **Shard-local grouping.** Split `[0,n)` into `NumCPU` contiguous ranges. Each worker scans its range and builds a *shard-local* typed group table (the same dtype-switched typed map as `GroupIDs`: `map[int64]localGid` / `map[string]localGid` / `map[uint64]localGid` with the canonical-NaN/-0 handling), recording, per local group, the first-seen global row index and a typed running aggregate accumulator (sum/count/min/max) so reduction happens **during** the scan — no per-group index lists are materialized.
2. **Merge.** Combine shard tables into a global table keyed the same way. Group identity across shards uses the same typed key; merging two partial aggregates is associative (sum+sum, min/min, count+count, etc.). Global group order is deterministic: order groups by the **minimum first-seen row index** across shards (matching the sequential encounter order), so output rows are reproducible.

For aggregates that cannot be expressed as an associative running reduce over the typed column (e.g. `n_unique`, or a non-`KindCol` expression target), fall back to the sequential `buckets → evalAgg` path for that aggregate. Key columns for the output are still produced by a typed `Gather` of the per-group representative rows.

**Why during-scan reduction (not parallel bucket lists):** materializing `[][]int` buckets in parallel then reducing is two passes and re-introduces O(rows) index storage; folding the aggregate into the shard table is one pass and bounds memory to O(groups·shards). **Why deterministic min-first-seen order:** the sequential path emits groups in first-encounter order; preserving it keeps outputs byte-stable and tests order-insensitive-free. **Alternative considered:** a single shared concurrent map with a mutex — rejected (lock contention dominates at 100s of groups); shard-local + merge is lock-free per worker.

### D3. Parallel merge sort for numeric keys (R-sort)

The current `radixArgsort` fast path is a single sequential LSD radix. Above a (larger) length threshold, parallelize:

1. Split `[0,n)` into `NumCPU` contiguous ranges; radix-argsort each range **in parallel** into its own index run (each worker writes a disjoint output slice — no shared state, race-free).
2. **Merge** the sorted runs by comparing the *key value* at each run's head (`keys[idx]`), pairwise or k-way. The merge is stable when, on equal keys, it always takes from the **earliest** run first and preserves within-run order — which reproduces the global stable order.

Extend the radix path to **multi-key** sorts: radix-argsort by the leading numeric key, then resolve ties using the existing `buildColumnComparators` on the remaining keys (stable). The leading-key gate stays numeric/null-free/no-NaN; otherwise the whole sort falls back to the comparator `sort.Slice` path.

**Why merge over a single big radix:** radix is already memory-bandwidth-bound single-threaded, so the win comes from using multiple cores on disjoint ranges; the merge is O(n) and cache-friendly. **Trade-off:** the merge adds an O(n) buffer and pass; net win only above the threshold — tuned empirically. **Alternative rejected:** parallel partition-by-radix-digit (MSD) — more complex, harder to keep stable, and the range-split+merge reuses the existing tested LSD kernel unchanged.

### D4. Parallelism thresholds and false-sharing

All three parallel paths reuse the established row-count gate (the `parallelForRows` / `Filter` threshold); below it they run sequentially (scheduler overhead dominates small inputs). Each worker writes a **disjoint contiguous output range** (sort runs, shard tables) so there is no write sharing; merges read shard outputs and write a fresh buffer. Worker count = `runtime.GOMAXPROCS(0)`, clamped to the row count. This mirrors the existing `Filter`/rolling parallelism discipline.

## Risks / Trade-offs

- **Parallel group-table merge correctness (D2)** → keep the typed-key encoding identical to `GroupIDs` (same canonical NaN / -0 handling) so a key hashes the same in every shard; merge is associative per aggregate; deterministic min-first-seen ordering. Mitigation: parity test asserting equal group keys + aggregates vs the sequential path on int/float/string keys with nulls, plus `-race`.
- **Parallel sort stability across run boundaries (D3)** → the merge must, on ties, drain the earliest run first; unit test that a stable reference (`sort.SliceStable`) and the parallel merge produce identical permutations on data with many duplicate keys.
- **Rank parity on equal keys (D1)** → the radix argsort is stable and the current path is `SliceStable`, so ordinal ranks match; parity test compares typed-vs-radix and radix-vs-rowwise on duplicate-heavy input.
- **Gains may be sublinear in cores** → memory bandwidth caps radix/merge speedup; set expectations (≈ cores× only up to bandwidth). Each path is independently benchmarked and gated, so a path that doesn't pay off can keep its threshold high (effectively off) without affecting the others.
- **Threshold mistuning** → too-low thresholds regress small inputs. Mitigation: gate on the existing measured threshold and benchmark 1K (must not regress) alongside 1M.

## Migration Plan

Phased, each phase independently shippable and benchmarked:

1. **R-rank** (lowest risk, reuses tested radix): swap `evalRank` + `evalOver` rank branch; parity + benchmark.
2. **R-group**: parallel shard tables + merge for the associative-aggregate fast path; parity (incl. nulls, multi-key) + `-race` + benchmark.
3. **R-sort**: parallel merge + multi-key leading-radix; stability/NaN parity + benchmark.
4. Re-run `bench/top30`; update the committed summary + README; confirm allocation counts did not regress.

**Rollback:** each path is gated by a length threshold and dtype/null/NaN guards; setting a threshold to `MaxInt` (or reverting a single dispatch) disables that path while leaving the others and the sequential fallback intact. `GOPOLARS_TYPED_STORAGE=0` continues to force the row-wise path for the batch-eval ops.

## Open Questions

- Exact per-op parallelism thresholds (rank/group/sort) — tune empirically against the bench suite rather than fixing in the spec.
- Whether `group_by` should fall back to sequential when the estimated group count is very high (merge cost approaches grouping cost) — decide after measuring.
- Whether to also radix-rank the string fast path (lexicographic radix) — deferred; numeric is the measured hot case.
