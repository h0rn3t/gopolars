## Why

The `close-polars-benchmark-gap` change eliminated per-row `interface{}` boxing on ~20 operations, collapsing allocation counts by 3–6 orders of magnitude (e.g. `group_by` 1M: 1,000,171 → 21 allocs; `rank` 1M: 999,762 → 13). But a freshly captured `bench/top30` run shows three operations where **wall-clock time** still loses to Python Polars at 1M rows even though allocations are already minimal — the remaining cost is algorithmic, not allocation: `rank` (Py ×24, an O(n·log n) `sort.SliceStable` argsort), `group_by` (Py ×11, single-threaded bucketing + aggregation), and `sort` (Py ×3.3, a sequential radix pass). Closing these directly advances the tracked "Performance parity on all workloads" goal now that the allocation work has landed.

## What Changes

- **Radix ordinal `rank`:** replace the comparison-based `sort.SliceStable` argsort in `evalRank` (and the per-partition rank in `evalOver`) with the existing O(n) `chunk.ArgsortFloat64` / `ArgsortInt64` radix kernels for null-free numeric columns, producing the same ordinal ranks. (`rank` 1M Py ×24.)
- **Parallel typed `group_by`:** parallelize grouping and aggregation across `NumCPU` — partition rows into contiguous shards, build per-shard typed group tables (reusing the `chunk.GroupIDs` typed-key machinery), then merge shard tables and reduce per group — instead of the current single-threaded `GroupIDs` + bucket loop. Gated on row count. (`group_by` 1M Py ×11.)
- **Parallel merge numeric `sort`:** add a parallel merge across `NumCPU` on top of the existing radix argsort — sort disjoint row ranges in parallel, then k-way/pairwise merge the sorted index runs — for large single-key numeric sorts, and extend the radix fast path to the leading numeric key of a multi-key sort (tie-break the remaining keys with the existing comparators). (`sort` 1M Py ×3.3.)
- All changes are **additive fast paths** gated on length thresholds; below the gate (and for unsupported dtypes / nullable / NaN / arbitrary-comparator inputs) the existing sequential path is preserved unchanged. Observable results — ordinal rank values, group membership/aggregates, and sort order/stability/NaN placement — are identical, each covered by a parity test against the current implementation.

## Capabilities

### New Capabilities

- `radix-rank`: `rank` (standalone and within `over`) computes ordinal ranks via an O(n) radix argsort over the typed backing slice for null-free numeric columns, with identical rank values to the comparison-sort path.
- `parallel-group-aggregation`: `group_by(...).agg(...)` builds groups and reduces aggregates concurrently across `NumCPU` for large frames, producing identical group membership and aggregate values to the sequential typed path.
- `parallel-merge-sort`: numeric-key sorts above a length threshold sort disjoint row ranges in parallel and merge the sorted runs, preserving the existing total order, stability guarantee, and NaN/null placement; the leading numeric key of a multi-key sort uses the radix path with comparator tie-breaks.

### Modified Capabilities

<!-- None: the prior change's delta specs (typed-group-aggregation, parallel-numeric-sort, vectorized-expr-kernels) are not yet archived into openspec/specs/, so this change introduces new, narrowly-scoped capabilities rather than amending unsynced deltas. The new capabilities layer parallelism/algorithmic improvements on top of the typed foundations already shipped. -->

## Impact

- **Code:** `pkg/frame/frame.go` (`evalRank`, `evalOver` rank branch, `Sort` / `radixArgsort`), `pkg/frame/groupby.go` (`GroupBy.Agg` parallel path), `pkg/chunk/radix.go` (parallel merge helper) and possibly `pkg/chunk/group.go`-style shard-merge helpers. Reuses `chunk.ArgsortFloat64`/`ArgsortInt64`, `chunk.GroupIDs`, and the existing `parallelForRows` threshold.
- **APIs:** no public signature changes; behavior preserved (ordinal rank, group results, sort order/stability/NaN).
- **Benchmarks:** `bench/top30` (`rank`, `group_by`, `sort`) — before/after wall-clock captured with `-benchmem`; allocation counts must not regress.
- **Dependencies:** portable Go only — goroutine parallelism and radix, no SIMD/assembly (the bench machine is arm64, where Go 1.26 `simd/archsimd` is amd64-only).
- **Risk:** the two correctness-sensitive areas are the parallel group-table merge (shard boundaries and group-key collisions) and the parallel sort merge (stability across run boundaries); both are addressed in design.md with deterministic merge order and parity tests against the sequential path. Concurrent writes use disjoint output ranges to avoid races (validated under `-race`).
