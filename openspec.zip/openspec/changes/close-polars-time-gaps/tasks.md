## 1. Baseline

- [x] 1.1 Capture a current baseline for `rank`, `group_by`, `sort` at 1K and 1M: `go test ./bench/top30 -bench=BenchmarkTop30$ -benchmem -light`; record ns/op + allocs/op so each phase has a before/after delta (allocations must not regress).

## 2. R-rank — radix ordinal rank

- [x] 2.1 Replace the `sort.SliceStable` argsort in `evalRank` with `chunk.ArgsortFloat64`/`ArgsortInt64` for the null-free, NaN-free numeric fast path; build the ordinal `[]int64` from the returned permutation; keep the comparison-sort fallback for other inputs — `pkg/frame/frame.go` (`evalRank`/`rankSeries`).
- [x] 2.2 Apply the same radix-argsort fast path to the per-partition `rank` branch in `evalOver` (radix-sort each partition's typed values; comparator fallback otherwise) — `pkg/frame/frame.go` (`evalOver`).
- [x] 2.3 Parity tests: radix rank equals the comparison-sort path on duplicate-heavy and mixed-sign data (exact ordinal vectors); equal values keep input order; nullable/NaN/non-numeric fall back correctly.
- [x] 2.4 Benchmark `rank` (standalone + `over`); confirm O(n) behavior and no allocation regression; record the speedup.

## 3. R-group — parallel typed group-by

- [x] 3.1 Add a shard-local typed group table (dtype-switched `map[int64]`/`map[string]`/`map[uint64]`-canonical, matching `chunk.GroupIDs` key encoding incl. canonical NaN / -0 and null bucket) that folds an associative running aggregate (sum/count/min/max/mean-as-sum+count) during the scan, recording each local group's first-seen global row index — `pkg/frame/groupby.go`.
- [x] 3.2 Implement the parallel scan: split `[0,height)` into `GOMAXPROCS` contiguous shards (gated on the `parallelForRows` threshold), build one shard table per worker writing only shard-local state.
- [x] 3.3 Implement the deterministic merge: combine shard tables by typed key, reduce partial aggregates associatively, and order final groups by minimum first-seen row index (matching sequential encounter order); materialize key columns via typed `Gather` of representative rows.
- [x] 3.4 Fall back to the sequential `buckets → evalAgg` path for non-associative aggregates (`n_unique`) or non-`KindCol` expression targets, and below the threshold.
- [x] 3.5 Parity tests vs the sequential typed path: equal group keys + aggregate values; null-key grouping; multi-key grouping; deterministic group order; run under `-race`.
- [x] 3.6 Benchmark `group_by`; confirm speedup scales with cores up to memory bandwidth and allocations do not regress.

## 4. R-sort — parallel merge numeric sort

- [x] 4.1 Add a parallel-merge helper in `pkg/chunk/radix.go`: radix-argsort `GOMAXPROCS` disjoint ranges concurrently (each worker writes its own run), then stable-merge the sorted index runs (on ties, drain the earliest run first) into the final permutation; gate on a large length threshold.
- [x] 4.2 Wire `frame.radixArgsort` to use the parallel-merge helper above the threshold for the single-key null-free numeric fast path; keep the sequential radix below it.
- [x] 4.3 Extend the radix fast path to multi-key sorts whose leading key is null-free numeric: order by the leading key via radix, resolve ties on remaining keys via the existing `buildColumnComparators` (stable); fall back to the full comparison sort otherwise.
- [x] 4.4 Tests: parallel-merge permutation equals a stable reference (`sort.SliceStable`) on duplicate-heavy data (stability across run boundaries); ascending/descending; NaN/null placement identical to the existing sort; multi-key leading-radix tie-break correctness.
- [x] 4.5 Benchmark `sort` (single-key + multi-key); record the achieved speedup; confirm 1K does not regress.

## 5. Validation & wrap-up

- [x] 5.1 `go test ./... -race` and `go vet ./...` pass; all new parity tests green.
- [x] 5.2 Re-run the `bench/top30` suite; update the committed `bench/top30` summary and the README benchmark table for `rank`/`group_by`/`sort`; confirm allocation counts did not regress vs the `close-polars-benchmark-gap` numbers.
- [x] 5.3 Confirm each parallel/radix path is gated (threshold + dtype/null/NaN guards) and that disabling a path (high threshold) cleanly reverts to the sequential fallback; `GOPOLARS_TYPED_STORAGE=0` still forces the row-wise batch-eval path.
