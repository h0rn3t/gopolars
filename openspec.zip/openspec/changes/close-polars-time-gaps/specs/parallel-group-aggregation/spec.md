## ADDED Requirements

### Requirement: Group-by grouping and aggregation run concurrently for large frames

`GroupBy.Agg` SHALL build groups and reduce aggregates concurrently across multiple workers (up to `GOMAXPROCS`) when the row count is above the established parallelism threshold, partitioning rows into disjoint contiguous shards, building a typed group table per shard, and merging the shard tables into the final result. Below the threshold, or for aggregates that cannot be expressed as an associative running reduction over a typed column, the system SHALL use the existing sequential typed path.

#### Scenario: large group_by uses multiple workers

- **WHEN** `group_by(...).agg(sum/min/max/count/mean)` is evaluated on a 1,000,000-row frame above the parallelism threshold
- **THEN** grouping and aggregation SHALL be split across disjoint row shards processed concurrently
- **AND** each worker SHALL write only its own shard-local state (no shared mutable group table)

#### Scenario: small group_by stays sequential

- **WHEN** the frame is below the parallelism threshold
- **THEN** the sequential typed grouping path SHALL be used

### Requirement: Parallel group-by results are identical to the sequential path

The parallel group-by path SHALL produce the same group membership, the same aggregate values, and a deterministic group ordering equal to the sequential typed path (groups in first-encounter order by minimum row index), including null-key handling.

#### Scenario: parallel matches sequential aggregates

- **WHEN** the same `group_by(...).agg(...)` is evaluated via the parallel path and via the sequential typed path
- **THEN** the set of group keys and their aggregate values SHALL be equal

#### Scenario: null and multi-key grouping preserved

- **WHEN** the key column contains nulls, or multiple key columns are given
- **THEN** the parallel path SHALL group nulls together (and composite keys correctly) identically to the sequential path

#### Scenario: deterministic group order

- **WHEN** the parallel path emits result rows
- **THEN** groups SHALL appear in ascending order of their first-seen row index, matching the sequential encounter order
