## ADDED Requirements

### Requirement: Rank uses an O(n) radix argsort for numeric columns

`rank` (both as a standalone expression and within `over(partition)`) SHALL compute its ordinal ranks via an O(n) radix argsort over the typed backing slice for null-free `Int64`/`Float64` columns, rather than an O(n·log n) comparison sort. For inputs outside this fast path (nullable columns, NaN-containing float columns, non-numeric dtypes, or columns below the length threshold) the system SHALL fall back to the existing comparison-sort path.

#### Scenario: numeric rank avoids a comparison sort

- **WHEN** `rank` is evaluated on a null-free, NaN-free 1,000,000-row `Float64` or `Int64` column
- **THEN** the ranks SHALL be produced by the radix argsort path
- **AND** the per-element work SHALL be O(1) amortized (total O(n)), not O(log n) per element

#### Scenario: unsupported input falls back

- **WHEN** `rank` is evaluated on a column that is nullable, contains NaN, or is non-numeric
- **THEN** the system SHALL use the comparison-sort path and still return correct ordinal ranks

### Requirement: Radix rank produces identical ordinal ranks

The radix rank path SHALL produce the same ordinal rank values (1..n, ties broken by input order via a stable sort) as the previous comparison-sort implementation on the same data.

#### Scenario: ranks match the comparison-sort path

- **WHEN** the same `rank` is computed via the radix path and via the comparison-sort fallback on a column with duplicate values
- **THEN** the two rank vectors SHALL be element-wise equal

#### Scenario: equal values keep input order

- **WHEN** a column contains equal values at positions i < j
- **THEN** the value at position i SHALL receive a smaller rank than the value at position j
