## ADDED Requirements

### Requirement: Numeric sorts sort disjoint ranges in parallel and merge

For a numeric sort key above the (large) length threshold, the system SHALL sort disjoint contiguous row ranges in parallel (each via the radix argsort) and merge the sorted index runs into the final permutation. Each worker SHALL write only its own run (no shared mutable state). Below the threshold the existing single-pass radix or comparison sort SHALL be used.

#### Scenario: large numeric sort uses parallel ranges

- **WHEN** a single `Float64`/`Int64` key column of 1,000,000 null-free, NaN-free rows is sorted above the threshold
- **THEN** disjoint row ranges SHALL be radix-sorted concurrently and merged
- **AND** the result SHALL be a permutation that orders the column ascending (or descending when requested)

#### Scenario: small sort stays single-pass

- **WHEN** the input is below the parallel-merge threshold
- **THEN** the existing single-pass radix or comparison sort SHALL be used

### Requirement: Multi-key numeric sort uses the radix leading key with comparator tie-breaks

When the leading sort key is a null-free, NaN-free numeric column, a multi-key sort SHALL order by that key via the radix path and resolve ties on the remaining keys using the existing stable comparators, falling back to the full comparison sort when the leading key is unsupported.

#### Scenario: leading numeric key with tie-break

- **WHEN** a sort is requested on `[numericKey, secondaryKey]` and the numeric key has duplicate values
- **THEN** rows SHALL be ordered by the numeric key, and rows with equal numeric keys SHALL be ordered by `secondaryKey`

### Requirement: Parallel sort preserves order, stability, and NaN/null placement

The parallel-merge sort SHALL produce the same total order, the same stability guarantee, and the same NaN and null placement as the existing sort implementation on the same data and parameters.

#### Scenario: stability across run boundaries

- **WHEN** the data contains many duplicate keys spanning multiple parallel ranges
- **THEN** the merged permutation SHALL place equal-key rows in the same relative order as the sequential stable reference

#### Scenario: order matches the existing sort

- **WHEN** any supported numeric sort is evaluated via the parallel-merge path and via the existing sequential path
- **THEN** the resulting row order SHALL be identical, including ascending/descending and NaN/null positions
