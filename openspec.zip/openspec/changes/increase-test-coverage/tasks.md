## 1. Coverage tooling (report-only first)

- [x] 1.1 Add `scripts/coverage.sh` that runs `go test ./pkg/... -coverprofile=coverage.out`, prints `go tool cover -func` per-package totals, and compares each against a threshold table (baseline 70%, total 75%)
- [x] 1.2 Add a `cover` target to the Makefile (or create one) invoking the script; document usage in the script header
- [x] 1.3 Run the script in report-only mode and record the current per-package baseline as a comment/table in the script

## 2. Lazy execution engine — pkg/exec (26.7% → ≥70%)

- [x] 2.1 Add `engine_streaming_test.go`: assert `ExecuteStreaming` produces equal schema/rows/values vs. standard execution across filter, projection, sort, and limit plans
- [x] 2.2 Test window/partition aggregation paths (`applyWindows`, `computePartitionAgg`, `orderKeyChanged`) with a fixed input frame and hand-checked expected output
- [x] 2.3 Test frame helpers `unionFrames`, `splitFrames`, `concatFrames`, `appendSeries`, and `extractGlobalLimit` directly (export_test hook if needed)
- [x] 2.4 Test `hasStatefulNode` and `executeOptimized` branch coverage; test `aggregateFrame` for each aggregation kind
- [x] 2.5 Add `report_test.go`: assert `ExecuteWithReport` returns per-node entries and an output frame matching standard execution

## 3. Expression layer — pkg/expr (27.2% → ≥70%)

- [x] 3.1 Add `expr_builders_more_test.go` covering string ops (`StrLen`, `StrLower`, `StrUpper`, `StrReplaceAll`, `StartsWith`, `Contains`), datetime ops (`DtYear`, `DtHour`, `DtWeekday`), and list/struct ops (`ListLen`, `ListGet`, `StructField`)
- [x] 3.2 Cover reducers and transforms (`Sum`, `Mean`, `Std`, `Var`, `Skew`, `Reverse`, `TopK`, `TopKBy`, `Rank`, `Over`, `CumSum`, `CumCount`) by building and evaluating against a fixed frame
- [x] 3.3 Cover rolling ops (`RollingMin/Max/Mean/Sum/Std/Var`) and fill ops (`FillNull`, `FillNaN`, `Replace`) with expected windowed values
- [x] 3.4 Cover conditional builders (`When`, `Where`, `Xor`, `TrueDiv`, `UpperBound`) and metadata (`Name`, `Names`, `MapAggregates`, `MapColumnNames`)
- [x] 3.5 Add evaluator tests in `eval_more_test.go`: `evalBin` for arithmetic/comparison/logical ops, `cmpInts`/`cmpFloats`/`cmpStrings`, `cast`, `arith`, `roundToSigFigs`
- [x] 3.6 Test `kleeneBool` three-valued logic with null operands and SQL kernels `compileLikePattern` / `sqlSubstr`

## 4. Plan packages — pkg/plan/logical & pkg/plan/physical (0% → first tests)

- [x] 4.1 Add `pkg/plan/logical/plan_test.go` exercising node constructors and their field/debug representations
- [x] 4.2 Add `pkg/plan/physical/plan_test.go` exercising the physical plan type(s) and any conversion from logical

## 5. Public API gaps — pkg/polars (45.9% → ≥70%)

- [x] 5.1 Identify uncovered exported methods via `go tool cover -func` filtered to `pkg/polars` and list the highest-value gaps
- [x] 5.2 Add tests for uncovered DataFrame/LazyFrame methods, reusing the existing `parity_ms_calc_*` expected-value style
- [x] 5.3 Add tests for uncovered series/groupby/io helper paths surfaced in 5.1

## 6. Remaining gaps

- [x] 6.1 `pkg/chunk`: test `Nulls`, `ConcatColumns`, `AppendRowKey`, `ArgsortFloat64Parallel`, and the `groupIDsSingle` branch
- [x] 6.2 `pkg/sql` (63.3% → ≥70%): add tests for uncovered statement/clause paths surfaced by `cover -func`
- [x] 6.3 `pkg/plan/optimizer` (65.2% → ≥70%): add tests for uncovered optimization rules
- [x] 6.4 `pkg/frame` (72.6% → ≥70% floor, push higher): close the largest remaining gaps from `cover -func`

## 7. Gate and verification

- [x] 7.1 Re-run `make cover`; confirm `pkg/exec`, `pkg/expr`, `pkg/polars` ≥70% and total `pkg/...` ≥75%
- [x] 7.2 Flip `scripts/coverage.sh` to enforcing mode (non-zero exit on any package below threshold); document any per-package override with an inline reason
- [x] 7.3 Run full `go test ./...` to confirm no regressions; flag and separately fix any genuine bug a new test uncovered
- [x] 7.4 (Optional, if CI config in scope) wire `make cover` into the CI workflow as a required check
