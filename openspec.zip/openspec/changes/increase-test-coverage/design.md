## Context

`go test ./pkg/... -coverprofile` reports **58.5%** total statement coverage. The distribution is uneven:

| Package | Coverage | Notes |
|---|---|---|
| `pkg/exec` | 26.7% | engine streaming, windows, union/split/concat, report all 0% |
| `pkg/expr` | 27.2% | most `expr.go` builders 0%; `Eval` 14.5%, `evalBin` 8.8% |
| `pkg/polars` | 45.9% | public API surface |
| `pkg/sql` | 63.3% | |
| `pkg/plan/optimizer` | 65.2% | |
| `pkg/frame` | 72.6% | |
| `pkg/chunk` | 78.9% | `Nulls`, `ConcatColumns`, `AppendRowKey`, `ArgsortFloat64Parallel` 0% |
| `pkg/plan/logical` | — | no test files |
| `pkg/plan/physical` | 0.0% | no test files |
| others (`cache`, `dtypes`, `simd`, `io/*`, `series`, `evalbatch`) | 82–100% | already strong |

The project already uses table-driven Go tests heavily (see existing `*_test.go` and the `parity_ms_calc_*` parity suites in `pkg/polars`). There is no enforced coverage gate today, so coverage can silently regress. The constraint is that this change must not alter library behavior — it adds tests and tooling only.

## Goals / Non-Goals

**Goals:**
- Raise the three weakest core packages (`pkg/exec`, `pkg/expr`, `pkg/polars`) to ≥70% and total `pkg/...` to ≥75%.
- Give `pkg/plan/logical` and `pkg/plan/physical` their first tests.
- Provide one reproducible coverage command that prints a per-package summary and gates on thresholds.
- Prefer tests that assert real behavior (parity with expected values), not coverage-padding calls.

**Non-Goals:**
- Refactoring production code for testability beyond tiny, clearly-justified seams.
- 100% coverage everywhere — generated/benchmark code and trivial getters are out of scope.
- Changing public API behavior. Any bug found gets a separate, flagged fix.
- Adding new test frameworks/dependencies (stay on stdlib `testing` + existing helpers).

## Decisions

**1. Test from the public API down, not symbol-by-symbol.**
Most `pkg/expr` builders and `pkg/exec` engine paths are reachable by constructing a `LazyFrame`/`Expr` and collecting results. Driving tests through realistic plans covers many uncovered functions at once and asserts behavior, rather than calling each unexported helper in isolation. *Alternative considered:* white-box tests per unexported function — rejected as brittle and low-signal, though it will be used for pure helpers (`toFloat`, `compileLikePattern`, `cmpInts`) where a public path is awkward.

**2. Use parity-style expected values where one exists.**
The repo already validates against expected Polars/pandas results (`parity_ms_calc_*`, `test/parity`). New tests reuse that style — small fixed input frames with hand-checked expected output — so they catch regressions, not just execute lines.

**3. Coverage gate as a shell script invoked by `make cover`.**
A `scripts/coverage.sh` runs `go test ./pkg/... -coverprofile`, parses `go tool cover -func` per package, compares against a threshold table, and exits non-zero on any miss. *Alternative considered:* a third-party action like `go-test-coverage` — rejected to avoid a new dependency; a ~40-line script is enough and stays vendor-neutral. The threshold table lives in the script so per-package targets are explicit and easy to ratchet up later.

**4. Threshold values: baseline 70%, total 75%.**
Chosen to be a meaningful jump from 58.5% while achievable without contorting code. Packages already above their floor keep it; the script can be tightened in a follow-up once the floor is green. This avoids setting an aspirational 90% that would stall the change.

**5. Streaming vs. eager equivalence as the primary `pkg/exec` test oracle.**
The strongest correctness check for the engine is that `ExecuteStreaming` and the standard execute path agree on the same plan. This both covers the streaming code and pins its semantics to the already-tested eager path.

## Risks / Trade-offs

- **Tests surface real bugs in long-untested code (exec/expr).** → Treat as success: fix the bug in a separate, clearly-noted commit; keep the failing-then-passing test. Do not paper over with weakened assertions.
- **Coverage chasing produces shallow tests.** → Require each new test to assert concrete output values (parity style); reviewers reject pure line-touching tests.
- **Threshold gate becomes flaky if a package legitimately has near-untestable code (e.g. SIMD asm fallbacks).** → Allow a small documented per-package override in the threshold table rather than a blanket skip; record the reason inline.
- **Engine internals may need a seam to test (e.g. forcing the streaming path).** → Prefer existing public toggles/options; if none exist, add a minimal internal test-only hook in a `_test.go` file (export_test pattern) rather than changing production APIs.
- **Larger test runtime in CI.** → New tests use small fixtures; parallelize with `t.Parallel()` where safe.

## Migration Plan

1. Land the coverage script + `make cover` first (measures current state, gate initially in report-only mode).
2. Add tests package-by-package in priority order (exec → expr → polars → plan/* → sql → optimizer → frame/chunk gaps), re-running `make cover` after each.
3. Flip the gate to enforcing once the weakest packages clear their floor.
4. Wire `make cover` into CI as a required check (optional, follow-up if CI config is out of scope here).

Rollback: tests and the script are additive; reverting the change removes them with no runtime impact.

## Open Questions

- Should the gate run in CI as a hard-fail now, or report-only for one release cycle? (Default: report-only first, then enforce.)
- Are there packages where SIMD/asm or platform-specific branches make 70% impractical, warranting a documented override?
