## Why

Overall statement coverage across `pkg/...` sits at **58.5%**, but the headline number hides large blind spots in the most important code: the lazy execution engine (`pkg/exec` — 26.7%), the expression builder/evaluator (`pkg/expr` — 27.2%), and the public DataFrame/LazyFrame API (`pkg/polars` — 45.9%). Two packages (`pkg/plan/physical`, `pkg/plan/logical`) have no tests at all. These are exactly the areas where regressions are most likely and hardest to catch by hand, so untested branches there carry the highest risk as the project moves toward a tagged release.

## What Changes

- Establish a **package-level minimum coverage policy** and raise the lowest-coverage packages to meet it, lifting overall `pkg/...` coverage from 58.5% toward ~80%.
- Add focused unit tests for the lazy execution engine (`pkg/exec`): streaming execution, window/partition aggregation, frame union/split/concat helpers, global-limit extraction, and report execution.
- Add tests for the expression layer (`pkg/expr`): the builder surface in `expr.go` (string/datetime/list/struct/rolling/cumulative ops, reducers, `When`/`Where`) and the evaluator paths in `eval.go` (`Eval`, `evalBin`, comparisons, casts, Kleene logic, SQL string kernels).
- Add the first tests for `pkg/plan/logical` and `pkg/plan/physical` (currently 0% / no test files).
- Fill remaining gaps in `pkg/polars` public API, `pkg/sql`, `pkg/plan/optimizer`, `pkg/frame`, and `pkg/chunk` (e.g. `Nulls`, `ConcatColumns`, `AppendRowKey`, `ArgsortFloat64Parallel`).
- Add a repeatable `make`/script target that runs coverage and fails when a package drops below its threshold, so coverage is enforced rather than aspirational.

No production code behavior changes; this is a test-and-tooling change. If a test surfaces a genuine bug, that fix will be called out explicitly.

## Capabilities

### New Capabilities
- `test-coverage`: Defines the regression-test coverage policy for the library — per-package minimum statement coverage thresholds, the set of previously-untested behaviors that must gain tests, and the tooling that measures and enforces coverage in CI/local runs.

### Modified Capabilities
<!-- None — no existing library behavior requirements change. -->

## Impact

- **New/expanded test files** under `pkg/exec`, `pkg/expr`, `pkg/polars`, `pkg/sql`, `pkg/plan/logical`, `pkg/plan/physical`, `pkg/plan/optimizer`, `pkg/frame`, `pkg/chunk`.
- **Tooling**: a coverage target (e.g. `make cover` / `scripts/coverage.sh`) and an optional CI gate.
- **No changes** to public API or runtime behavior, except any narrowly-scoped bug fixes uncovered while writing tests (flagged individually).
- **Dependencies**: none added; uses the standard `go test -coverprofile` toolchain already in use.
