## ADDED Requirements

### Requirement: Per-package minimum coverage policy

The test suite SHALL enforce a minimum statement-coverage threshold for each package under `pkg/...`. The baseline threshold SHALL be **70%** for every package that contains executable statements, with the previously low-coverage core packages (`pkg/exec`, `pkg/expr`, `pkg/polars`) raised to at least **70%** and overall `pkg/...` coverage raised to at least **75%**. A package MUST NOT be exempt from the threshold solely because it currently lacks test files.

#### Scenario: Package below threshold fails the gate

- **WHEN** the coverage gate runs and any `pkg/...` package reports statement coverage below its configured threshold
- **THEN** the gate exits non-zero and names each failing package together with its measured coverage

#### Scenario: All packages meet threshold

- **WHEN** the coverage gate runs and every `pkg/...` package meets or exceeds its threshold
- **THEN** the gate exits zero and prints the per-package and total coverage summary

### Requirement: Lazy execution engine is covered

The `pkg/exec` package SHALL have unit tests exercising the streaming and optimized execution paths, including window/partition aggregation, frame union/split/concat helpers, global-limit extraction, stateful-node detection, and report-based execution.

#### Scenario: Streaming execution produces same result as eager execution

- **WHEN** a lazy plan is executed via the streaming path and via the standard path on identical input
- **THEN** both produce frames with equal schema, row count, and values

#### Scenario: Report execution returns timing and node metadata

- **WHEN** a plan is executed with the report-producing entry point
- **THEN** the resulting report contains per-node entries and the output frame matches standard execution

### Requirement: Expression builder and evaluator are covered

The `pkg/expr` package SHALL have unit tests for the public expression builder surface (string, datetime, list, struct, rolling, cumulative, reducer, and conditional `When`/`Where` constructors) and for the evaluator (`Eval`, `evalBin`, integer/float/string comparisons, casts, Kleene boolean logic, and SQL string kernels).

#### Scenario: Builder constructors produce evaluable expressions

- **WHEN** an expression is built from a builder constructor (e.g. a rolling, string, or datetime op) and evaluated against a frame
- **THEN** evaluation succeeds and the output column matches the expected values

#### Scenario: Kleene boolean logic handles nulls

- **WHEN** a boolean binary expression is evaluated over operands containing null/unknown values
- **THEN** the result follows three-valued (Kleene) logic semantics

### Requirement: Logical and physical plan packages are covered

The `pkg/plan/logical` and `pkg/plan/physical` packages SHALL each have at least one test file, and their exported constructors and transformations SHALL be exercised by tests.

#### Scenario: Plan construction round-trips

- **WHEN** a logical or physical plan node is constructed and inspected
- **THEN** its fields and string/debug representation match the construction inputs

### Requirement: Coverage tooling is repeatable

The repository SHALL provide a single command (e.g. a `make` target or `scripts/coverage.sh`) that produces a coverage profile for `pkg/...`, prints a per-package summary, and applies the threshold gate, so coverage can be reproduced locally and in CI without manual flag composition.

#### Scenario: Developer runs the coverage command

- **WHEN** a developer runs the coverage command from the repository root
- **THEN** a coverage profile is written, a per-package summary is printed, and the command's exit code reflects whether the thresholds were met
